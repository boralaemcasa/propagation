package br.com.calcula.wiki.entidades;

import br.com.calcula.wiki.Util;

public class BigTask implements Runnable {

	private Boolean flag;

	public BigTask(Boolean continuar) {
		flag = continuar;
	}

	public void run() {
		try {
			if (flag) {
				Util.println("[5 processado via continue.]");
			} else {
				Util.println("[5 processado.]");
			}
		} catch (Exception e) {
			Util.println("SQL Exception");
			e.printStackTrace();
		}
	}

}
