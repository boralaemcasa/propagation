package br.com.calcula.wiki;

public class IntervalVector {
	public Interval[] x;

	public Interval getX() {
		return x[0];
	}

	public IntervalVector(Integer n, Interval x) {
		this.x = new Interval[n];
		this.x[0].set(x);
	}

	public IntervalVector(Integer n) {
		this.x = new Interval[n];
	}

	public boolean equals(IntervalVector f) {
		return getX().equals(f.getX());
	}

	public boolean equals(Interval y) {
		return getX().equals(y);
	}

	@Override
	public String toString() {
		return getX().toString();
	}

	public Interval[] [] cartesiano(Integer nPontos, Integer nVariaveis, Integer nPower) {
		Interval[] [] mat = new Interval[nPower][nVariaveis];
		// {0,1}^3 = 01010101 x 00110011 x 00001111
		Integer rep = 1;
		for (Integer v = 0;v < nVariaveis;v++, rep *= nPontos) {
			Integer j = 0;
			Integer k = 0;
			for (Integer i = 0;i < nPower;i++) {
				mat[i][v] = x[j];
				k++;
				if (k >= rep) {
					k = 0;
					j++;
					if (j >= nPontos)
						j = 0;
				}
			}
		}

		return mat;
	}
}
