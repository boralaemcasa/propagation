package br.com.calcula.wiki;

import br.com.calcula.wiki.entidades.AverageInterval;
import br.com.calcula.wiki.entidades.MyTask;
import br.com.calcula.wiki.entidades.SaidaInterval;

public class Memo {
	public Integer x;
	public String valor;
	public String output;
	public String resto;
	public Boolean error;

	public Memo(String valor1) {
		valor = valor1.replace("\r", "");
		valor = valor.replace(" ", "\n");
		do {
			x = valor.indexOf("\n\n");
			valor = valor.replace("\n\n", "\n");
		} while (x >= 0);
		error = false;
	}

	public Boolean readOutput() {
		x = valor.indexOf("\n");
		if (x < 0)
			return false;
		resto = valor.substring(x + 1);
		output = valor.substring(0, x);
		return true;
	}

	public Double readDouble() {
		Double Result = 0.0;
		x = resto.indexOf("\n");
		if (x < 0) {
			error = true;
			return Result;
		}
		String target = resto.substring(0, x);
		resto = resto.substring(x + 1);
		try {
			Result = Double.parseDouble(target);
		} catch (NumberFormatException e) {
			error = true;
		}
		return Result;
	}

	public Integer readInt() {
		Integer Result = 0;
		x = resto.indexOf("\n");
		if (x < 0) {
			error = true;
			return Result;
		}
		String target = resto.substring(0, x);
		resto = resto.substring(x + 1);
		try {
			Double dbl = Double.parseDouble(target);
			Result = dbl.intValue();
		} catch (NumberFormatException e) {
			error = true;
		}
		return Result;
	}

	public Interval readInterval() {
		Interval Result = new Interval();

		Result.min = this.readDouble();
		if (this.error)
			return Result;

		Result.max = this.readDouble();
		return Result;
	}

	public String fuzzyInterval(MyTask task) {
		if (!this.readOutput())
			return "output n&#xe3;o encontrado.";
		Double xleft = this.readDouble(), xright, ybottom, ytop;
		Interval xit = new Interval(), xft = new Interval(), alpha = new Interval(), tmp = new Interval();
		if (this.error)
			return "xleft n&#xe3;o encontrado.";

		xright = this.readDouble();
		if (this.error)
			return "xright n&#xe3;o encontrado.";

		if (this.output.equals("square"))
			return task.fsquare(xleft, xright);

		if (this.output.equals("exp"))
			return task.fexp(xleft, xright);

		ybottom = this.readDouble();
		if (this.error)
			return "ybottom n&#xe3;o encontrado.";

		ytop = this.readDouble();
		if (this.error)
			return "ytop n&#xe3;o encontrado.";

		if (this.output.equals("plus"))
			return task.fplus(xleft, xright, ybottom, ytop);

		if (this.output.equals("minus"))
			return task.fminus(xleft, xright, ybottom, ytop);

		if (this.output.equals("times"))
			return task.ftimes(xleft, xright, ybottom, ytop);

		if (this.output.equals("over"))
			return task.fover(xleft, xright, ybottom, ytop);

		if (this.output.equals("equals"))
			return task.fequals(xleft, xright, ybottom, ytop);

		if (this.output.equals("lessthan"))
			return task.flessthan(xleft, xright, ybottom, ytop);

		if (this.output.equals("le"))
			return task.fle(xleft, xright, ybottom, ytop);

		alpha = this.readInterval();
		if (this.error)
			return "Intervalo alfa n&#xe3;o encontrado.";

		if (this.output.equals("gauss"))
			return task.fgauss(xleft, xright, ybottom, ytop, alpha.min, alpha.max);

		Integer nGaussianas = this.readInt(), nPontosT = 0, nPontosV = 0, nVariaveis, nEpocas, i, j, v;
		if (this.error)
			return "nGaussianas n&#xe3;o encontrado.";

		nVariaveis = this.readInt();
		if (this.error)
			return "nVari&#xe1;veis n&#xe3;o encontrado.";

		nEpocas = this.readInt();
		if (this.error)
			return "n&#xc9;pocas n&#xe3;o encontrado.";

		task.setSaida1("Princ&#xED;pio do processamento 1 = simples\n\n");
		task.setSaida2("Princ&#xED;pio do processamento 1 = simples\n\n");
		Interval[][] xt = null, xv = null;
		Interval[] ydt = null, ydv = null;

		if (this.output.equals("lista")) {

			nPontosT = this.readInt();
			if (this.error)
				return "nPontosT n&#xe3;o encontrado.";

			nPontosV = this.readInt();
			if (this.error)
				return "nPontosV n&#xe3;o encontrado.";

			xt = new Interval[nPontosT][nVariaveis];
			xv = new Interval[nPontosV][nVariaveis];
			ydt = new Interval[nPontosT];
			ydv = new Interval[nPontosV];
			xit.min = Util.infty;
			xft.min = 0.0;
			for (i = 0; i < nPontosT; i++)
				for (v = 0; v < nVariaveis; v++) {

					tmp = this.readInterval();
					if (this.error)
						return "Intervalo xt_{" + i.toString() + ", " + v.toString() + "} n&#xe3;o encontrado.";
					if (tmp.min < xit.min)
						xit.set(tmp);
					if (tmp.min > xft.min)
						xft.set(tmp);
					;
					xt[i][v].set(tmp);
				}

			for (i = 0; i < nPontosT; i++) {
				ydt[i] = this.readInterval();
				if (this.error)
					return "Intervalo ydt_" + i.toString() + " n&#xe3;o encontrado.";
			}

			for (i = 0; i < nPontosV; i++)
				for (v = 0; v < nVariaveis; v++) {
					xv[i][v] = this.readInterval();
					if (this.error)
						return "Intervalo xv_{" + i.toString() + ", " + v.toString() + "} n&#xe3;o encontrado.";
				}

			for (i = 0; i < nPontosV; i++) {
				ydv[i] = this.readInterval();
				if (this.error)
					return "ydv_" + i.toString() + " n&#xe3;o encontrado.";
			}
		} else {
			xit = this.readInterval();
			if (this.error)
				return "Intervalo xi_t n&#xe3;o encontrado.";

			xft = this.readInterval();
			if (this.error)
				return "Intervalo xf_t n&#xe3;o encontrado.";

			Double stept = this.readDouble();
			if (this.error)
				return "step_t n&#xe3;o encontrado.";

			Interval xiv = this.readInterval();
			if (this.error)
				return "Intervalo xi_v n&#xe3;o encontrado.";

			Interval xfv = this.readInterval();
			if (this.error)
				return "Intervalo xf_v n&#xe3;o encontrado.";

			Double stepv = this.readDouble();
			if (this.error)
				return "step_v n&#xe3;o encontrado.";

			tmp.min = (xft.min - xit.min) / stept + 1.0;
			tmp.max = (xft.max - xit.max) / stept + 1.0;
			nPontosT = tmp.min.intValue();
			IntervalVector xvect = new IntervalVector(nPontosT);
			tmp.set(xit);
			for (i = 0; i < nPontosT; i++) {
				xvect.x[i] = new Interval(tmp);
				tmp.min += stept;
				tmp.max += stept;
			}
			j = nPontosT;
			for (i = 1; i < nVariaveis; i++)
				j *= nPontosT;
			xt = xvect.cartesiano(nPontosT, nVariaveis, j);
			nPontosT = j;

			tmp.min = (xfv.min - xiv.min) / stepv + 1.0;
			tmp.max = (xfv.max - xiv.max) / stepv + 1.0;
			nPontosV = tmp.min.intValue();
			IntervalVector xvecv = new IntervalVector(nPontosV);
			tmp.set(xiv);
			for (i = 0; i < nPontosV; i++) {
				xvecv.x[i] = new Interval(tmp);
				tmp.min += stepv;
				tmp.max += stepv;
			}
			j = nPontosV;
			for (i = 1; i < nVariaveis; i++)
				j *= nPontosV;
			xv = xvecv.cartesiano(nPontosV, nVariaveis, j);
			nPontosV = j;

			ydt = new Interval[nPontosT];
			for (i = 0; i < nPontosT; i++)
				if (nVariaveis.equals(3) && this.output.equals("livro")) {
					tmp.set(xt[i][2]);
					Interval sqrt = tmp.sqrt();
					Interval soma = sqrt.over(tmp);
					tmp.set(1.0, 1.0);
					soma = soma.plus(tmp);
					tmp = tmp.over(xt[i][1]);
					soma = soma.plus(tmp);
					ydt[i] = soma.plus(xt[i][0].sqrt());
				} else {
					ydt[i] = new Interval(0.0, 0.0);
					for (v = 0; v < nVariaveis; v++) {
						tmp.min = xt[i][v].avg();
						ydt[i] = ydt[i].plusConstant(Math.abs(tmp.min));
					}
				}

			ydv = new Interval[nPontosV];
			for (i = 0; i < nPontosV; i++)
				if (nVariaveis.equals(3) && this.output.equals("livro")) {
					tmp.set(xv[i][2]);
					Interval sqrt = tmp.sqrt();
					Interval soma = sqrt.over(tmp);
					tmp.set(1.0, 1.0);
					soma = soma.plus(tmp);
					tmp = tmp.over(xv[i][1]);
					soma = soma.plus(tmp);
					ydv[i] = soma.plus(xv[i][0].sqrt());
				} else {
					ydv[i] = new Interval(0.0, 0.0);
					for (v = 0; v < nVariaveis; v++) {
						tmp.min = xv[i][v].avg();
						ydv[i] = ydv[i].plusConstant(Math.abs(tmp.min));
					}
				}
		}

		if (nVariaveis > 1) {
			xleft = -1.0;
			xright = 1.0 + (double) nPontosV;
		}
		task.setSaida1(task.getSaida1() + "\nNro de pontos treinamento = " + nPontosT.toString()
				+ "\nNro de pontos valida&#xE7;&#xe3;o = " + nPontosV.toString());
		task.setSaida3(xleft.toString() + "\n" + xright.toString() + "\n" + ybottom.toString() + "\n" + ytop.toString()
				+ "\n" + nPontosV.toString() + "\n");
		if (nVariaveis.equals(1)) {
			for (i = 0; i < nPontosV; i++)
				task.setSaida3(task.getSaida3() + xv[i][0].graph() + ydv[i].graph());
		} else
			for (i = 0; i < nPontosV; i++)
				task.setSaida3(task.getSaida3() + i.toString() + "\n" + i.toString() + "\n" + ydv[i].graph());

		AverageInterval[] erro = new AverageInterval[8];
		erro[0] = calcularAPE(alpha, nEpocas, nPontosT, nPontosV, xt, xv, ydt, ydv, nVariaveis, nGaussianas, xit, xft,
				false, false, false);
		erro[1] = calcularAPE(alpha, nEpocas, nPontosT, nPontosV, xt, xv, ydt, ydv, nVariaveis, nGaussianas, xit, xft,
				false, false, true);
		erro[2] = calcularAPE(alpha, nEpocas, nPontosT, nPontosV, xt, xv, ydt, ydv, nVariaveis, nGaussianas, xit, xft,
				false, true, false);
		erro[3] = calcularAPE(alpha, nEpocas, nPontosT, nPontosV, xt, xv, ydt, ydv, nVariaveis, nGaussianas, xit, xft,
				false, true, true);
		erro[4] = calcularAPE(alpha, nEpocas, nPontosT, nPontosV, xt, xv, ydt, ydv, nVariaveis, nGaussianas, xit, xft,
				true, false, false);
		erro[5] = calcularAPE(alpha, nEpocas, nPontosT, nPontosV, xt, xv, ydt, ydv, nVariaveis, nGaussianas, xit, xft,
				true, false, true);
		erro[6] = calcularAPE(alpha, nEpocas, nPontosT, nPontosV, xt, xv, ydt, ydv, nVariaveis, nGaussianas, xit, xft,
				true, true, false);
		erro[7] = calcularAPE(alpha, nEpocas, nPontosT, nPontosV, xt, xv, ydt, ydv, nVariaveis, nGaussianas, xit, xft,
				true, true, true);
		i = 0;
		while ((i < 7) && (erro[i].ape.equals(0.0) || erro[i].ape.isNaN()))
			i++;
		for (j = i + i; j < 8; j++)
			if (!erro[j].ape.equals(0.0))
				if (!erro[j].ape.isNaN())
					if (erro[j].ape < erro[i].ape)
						i = j;

		task.setSaida1(task.getSaida1() + "\nAverage Error " + erro[i].ape.toString() + "%\nalfa = "
				+ erro[i].alpha.toString());

		if (nVariaveis.equals(1)) {
			for (j = 0; j < nPontosV; j++)
				task.setSaida3(task.getSaida3() + xv[j][0].graph() + erro[i].saida.ys[j].graph());
		} else
			for (j = 0; j < nPontosV; j++)
				task.setSaida3(
						task.getSaida3() + j.toString() + "\n" + j.toString() + "\n" + erro[i].saida.ys[j].graph());

		task.setSaida2(task.getSaida2() + "\n<a href=\"/grafico\" target=\"_blank\">Gr&#xe1;fico</a>\n&#xc9;pocas = "
				+ erro[i].epocas.toString());

		for (j = 1; j <= nGaussianas; j++) {
			task.setSaida2(task.getSaida2() + "\nq_" + j.toString() + " = " + erro[i].q[j - 1].toString());
			for (v = 1; v <= nVariaveis; v++)
				task.setSaida2(task.getSaida2() + "\np_{" + j.toString() + ", " + v.toString() + "} = "
						+ erro[i].p[j - 1][v - 1].toString() + "\nc_{" + j.toString() + ", " + v.toString() + "} = "
						+ erro[i].c[j - 1][v - 1].toString() + "\nsigma_{" + j.toString() + ", " + v.toString() + "} = "
						+ erro[i].sigma[j - 1][v - 1].toString());
		}

		Util.println("[fim 1] verifique");
		return "Processamento conclu&#xed;do.";
	}

	public AverageInterval calcularAPE(Interval alpha, Integer nEpocas, Integer nPontosT, Integer nPontosV,
			Interval[][] xt, Interval[][] xv, Interval[] ydt, Interval[] ydv, Integer nVariaveis, Integer nGaussianas,
			Interval xit, Interval xft, Boolean normalizar, Boolean limitar, Boolean copiar) {
		if (normalizar)
			System.out.print("1");
		else
			System.out.print("0");
		if (limitar)
			System.out.print("1");
		else
			System.out.print("0");
		if (copiar)
			System.out.print("1 ");
		else
			System.out.print("0 ");
		Double apeAnt = Util.infty;
		Interval tmp = new Interval();
		Integer j, k, v;
		Interval[] dq = new Interval[nGaussianas];
		Interval[][] dp = new Interval[nGaussianas][nVariaveis];
		Interval[][] dc = new Interval[nGaussianas][nVariaveis];
		Interval[][] dsigma = new Interval[nGaussianas][nVariaveis];

		AverageInterval obj = new AverageInterval(), Result = new AverageInterval();
		obj.alpha = new Interval(alpha);
		obj.q = new Interval[nGaussianas];
		obj.p = new Interval[nGaussianas][nVariaveis];
		obj.c = new Interval[nGaussianas][nVariaveis];
		obj.sigma = new Interval[nGaussianas][nVariaveis];
		tmp.min = (xft.min - xit.min) / (nGaussianas - 1.0);
		tmp.max = (xft.max - xit.max) / (nGaussianas - 1.0);
		for (k = 0; k < nGaussianas; k++) {
			obj.q[k] = new Interval(Math.random());
			obj.q[k].max = obj.q[k].min;
			for (v = 0; v < nVariaveis; v++) {
				obj.p[k][v] = new Interval(Math.random());
				obj.p[k][v].max = obj.p[k][v].min;
				Interval interval = tmp.timesConstant((double) k);
				obj.c[k][v] = xit.plus(interval);
				obj.sigma[k][v] = tmp.timesConstant(0.5 / Math.sqrt(2.0 * Math.log(2.0)));
			}
		}

		Integer[] shuffle = new Integer[nPontosT];
		obj.saida = null;
		Interval dysdyj = new Interval(), dyjdpij = new Interval();
		for (obj.epocas = 0; (obj.epocas < 500) && (obj.epocas < nEpocas); obj.epocas++) {
			for (k = 0; k < nPontosT; k++)
				shuffle[k] = k;
			for (k = 0; k < 1000; k++) {// mil embaralhadas
				j = (int) (Math.random() * 1000000.0) % nPontosT;
				v = (int) (Math.random() * 1000000.0) % nPontosT;
				Integer t = shuffle[v];
				shuffle[v] = shuffle[j];
				shuffle[j] = t;
			}

			for (k = 0; k < nPontosT; k++) {
				obj.saida = calcularSaidaInterval(Util.matrixInterval(xt[shuffle[k]], nVariaveis), nVariaveis,
						nGaussianas, 1, obj.c, obj.sigma, obj.p, obj.q);
				Double max = 0.0;
				for (j = 0; j < nGaussianas; j++) {
					Interval dysdwj = obj.saida.z[j].minus(obj.saida.ys[0]);
					dysdwj = dysdwj.over(obj.saida.denom);
					dysdyj.set(obj.saida.omega[j]);
					Interval dedys = obj.saida.ys[0].minus(ydt[shuffle[k]]);
					if (normalizar) {
						dedys.min /= Math.abs(dedys.min);
						dedys.max /= Math.abs(dedys.max);
					}
					for (v = 0; v < nVariaveis; v++) {
						Interval sq = obj.sigma[j][v].square();
						Interval cu = obj.sigma[j][v].cube();
						Interval difx = xt[shuffle[k]][v].minus(obj.c[j][v]);
						Interval interval = obj.saida.omega[j].times(difx);
						Interval dwjdcij = interval.over(sq);
						difx = difx.square();
						Interval dwjdsij = interval.over(cu);
						dyjdpij.set(xt[shuffle[k]][v]);

						tmp = dedys.times(dysdwj);
						dc[j][v] = tmp.times(dwjdcij);
						tmp.min = dc[j][v].avg();
						if (tmp.min > max)
							max = tmp.min;

						tmp = dedys.times(dysdwj);
						dsigma[j][v] = tmp.times(dwjdsij);
						tmp.min = dsigma[j][v].avg();
						if (tmp.min > max)
							max = tmp.min;

						tmp = dedys.times(dysdyj);
						dp[j][v] = tmp.times(dyjdpij);
						tmp.min = dp[j][v].avg();
						if (tmp.min > max)
							max = tmp.min;
					}
					dq[j] = dedys.times(dysdyj);
					tmp.min = dq[j].avg();
					if (tmp.min > max)
						max = tmp.min;
				}
				if (limitar && (max > 100.0))
					alpha = alpha.timesConstant(0.01);
				for (j = 0; j < nGaussianas; j++) {
					for (v = 0; v < nVariaveis; v++) {
						tmp = alpha.times(dc[j][v]);
						obj.c[j][v] = obj.c[j][v].minus(tmp);
						tmp = alpha.times(dsigma[j][v]);
						obj.sigma[j][v] = obj.sigma[j][v].minus(tmp);
						tmp = alpha.times(dp[j][v]);
						obj.p[j][v] = obj.p[j][v].minus(tmp);
					}
					tmp = alpha.times(dq[j]);
					obj.q[j] = obj.q[j].minus(tmp);
				}
			}
			if (copiar) {
				obj.saida = calcularSaidaInterval(xv, nVariaveis, nGaussianas, nPontosV, obj.c, obj.sigma, obj.p,
						obj.q);
				obj.ape = 0.0;
				for (v = 0; v < nPontosV; v++) {
					tmp.max = obj.saida.ys[v].avg();
					if (!tmp.max.equals(0.0)) {
						tmp.min = (tmp.max - ydv[v].avg()) / tmp.max;
						obj.ape += Math.abs(tmp.min);
					}
				}
				obj.ape /= (double) nPontosV / 100.0;
				if ((obj.ape > 0.0) && (obj.ape < apeAnt) || obj.epocas.equals(0)) {
					Result.copy(obj, nGaussianas, nVariaveis);
					apeAnt = obj.ape;
				} else
					obj.copy(Result, nGaussianas, nVariaveis);
			}
		}

		if (copiar)
			obj.copy(Result, nGaussianas, nVariaveis);
		obj.saida = calcularSaidaInterval(xv, nVariaveis, nGaussianas, nPontosV, obj.c, obj.sigma, obj.p, obj.q);
		obj.ape = 0.0;
		for (k = 0; k < nPontosV; k++) {
			tmp.max = obj.saida.ys[k].avg();
			if (!tmp.max.equals(0.0)) {
				tmp.min = (tmp.max - ydv[k].avg()) / tmp.max;
				obj.ape += Math.abs(tmp.min);
			}
		}
		obj.ape /= (double) nPontosV / 100.0;
		Util.println(obj.ape.toString());
		return obj;
	}

	public SaidaInterval calcularSaidaInterval(Interval[][] X, Integer nVariaveis, Integer nGaussianas, Integer nPontos,
			Interval[][] c, Interval[][] sigma, Interval[][] p, Interval[] q) {
		SaidaInterval Result = new SaidaInterval();
		Result.omega = new Interval[nGaussianas];
		Result.z = new Interval[nGaussianas];
		Result.ys = new Interval[nPontos];
		Interval[] ysd = new Interval[nPontos];
		Interval tmp, ysn = new Interval();
		for (Integer k = 0; k < nPontos; k++) {
			ysn.set(0.0, 0.0);
			ysd[k] = new Interval(0.0, 0.0);
			for (Integer j = 0; j < nGaussianas; j++) {
				Result.omega[j] = new Interval(1.0, 1.0);
				Result.z[j] = new Interval(q[j]);
				for (Integer v = 0; v < nVariaveis; v++) {
					tmp = X[k][v].gauss(c[j][v], sigma[j][v]);
					Result.omega[j] = Result.omega[j].times(tmp);
					tmp = p[j][v].times(X[k][v]);
					Result.z[j] = Result.z[j].plus(tmp);
				}
				tmp = Result.omega[j].times(Result.z[j]);
				ysn = ysn.plus(tmp);
				ysd[k] = ysd[k].plus(Result.omega[j]);
			}

			Result.ys[k] = ysn.over(ysd[k]);
		}
		Result.denom = new Interval(ysd[0]);
		return Result;
	}

}
