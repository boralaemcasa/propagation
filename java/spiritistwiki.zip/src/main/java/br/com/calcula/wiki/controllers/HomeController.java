package br.com.calcula.wiki.controllers;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import br.com.calcula.wiki.Lambda;
import br.com.calcula.wiki.SFrac;
import br.com.calcula.wiki.SNum;
import br.com.calcula.wiki.Util;
import br.com.calcula.wiki.entidades.MyTask;

@Controller
public class HomeController {
	private Boolean linguaPortuguesa;
	private String sCarmichael;
	private String sReturned;
	private String sIsCarmichael;
	private String sInvalid;
	private String sInput;
	private String sOrderSuccess;
	private String sIncrement;

	private void setLinguagem(Boolean portugues) {
		linguaPortuguesa = portugues;
		if (portugues) {
			sCarmichael = "Carmichael m&#xf3;dulo ";
			sReturned = " retornou:";
			sIsCarmichael = " &#xe9; um n&#xfa;mero de Carmichael";
			sInvalid = "M&#xf3;dulo inv&#xe1;lido.";
			sInput = "Entrada inv&#xe1;lida para ax + by = 1.";
			sOrderSuccess = "Ordem m&#xf3;dulo m realizada com sucesso";
			sIncrement = "Incrementar retornou:";
		} else {
			sCarmichael = "Carmichael modulo ";
			sReturned = " returned:";
			sIsCarmichael = " is a Carmichael number";
			sInvalid = "Invalid modulo.";
			sInput = "Invalid input for ax + by = 1.";
			sOrderSuccess = "Order modulo m returned with success";
			sIncrement = "Increment returned:";
		}
	}

	@RequestMapping("/wiki/home/open")
	public String home(final Map<String, Object> modelMap) {
		modelMap.put("message", "Wait for next release.");
		modelMap.put("valor1", "select a.hora, \'OUT\' as c, a.i::text, a.j::text, a.k::text, a.max::text\n"
				+ "from statusout a\n" + "\n" + "union\n" + "\n"
				+ "select w.hora, \'WITH\', w.i::text, w.who1 || \' \' || w.a1::text, w.who2 || \' \' || w.b1::text, w.line::text\n"
				+ "from statuswith w\n" + "order by 1 desc");
		return "home";
	}

	@RequestMapping("/wiki/entrada/abrir")
	public String entrada(final Map<String, Object> modelMap) {
		modelMap.put("message", "Aguarde pr&#xf3;xima vers&#xe3;o.");
		modelMap.put("valor1", "select a.hora, \'OUT\' as c, a.i::text, a.j::text, a.k::text, a.max::text\n"
				+ "from statusout a\n" + "\n" + "union\n" + "\n"
				+ "select w.hora, \'WITH\', w.i::text, w.who1 || \' \' || w.a1::text, w.who2 || \' \' || w.b1::text, w.line::text\n"
				+ "from statuswith w\n" + "order by 1 desc");
		return "entrada";
	}

	@PostMapping("/main/fracAdd")
	public String fracAddE(String valor1, String valor2, String valor50, Map<String, Object> modelMap) {
		valor1 = SNum.FracValida(valor1);
		valor2 = SNum.FracValida(valor2);
		String valor3 = "";
		if (valor50.equals("1")) {
			valor3 = SNum.FracAdd(valor1, valor2);
			modelMap.put("message", "Summed with success.");
		} else if (valor50.equals("2")) {
			valor3 = SNum.FracSub(valor1, valor2);
			modelMap.put("message", "Subtracted with success.");
		} else if (valor50.equals("3")) {
			valor3 = SNum.FracMul(valor1, valor2);
			modelMap.put("message", "Multiplied with success.");
		} else if (valor50.equals("4")) {
			valor3 = SNum.FracDiv(valor1, valor2);
			modelMap.put("message", "Divided with success.");
		} else if (valor50.equals("5")) {
			valor3 = SNum.FracPower(valor1, valor2);
			modelMap.put("message", "Power returned with success.");
		} else if (valor50.equals("6")) {
			valor3 = SNum.binom(valor1, valor2);
			modelMap.put("message", "Newton Binomial returned with success.");
		}

		modelMap.put("valor1", valor1.replace("_", "/"));
		modelMap.put("valor2", valor2.replace("_", "/"));
		modelMap.put("valor3", valor3.replace("_", "/"));
		return "main";
	}

	@PostMapping("/principal/fracAdd")
	public String fracAddP(String valor1, String valor2, String valor50, Map<String, Object> modelMap) {
		valor1 = SNum.FracValida(valor1);
		valor2 = SNum.FracValida(valor2);
		String valor3 = "";
		if (valor50.equals("1")) {
			valor3 = SNum.FracAdd(valor1, valor2);
			modelMap.put("message", "Somado com sucesso.");
		} else if (valor50.equals("2")) {
			valor3 = SNum.FracSub(valor1, valor2);
			modelMap.put("message", "Subtra&#xed;do com sucesso.");
		} else if (valor50.equals("3")) {
			valor3 = SNum.FracMul(valor1, valor2);
			modelMap.put("message", "Multiplicado com sucesso.");
		} else if (valor50.equals("4")) {
			valor3 = SNum.FracDiv(valor1, valor2);
			modelMap.put("message", "Dividido com sucesso.");
		} else if (valor50.equals("5")) {
			valor3 = SNum.FracPower(valor1, valor2);
			modelMap.put("message", "Pot&#xea;ncia realizada com sucesso.");
		} else if (valor50.equals("6")) {
			valor3 = SNum.binom(valor1, valor2);
			modelMap.put("message", "Bin&#xf4;mio de Newton realizado com sucesso.");
		}

		modelMap.put("valor1", valor1.replace("_", "/"));
		modelMap.put("valor2", valor2.replace("_", "/"));
		modelMap.put("valor3", valor3.replace("_", "/"));
		return "principal";
	}

	@PostMapping("/main/fracLog")
	public String fracLogE(String valor19, String valor20, String valor22, Map<String, Object> modelMap) {
		valor19 = SNum.FracValida(valor19);
		valor20 = SNum.FracValida(valor20);
		valor22 = SNum.FracValida(valor22);
		final String result = SNum.FracLog(valor20, valor22, valor19);

		modelMap.put("valor19", valor19.replace("_", "/"));
		modelMap.put("valor20", valor20.replace("_", "/"));
		modelMap.put("valor21", result.replace("_", "/"));
		modelMap.put("valor22", valor22.replace("_", "/"));
		modelMap.put("message", "Logarithm returned with success.");

		return "main";
	}

	@PostMapping("/principal/fracLog")
	public String fracLogP(String valor19, String valor20, String valor22, Map<String, Object> modelMap) {
		valor19 = SNum.FracValida(valor19);
		valor20 = SNum.FracValida(valor20);
		valor22 = SNum.FracValida(valor22);
		final String result = SNum.FracLog(valor20, valor22, valor19);

		modelMap.put("valor19", valor19.replace("_", "/"));
		modelMap.put("valor20", valor20.replace("_", "/"));
		modelMap.put("valor21", result.replace("_", "/"));
		modelMap.put("valor22", valor22.replace("_", "/"));
		modelMap.put("message", "Logaritmo realizado com sucesso.");

		return "principal";
	}

	@PostMapping("/main/Gamma")
	public String GammaE(String valor23, String valor48, Map<String, Object> modelMap) {
		valor23 = SNum.FracValida(valor23);
		valor48 = SNum.FracValida(valor48);
		final String result = SNum.FracGamma(valor48, valor23);

		modelMap.put("valor23", valor23.replace("_", "/"));
		modelMap.put("valor48", valor48.replace("_", "/"));
		modelMap.put("valor24", result.replace("_", "/"));
		modelMap.put("message", "Gamma returned with success.");

		return "main";
	}

	@PostMapping("/principal/Gamma")
	public String GammaP(String valor23, String valor48, Map<String, Object> modelMap) {
		valor23 = SNum.FracValida(valor23);
		valor48 = SNum.FracValida(valor48);
		final String result = SNum.FracGamma(valor48, valor23);

		modelMap.put("valor23", valor23.replace("_", "/"));
		modelMap.put("valor48", valor48.replace("_", "/"));
		modelMap.put("valor24", result.replace("_", "/"));
		modelMap.put("message", "Gama realizado com sucesso.");

		return "principal";
	}

	@PostMapping("/main/floor")
	public String floorE(String valor25, Map<String, Object> modelMap) {
		valor25 = SNum.FracValida(valor25);
		final String result = SNum.FracFloor(valor25);

		modelMap.put("valor25", valor25.replace("_", "/"));
		modelMap.put("valor26", result);
		modelMap.put("message", "Floor returned with success.");

		return "main";
	}

	@PostMapping("/principal/floor")
	public String floorP(String valor25, Map<String, Object> modelMap) {
		valor25 = SNum.FracValida(valor25);
		final String result = SNum.FracFloor(valor25);

		modelMap.put("valor25", valor25.replace("_", "/"));
		modelMap.put("valor26", result);
		modelMap.put("message", "Piso realizado com sucesso.");

		return "principal";
	}

	@PostMapping("/main/gcd")
	public String gcdE(String valor27, String valor28, Map<String, Object> modelMap) {
		valor27 = SNum.Valida(SNum.FracValida(valor27));
		valor28 = SNum.Valida(SNum.FracValida(valor28));
		final String result = SNum.mdc(valor27, valor28);

		modelMap.put("valor27", valor27);
		modelMap.put("valor28", valor28);
		modelMap.put("valor29", result);
		modelMap.put("message", "Greatest Common Divisor returned with success.");

		return "main";
	}

	@PostMapping("/principal/gcd")
	public String gcdP(String valor27, String valor28, Map<String, Object> modelMap) {
		valor27 = SNum.Valida(SNum.FracValida(valor27));
		valor28 = SNum.Valida(SNum.FracValida(valor28));
		final String result = SNum.mdc(valor27, valor28);

		modelMap.put("valor27", valor27);
		modelMap.put("valor28", valor28);
		modelMap.put("valor29", result);
		modelMap.put("message", "M&#xe1;ximo divisor comum realizado com sucesso.");

		return "principal";
	}

	@PostMapping("/main/ln")
	public String lnE(String valor30, String valor31, Map<String, Object> modelMap) {
		valor30 = SNum.FracValida(valor30);
		valor31 = SNum.FracValida(valor31);
		final String result = SNum.FracLog("e", valor31, valor30);

		modelMap.put("valor30", valor30.replace("_", "/"));
		modelMap.put("valor31", valor31.replace("_", "/"));
		modelMap.put("valor32", result.replace("_", "/"));
		modelMap.put("message", "Natural Logarithm returned with success.");

		return "main";
	}

	@PostMapping("/principal/ln")
	public String lnP(String valor30, String valor31, Map<String, Object> modelMap) {
		valor30 = SNum.FracValida(valor30);
		valor31 = SNum.FracValida(valor31);
		final String result = SNum.FracLog("e", valor31, valor30);

		modelMap.put("valor30", valor30.replace("_", "/"));
		modelMap.put("valor31", valor31.replace("_", "/"));
		modelMap.put("valor32", result.replace("_", "/"));
		modelMap.put("message", "Logaritmo natural realizado com sucesso.");

		return "principal";
	}

	@PostMapping("/main/lcm")
	public String lcmE(String valor33, String valor34, Map<String, Object> modelMap) {
		valor33 = SNum.Valida(SNum.FracValida(valor33));
		valor34 = SNum.Valida(SNum.FracValida(valor34));
		final String result = SNum.mmc(valor33, valor34);

		modelMap.put("valor33", valor33);
		modelMap.put("valor34", valor34);
		modelMap.put("valor35", result);
		modelMap.put("message", "Least Common Multiple returned with success.");

		return "main";
	}

	@PostMapping("/principal/lcm")
	public String lcmP(String valor33, String valor34, Map<String, Object> modelMap) {
		valor33 = SNum.Valida(SNum.FracValida(valor33));
		valor34 = SNum.Valida(SNum.FracValida(valor34));
		final String result = SNum.mmc(valor33, valor34);

		modelMap.put("valor33", valor33);
		modelMap.put("valor34", valor34);
		modelMap.put("valor35", result);
		modelMap.put("message", "M&#xed;nimo m&#xfa;ltiplo comum realizado com sucesso.");

		return "principal";
	}

	@PostMapping("/main/carMichael")
	public String carMichaelE(String valor36, Map<String, Object> modelMap) {
		setLinguagem(false);
		return doubleCarMichael(valor36, modelMap, "main");
	}

	@PostMapping("/principal/carMichael")
	public String carMichaelP(String valor36, Map<String, Object> modelMap) {
		setLinguagem(true);
		return doubleCarMichael(valor36, modelMap, "principal");
	}

	private String doubleCarMichael(String valor36, Map<String, Object> modelMap, String webPage) {
		String modulo = SNum.Valida(SNum.FracValida(valor36));

		String Result;

		if (SNum.SNumCompare(modulo, "3") >= 0) {

			Result = sCarmichael + modulo + sReturned;

			String a = "2", x, n, sep = "\n";
			SFrac qr = new SFrac();

			while (SNum.SNumCompare(a, modulo) <= 0) {
				x = a;
				while (SNum.SNumCompare(x, modulo) <= 0) {
					qr = SNum.Divide(SNum.Multiplica(a, x), modulo);
					if (qr.d.equals("1")) {
						Result = Result + sep + a + "<sup>" + x + "</sup> &#x2261; 1 (mod " + modulo + ")";
						break;
					}
					x = SNum.Soma(x, "1");
				}
				a = SNum.Soma(a, "1");
			}

			a = "2";
			while (SNum.SNumCompare(a, modulo) < 0) {
				x = "1";
				n = "0";
				String todos = ";";
				do {
					qr = SNum.Divide(SNum.Multiplica(x, a), modulo);

					if (todos.contains(";" + qr.d + ";")) {
						todos = Util.delete(todos, todos.indexOf(";" + qr.d + ";") + 1, todos.length());

						String counter = "1";
						for (int i = 0; i < todos.length(); i++)
							if (todos.charAt(i) == ';')
								counter = SNum.Soma(counter, "1");

						if (counter.equals("1"))
							Result = Result + sep + a + "<sup>" + SNum.Soma(n, "1") + "</sup> &#x2261; " + qr.d
									+ " (mod " + modulo + ") &#x21d2; " + a + sIsCarmichael;
						else
							Result = Result + sep + a + "<sup>" + SNum.Soma(n, "1") + "</sup> &#x2261; " + a + "<sup>"
									+ counter + "</sup> (mod " + modulo + ")";
						break;
					}

					x = qr.d;
					todos = todos + x + ";";
					n = SNum.Soma(n, "1");
					if (x.equals("1") || x.equals("0")) {
						Result = Result + sep + a + "<sup>" + n + "</sup> &#x2261; " + x + " (mod " + modulo + ")";
						break;
					}
				} while (true);

				a = SNum.Soma(a, "1");
			}
		} else
			Result = sInvalid;

		modelMap.put("valor36", modulo);
		modelMap.put("message", Result);

		return webPage;
	}

	@PostMapping("/main/axby")
	public String axbyE(String valor37, String valor38, Map<String, Object> modelMap) {
		setLinguagem(false);
		return doubleAxby(valor37, valor38, modelMap, "main");
	}

	@PostMapping("/principal/axby")
	public String axbyP(String valor37, String valor38, Map<String, Object> modelMap) {
		setLinguagem(true);
		return doubleAxby(valor37, valor38, modelMap, "principal");
	}

	private String doubleAxby(String valor37, String valor38, Map<String, Object> modelMap, String webPage) {
		valor37 = SNum.Valida(SNum.FracValida(valor37));
		valor38 = SNum.Valida(SNum.FracValida(valor38));

		String Result, x = valor37, y = valor38, a = "", b = "", sep = "\n";
		SFrac qr = new SFrac();
		qr.d = "2";

		if (x.equals("0") || y.equals("0"))
			Result = sInput;
		else {
			ArrayList<String> memox = new ArrayList<String>();
			ArrayList<String> memoy = new ArrayList<String>();

			if (x.charAt(0) == '-')
				x = SNum.SNumOposto(x);
			if (y.charAt(0) == '-')
				y = SNum.SNumOposto(y);
			if (SNum.SNumCompare(y, x) > 0) {
				qr.n = x;
				x = y;
				y = qr.n;
			}

			valor37 = x;
			valor38 = y;

			Result = "ax + by = 1 " + sReturned + sep + "x = " + x + sep + "y = " + y;

			do {
				qr = SNum.Divide(x, y);
				if (!qr.d.equals("0") || memox.isEmpty()) {
					if (memox.isEmpty()) {
						a = "1";
						b = SNum.SNumOposto(qr.n);
					} else if (memox.size() == 1) {
						a = SNum.Multiplica(SNum.SNumOposto(a), qr.n);
						b = SNum.Soma(SNum.Multiplica(SNum.SNumOposto(b), qr.n), "1");
					} else {
						a = SNum.Subtrai(memox.get(memox.size() - 2), SNum.Multiplica(a, qr.n));
						b = SNum.Subtrai(memoy.get(memoy.size() - 2), SNum.Multiplica(b, qr.n));
					}

					memox.add(a);
					memoy.add(b);
					if (b.charAt(0) != '-')
						Result = Result + sep + qr.d + " = " + x + " - " + qr.n + " &#x22C5; " + y + " = " + a + " x + "
								+ b + " y";
					else
						Result = Result + sep + qr.d + " = " + x + " - " + qr.n + " &#x22C5;  " + y + " = " + a
								+ " x - " + SNum.SNumOposto(b) + " y";
				}
				if (qr.d.equals("1") || qr.d.equals("0"))
					break;
				x = y;
				y = qr.d;
			} while (true);
		}

		qr.n = SNum.FracDiv(valor37, valor38);

		if (qr.n.contains("_")) {
			if (qr.d.equals("1")) {
				x = valor37;
				y = valor38;
			} else {
				x = SNum.FracDiv(valor37, y);
				y = SNum.FracDiv(valor38, y);
				if (b.charAt(0) != '-')
					Result = Result + sep + "1 = " + a + " &#x22C5; " + x + " + " + b + " &#x22C5;  " + y;
				else
					Result = Result + sep + "1 = " + a + " &#x22C5; " + x + " - " + SNum.SNumOposto(b) + " &#x22C5;  "
							+ y;
			}

			String alinha = a, blinha = b;
			if (alinha.charAt(0) == '-') {
				qr = SNum.Divide(alinha, SNum.SNumAbs(b));
				alinha = qr.d;
			}
			if (blinha.charAt(0) == '-') {
				qr = SNum.Divide(blinha, SNum.SNumAbs(a));
				blinha = qr.d;
			}
			if (!alinha.equals("1"))
				alinha = alinha + "<sup>-1</sup>";
			if (!blinha.equals("1"))
				blinha = blinha + "<sup>-1</sup>";
			if (!SNum.SNumAbs(b).equals("1"))
				Result = Result + sep + x + " &#x2261; " + alinha + " (mod " + SNum.SNumAbs(b) + ")";
			if (!SNum.SNumAbs(a).equals("1"))
				Result = Result + sep + y + " &#x2261; " + blinha + " (mod " + SNum.SNumAbs(a) + ")";

			if (a.charAt(0) == '-')
				a = SNum.Soma(a, y);
			if (b.charAt(0) == '-')
				b = SNum.Soma(b, x);
			if (!a.equals("1"))
				a = a + "<sup>-1</sup>";
			if (!b.equals("1"))
				b = b + "<sup>-1</sup>";
			Result = Result + sep + x + " &#x2261; " + a + " (mod " + y + ")";
			Result = Result + sep + y + " &#x2261; " + b + " (mod " + x + ")";
		}

		modelMap.put("valor37", valor37);
		modelMap.put("valor38", valor38);
		modelMap.put("message", Result.replace("-", "- "));
		return webPage;
	}

	@PostMapping("/main/fracExp")
	public String fracExpE(String valor39, String valor40, Map<String, Object> modelMap) {
		valor39 = SNum.FracValida(valor39);
		valor40 = SNum.FracValida(valor40);
		final String result = SNum.FracExp(valor40, valor39);

		modelMap.put("valor39", valor39.replace("_", "/"));
		modelMap.put("valor40", valor40.replace("_", "/"));
		modelMap.put("valor41", result.replace("_", "/"));
		modelMap.put("message", "Exponential returned with success.");

		return "main";
	}

	@PostMapping("/principal/fracExp")
	public String fracExpP(String valor39, String valor40, Map<String, Object> modelMap) {
		valor39 = SNum.FracValida(valor39);
		valor40 = SNum.FracValida(valor40);
		final String result = SNum.FracExp(valor40, valor39);

		modelMap.put("valor39", valor39.replace("_", "/"));
		modelMap.put("valor40", valor40.replace("_", "/"));
		modelMap.put("valor41", result.replace("_", "/"));
		modelMap.put("message", "Exponencial realizada com sucesso.");

		return "principal";
	}

	@PostMapping("/main/powerWithError")
	public String powerWithErrorE(String valor42, String valor43, String valor44, Map<String, Object> modelMap) {
		valor42 = SNum.FracValida(valor42);
		valor43 = SNum.FracValida(valor43);
		valor44 = SNum.FracValida(valor44);
		String a = valor42, b = valor43, erro = valor44, result = "0";

		if (SNum.FracCompare(a, "0") > 0)
			if (SNum.FracCompare(erro, "0") > 0) {
				erro = SNum.FracDiv(erro, "500");
				result = SNum.FracExp(erro, SNum.FracMul(b, SNum.ln(erro, a)));
			}

		modelMap.put("valor42", valor42.replace("_", "/"));
		modelMap.put("valor43", valor43.replace("_", "/"));
		modelMap.put("valor44", valor44.replace("_", "/"));
		modelMap.put("valor45", result.replace("_", "/"));
		modelMap.put("message", "Power with error returned with success.");

		return "main";
	}

	@PostMapping("/principal/powerWithError")
	public String powerWithErrorP(String valor42, String valor43, String valor44, Map<String, Object> modelMap) {
		valor42 = SNum.FracValida(valor42);
		valor43 = SNum.FracValida(valor43);
		valor44 = SNum.FracValida(valor44);
		String a = valor42, b = valor43, erro = valor44, result = "0";

		if (SNum.FracCompare(a, "0") > 0)
			if (SNum.FracCompare(erro, "0") > 0) {
				erro = SNum.FracDiv(erro, "500");
				result = SNum.FracExp(erro, SNum.FracMul(b, SNum.ln(erro, a)));
			}

		modelMap.put("valor42", valor42.replace("_", "/"));
		modelMap.put("valor43", valor43.replace("_", "/"));
		modelMap.put("valor44", valor44.replace("_", "/"));
		modelMap.put("valor45", result.replace("_", "/"));
		modelMap.put("message", "Pot&#xea;ncia com erro realizada com sucesso.");

		return "principal";
	}

	@PostMapping("/main/orderModulo")
	public String orderModuloE(String valor46, String valor47, Map<String, Object> modelMap) {
		setLinguagem(false);
		return doubleOrderModulo(valor46, valor47, modelMap, "main");
	}

	@PostMapping("/principal/orderModulo")
	public String orderModuloP(String valor46, String valor47, Map<String, Object> modelMap) {
		setLinguagem(true);
		return doubleOrderModulo(valor46, valor47, modelMap, "principal");
	}

	private String doubleOrderModulo(String valor46, String valor47, Map<String, Object> modelMap, String webPage) {
		valor46 = SNum.Valida(SNum.FracValida(valor46));
		valor47 = SNum.Valida(SNum.FracValida(valor47));

		// (SNum.SNumCompare(a, modulo) < 0) {

		String a = valor46, modulo = valor47, Result = sOrderSuccess;

		if (SNum.SNumCompare(modulo, "3") >= 0) {

			SFrac qr = new SFrac();

			if ((SNum.SNumCompare(a, modulo) >= 0) || (a.charAt(0) == '-')) {
				qr = SNum.Divide(a, modulo);
				a = qr.d;
			}

			if ((!a.equals("0")) && (!a.equals("1"))) {

				String x = "1", n = "0", todos = ";";

				do {
					qr = SNum.Divide(SNum.Multiplica(x, a), modulo);

					if (todos.contains(";" + qr.d + ";")) {
						todos = Util.delete(todos, todos.indexOf(";" + qr.d + ";") + 1, todos.length());

						String counter = "1";
						for (int i = 0; i < todos.length(); i++)
							if (todos.charAt(i) == ';')
								counter = SNum.Soma(counter, "1");

						if (counter.equals("1"))
							Result = Result + "\n" + a + "<sup>" + SNum.Soma(n, "1") + "</sup> &#x2261; " + qr.d
									+ " (mod " + modulo + ") &#x21d2; " + a + sIsCarmichael;
						else
							Result = Result + "\n" + a + "<sup>" + SNum.Soma(n, "1") + "</sup> &#x2261; " + a + "<sup>"
									+ counter + "</sup> (mod " + modulo + ")";
						break;
					}

					x = qr.d;
					todos = todos + x + ";";
					n = SNum.Soma(n, "1");
					if (x.equals("1") || x.equals("0")) {
						Result = Result + "\n" + a + "<sup>" + n + "</sup> &#x2261; " + x + " (mod " + modulo + ")";
						break;
					}
				} while (true);
			}
		}

		modelMap.put("valor46", a);
		modelMap.put("valor47", modulo);
		modelMap.put("message", Result);

		return webPage;
	}

	@PostMapping("/main/command")
	public String commandE(String valor49, Map<String, Object> modelMap) {
		final String result = Lambda.CommandProcess(valor49);

		modelMap.put("valor49", valor49);
		modelMap.put("message", "Command returned:\n" + result);

		return "main";
	}

	@PostMapping("/principal/command")
	public String commandP(String valor49, Map<String, Object> modelMap) {
		final String result = Lambda.CommandProcess(valor49);

		modelMap.put("valor49", valor49);
		modelMap.put("message", "Comando retornou:\n" + result);

		return "principal";
	}

	@PostMapping("/main/increment")
	public String incrementE(String valor50, String valor51, String valor52, String valor53, String valor54,
			String valor55, Map<String, Object> modelMap) {
		setLinguagem(false);
		return doubleIncrement(valor50, valor51, valor52, valor53, valor54, valor55, modelMap, "main");
	}

	@PostMapping("/principal/increment")
	public String incrementP(String valor50, String valor51, String valor52, String valor53, String valor54,
			String valor55, Map<String, Object> modelMap) {
		setLinguagem(true);
		return doubleIncrement(valor50, valor51, valor52, valor53, valor54, valor55, modelMap, "principal");
	}

	private String doubleIncrement(String valor50, String valor51, String valor52, String valor53, String valor54,
			String valor55, Map<String, Object> modelMap, String webPage) {
		valor50 = SNum.Valida(SNum.FracValida(valor50));
		valor51 = SNum.Valida(SNum.FracValida(valor51));

		boolean co_prime;
		int halfMode;
		if (valor52.equals("1"))
			co_prime = true;
		else if (valor52.equals("2"))
			co_prime = false;
		else
			return webPage;

		if (valor53.equals("1"))
			halfMode = SFrac.halfYPositive;
		else if (valor53.equals("2"))
			halfMode = SFrac.halfYNegative;
		else if (valor53.equals("3"))
			halfMode = SFrac.halfXPositive;
		else if (valor53.equals("4"))
			halfMode = SFrac.halfXNegative;
		else if (valor53.equals("5"))
			halfMode = SFrac.halfAll;
		else
			return webPage;

		valor54 = SNum.SNumAbs(SNum.Valida(SNum.FracValida(valor54)));
		valor55 = SNum.SNumAbs(SNum.Valida(SNum.FracValida(valor55)));
		if (valor54.equals("0") || valor55.equals("0"))
			return webPage;

		SFrac s = new SFrac();
		s.n = valor50;
		s.d = valor51;

		String times = valor55;
		String Result = "";

		while (SNum.SNumCompare(times, "0") > 0) {
			s = SFrac.Incrementar(s.n, s.d, co_prime, halfMode, valor54);
			Result = Result + "\n" + s.n + "/" + s.d;
			times = SNum.Subtrai(times, "1");
		}

		modelMap.put("valor50", valor50);
		modelMap.put("valor51", valor51);
		modelMap.put("valor52", valor52);
		modelMap.put("valor53", valor53);
		modelMap.put("valor54", valor54);
		modelMap.put("valor55", valor55);
		modelMap.put("message", sIncrement + Result);

		return webPage;
	}

	@RequestMapping("/bayes_pt/abrir")
	public String bayesPT(HttpSession session, final Map<String, Object> modelMap) {
		modelMap.put("message", "Esta vers&#xe3;o ordena as linhas pelo valor ascendente da ultima coluna.\n"
				+ "Esta vers&#xe3;o est&#xe1; aparentemente pronta para 2 classes de 3 colunas, qualquer numero de linhas.\n"
				+ "Matriz de fracoes: m&#xe1;ximo de " + MyTask.MAXYV + " x " + MyTask.MAXXV + ".\n");
		modelMap.put("valor1",
				"100\n" + "3\n1\n" + "-0.192805544573921 -0.351325794146206 2\n"
						+ "0.40665525234054 -0.4520715560576 2\n" + "0.311256674442092 0.0070272187789895 1\n"
						+ "0.184843841998495 0.797668241348402 2\n" + "0.0645991964427388 -0.505947077153015 2\n"
						+ "0.314224124955703 0.0103969570547945 1\n" + "0.412951406041742 -0.0137763286294225 1\n"
						+ "0.302023386281764 0.0223084316228358 1\n" + "0.325798745309398 0.0202369421266919 1\n"
						+ "0.382817253233042 0.601622214305743 2\n" + "-0.584226402798737 0.752769089584917 2\n"
						+ "0.31508629692153 0.0272726537077652 1\n" + "0.327438359391679 0.0286831765256553 1\n"
						+ "-0.722557617172174 0.488963772585569 2\n" + "0.392845041452894 0.0190015686781646 1\n"
						+ "-0.121091596266242 -0.465083239758139 2\n" + "-0.1954325742675 -0.413235188565172 2\n"
						+ "0.409700000715483 0.0209490106802716 1\n" + "-0.268431307779805 -0.340047792774881 2\n"
						+ "0.402077162249264 0.0279413803883962 1\n" + "0.685242046809627 0.238200639405632 2\n"
						+ "0.615701761217569 -0.148506075247666 2\n" + "0.346110113261138 0.043072128265292 1\n"
						+ "0.407128654418735 0.0380197939776961 1\n" + "0.339913705447729 0.0532702880944421 1\n"
						+ "-0.835448238638803 0.460205801107877 2\n" + "0.357523242985189 0.0555192960237242 1\n"
						+ "-0.328807839739094 -0.108139662796718 2\n" + "-0.238769841937948 -0.243574681075663 2\n"
						+ "0.37853062054262 -0.369352762980949 2\n" + "-0.291227220756589 -0.152899024648948 2\n"
						+ "-0.231441585502959 -0.4379655752019 2\n" + "0.325917802722758 0.0640317423879507 1\n"
						+ "0.419475509586452 0.0587075224875067 1\n" + "0.338226209004982 0.0716658601085556 1\n"
						+ "0.423152185234481 0.0697424676149397 1\n" + "0.696254443557092 0.111446066884336 2\n"
						+ "0.564426429819252 0.457360753436338 2\n" + "0.267479267530895 0.0851884423068514 1\n"
						+ "0.662802741201987 0.0516238824337915 2\n" + "0.348200182206664 0.0848385732093748 1\n"
						+ "0.326228120772782 0.0903213391664319 1\n" + "0.28726810807837 0.0955880391488078 1\n"
						+ "0.752996079500525 0.220587350604339 2\n" + "-102.095.721.232.552 0.201439518298095 2\n"
						+ "-0.150408505331764 0.863596642715041 2\n" + "0.137353232911758 0.753238877139628 2\n"
						+ "0.342779848864533 0.0990404781980364 1\n" + "-0.404960134640249 0.694857971141751 2\n"
						+ "0.671288080625118 -0.16261596892458 2\n" + "-0.356667408561473 0.813475473169622 2\n"
						+ "-0.329209616012092 -0.0548232899432868 2\n" + "-0.11116104510333 -0.458979369061473 2\n"
						+ "0.654147856846073 0.153497830091246 2\n" + "0.443219116574298 0.104255656802148 1\n"
						+ "0.647815769722224 0.258000939620565 2\n" + "-0.393391218866174 -0.223621676744052 2\n"
						+ "-101.705.281.644.563 0.186583247742008 2\n" + "-0.343390150299188 -0.171846591632672 2\n"
						+ "0.325905675869956 0.108084689097673 1\n" + "0.349262173905614 0.113323824145621 1\n"
						+ "0.517889499391597 0.515173246429049 2\n" + "0.34268524547189 0.117838013419732 1\n"
						+ "-0.0507571474372205 0.869931052206538 2\n" + "0.0826597684383362 -0.54838979379675 2\n"
						+ "0.373002811005681 0.124395277268758 1\n" + "0.348734628532299 0.127804535569536 1\n"
						+ "0.278456166348009 0.126586418119535 1\n" + "0.367438453835085 0.139473946439551 1\n"
						+ "0.125627379959525 -0.545543150310386 2\n" + "0.19934433835479 -0.43790412775118 2\n"
						+ "0.303687648298724 0.137395601016884 1\n" + "0.0545578005871206 -0.476510970868176 2\n"
						+ "0.330710688751923 0.145201997700936 1\n" + "0.317650541824102 0.148110150967457 1\n"
						+ "0.330148465063194 0.154661868832019 1\n" + "0.410384403932518 0.173051341149114 1\n"
						+ "0.386215931323506 0.174600833748906 1\n" + "0.357512845958663 0.174628291233861 1\n"
						+ "0.403758394087202 0.189710534083391 1\n" + "0.746321754919792 0.150574318214847 2\n"
						+ "-0.282546341596202 -0.374134819546578 2\n" + "0.0604105839928038 -0.480005580497233 2\n"
						+ "0.354612172772311 0.184672207031995 1\n" + "0.36178297222909 0.191767680138469 1\n"
						+ "0.354527872583498 0.19546176487933 1\n" + "0.660440247346529 0.421240742399967 2\n"
						+ "0.312616125214513 0.189718643340115 1\n" + "0.284811045304133 -0.434441270997291 2\n"
						+ "0.40769154997382 0.221494414087259 1\n" + "-0.278777353442363 -0.326849854810398 2\n"
						+ "0.326736792535935 0.20383399333419 1\n" + "0.556898507180398 -0.401502221181773 2\n"
						+ "-0.0119256193737206 -0.523674759377896 2\n" + "0.300190532281521 -0.374963307370614 2\n"
						+ "0.382566393602693 0.226479783973756 1\n" + "0.760056411942736 -0.114862854060395 2\n"
						+ "0.241996758700624 0.186749282593854 1\n" + "0.160171802342895 0.162944017010882 1\n"
						+ "0.310185998540363 0.219327500297501 1\n" + "-9/10\n" + "9/10\n" + "1/5\n" + "-9/10\n"
						+ "9/10\n" + "1/5\n");
		modelMap.put("valor2",
				"309\n" + "7\n" + "30\n" + "1\n" + "2\n"
						+ "63.0278175 22.55258597 39.60911701 40.47523153 98.67291675 -0.254399986 2\n"
						+ "39.05695098 10.06099147 25.01537822 28.99595951 114.4054254 4.564258645 2\n"
						+ "68.83202098 22.21848205 50.09219357 46.61353893 105.9851355 -3.530317314 2\n"
						+ "69.29700807 24.65287791 44.31123813 44.64413017 101.8684951 11.21152344 2\n"
						+ "49.71285934 9.652074879 28.317406 40.06078446 108.1687249 7.918500615 2\n"
						+ "40.25019968 13.92190658 25.1249496 26.32829311 130.3278713 2.230651729 2\n"
						+ "53.43292815 15.86433612 37.16593387 37.56859203 120.5675233 5.988550702 2\n"
						+ "45.36675362 10.75561143 29.03834896 34.61114218 117.2700675 -10.67587083 2\n"
						+ "43.79019026 13.5337531 42.69081398 30.25643716 125.0028927 13.28901817 2\n"
						+ "36.68635286 5.010884121 41.9487509 31.67546874 84.24141517 0.664437117 2\n"
						+ "49.70660953 13.04097405 31.33450009 36.66563548 108.6482654 -7.825985755 2\n"
						+ "31.23238734 17.71581923 15.5 13.51656811 120.0553988 0.499751446 2\n"
						+ "48.91555137 19.96455616 40.26379358 28.95099521 119.321358 8.028894629 2\n"
						+ "53.5721702 20.46082824 33.1 33.11134196 110.9666978 7.044802938 2\n"
						+ "57.30022656 24.1888846 46.99999999 33.11134196 116.8065868 5.766946943 2\n"
						+ "44.31890674 12.53799164 36.098763 31.78091509 124.1158358 5.415825143 2\n"
						+ "63.83498162 20.36250706 54.55243367 43.47247456 112.3094915 -0.622526643 2\n"
						+ "31.27601184 3.14466948 32.56299592 28.13134236 129.0114183 3.623020073 2\n"
						+ "38.69791243 13.44474904 31 25.25316339 123.1592507 1.429185758 2\n"
						+ "41.72996308 12.25407408 30.12258646 29.475889 116.5857056 -1.244402488 2\n"
						+ "43.92283983 14.17795853 37.8325467 29.7448813 134.4610156 6.451647637 2\n"
						+ "54.91944259 21.06233245 42.19999999 33.85711014 125.2127163 2.432561437 2\n"
						+ "63.07361096 24.41380271 53.99999999 38.65980825 106.4243295 15.77969683 2\n"
						+ "45.54078988 13.06959759 30.29832059 32.47119229 117.9808303 -4.987129618 2\n"
						+ "36.12568347 22.75875277 29 13.3669307 115.5771163 -3.237562489 2\n"
						+ "54.12492019 26.65048856 35.32974693 27.47443163 121.447011 1.571204816 2\n"
						+ "26.14792141 10.75945357 14 15.38846783 125.2032956 -10.09310817 2\n"
						+ "43.58096394 16.5088837 46.99999999 27.07208024 109.271634 8.992815727 2\n"
						+ "44.5510115 21.93114655 26.78591597 22.61986495 111.0729197 2.652320636 2\n"
						+ "66.87921138 24.89199889 49.27859673 41.9872125 113.4770183 -2.005891748 2\n"
						+ "50.81926781 15.40221253 42.52893886 35.41705528 112.192804 10.86956554 2\n"
						+ "46.39026008 11.07904664 32.13655345 35.31121344 98.77454633 6.386831648 2\n"
						+ "44.93667457 17.44383762 27.78057555 27.49283695 117.9803245 5.569619587 2\n"
						+ "38.66325708 12.98644139 39.99999999 25.67681568 124.914118 2.703008052 2\n"
						+ "59.59554032 31.99824445 46.56025198 27.59729587 119.3303537 1.474285836 2\n"
						+ "31.48421834 7.82622134 24.28481815 23.657997 113.8331446 4.393080498 2\n"
						+ "32.09098679 6.989378081 35.99819848 25.10160871 132.264735 6.413427708 2\n"
						+ "35.70345781 19.44325311 20.7 16.26020471 137.5406125 -0.263489651 2\n"
						+ "55.84328595 28.84744756 47.69054322 26.99583839 123.3118449 2.812426855 2\n"
						+ "52.41938511 19.01156052 35.87265953 33.40782459 116.5597709 1.694705102 2\n"
						+ "35.49244617 11.7016723 15.59036345 23.79077387 106.9388517 -3.460357991 2\n"
						+ "46.44207842 8.39503589 29.0372302 38.04704253 115.4814047 2.045475795 2\n"
						+ "53.85479842 19.23064334 32.77905978 34.62415508 121.6709148 5.329843204 2\n"
						+ "66.28539377 26.32784484 47.49999999 39.95754893 121.2196839 -0.799624469 2\n"
						+ "56.03021778 16.2979149 62.27527456 39.73230287 114.0231172 -2.325683841 2\n"
						+ "50.91244034 23.01516931 46.99999999 27.89727103 117.4222591 -2.526701511 2\n"
						+ "48.332638 22.22778399 36.18199318 26.10485401 117.3846251 6.481709096 2\n"
						+ "41.35250407 16.57736351 30.70619135 24.77514057 113.2666746 -4.497957556 2\n"
						+ "40.55735663 17.97778407 34 22.57957256 121.0462458 -1.537383074 2\n"
						+ "41.76773173 17.89940172 20.0308863 23.86833001 118.3633889 2.062962549 2\n"
						+ "55.28585178 20.44011836 34 34.84573342 115.8770174 3.558372358 2\n"
						+ "74.43359316 41.55733141 27.7 32.87626175 107.9493045 5.000088788 2\n"
						+ "50.20966979 29.76012218 36.10400731 20.44954761 128.2925148 5.740614083 2\n"
						+ "30.14993632 11.91744524 34 18.23249108 112.6841408 11.46322327 2\n"
						+ "41.17167989 17.32120599 33.46940277 23.85047391 116.3778894 -9.569249858 2\n"
						+ "47.65772963 13.27738491 36.67998541 34.38034472 98.24978071 6.273012173 2\n"
						+ "43.34960621 7.467468964 28.06548279 35.88213725 112.7761866 5.753277458 2\n"
						+ "46.85578065 15.35151393 38 31.50426672 116.2509174 1.662705589 2\n"
						+ "43.20318499 19.66314572 35 23.54003927 124.8461088 -2.919075955 2\n"
						+ "48.10923638 14.93072472 35.56468278 33.17851166 124.0564518 7.947904861 2\n"
						+ "74.37767772 32.05310438 78.77201304 42.32457334 143.5606905 56.12590603 2\n"
						+ "89.68056731 32.70443487 83.13073216 56.97613244 129.9554764 92.02727682 2\n"
						+ "44.529051 9.433234213 51.99999999 35.09581679 134.7117723 29.10657504 2\n"
						+ "77.69057712 21.38064464 64.42944191 56.30993248 114.818751 26.93184095 2\n"
						+ "76.1472121 21.93618556 82.96150249 54.21102654 123.9320096 10.43197194 2\n"
						+ "83.93300857 41.28630543 61.99999999 42.64670314 115.012334 26.58810016 2\n"
						+ "78.49173027 22.1817978 59.99999999 56.30993248 118.5303266 27.38321314 2\n"
						+ "75.64973136 19.33979889 64.14868477 56.30993248 95.9036288 69.55130292 2\n"
						+ "72.07627839 18.94617604 50.99999999 53.13010236 114.2130126 1.01004051 2\n"
						+ "58.59952852 -0.261499046 51.49999999 58.86102756 102.0428116 28.05969711 2\n"
						+ "72.56070163 17.38519079 51.99999999 55.17551084 119.1937238 32.10853735 2\n"
						+ "86.90079431 32.9281677 47.79434664 53.97262661 135.0753635 101.7190919 2\n"
						+ "84.97413208 33.02117462 60.85987263 51.95295747 125.6595336 74.33340864 2\n"
						+ "55.512212 20.09515673 43.99999999 35.41705528 122.648753 34.55294641 2\n"
						+ "72.2223343 23.07771056 90.99999999 49.14462374 137.7366546 56.80409277 2\n"
						+ "70.22145219 39.82272448 68.11840309 30.39872771 148.5255624 145.3781432 2\n"
						+ "86.75360946 36.04301632 69.22104479 50.71059314 139.414504 110.8607824 2\n"
						+ "58.78254775 7.667044186 53.33894082 51.11550357 98.50115697 51.58412476 2\n"
						+ "67.41253785 17.44279712 60.14464036 49.96974073 111.12397 33.15764573 2\n"
						+ "47.74467877 12.08935067 38.99999999 35.6553281 117.5120039 21.68240136 2\n"
						+ "77.10657122 30.46999418 69.48062839 46.63657704 112.1516 70.75908308 2\n"
						+ "74.00554124 21.12240192 57.37950226 52.88313932 120.2059626 74.55516588 2\n"
						+ "88.62390839 29.08945331 47.56426247 59.53445508 121.7647796 51.80589921 2\n"
						+ "81.10410039 24.79416792 77.88702048 56.30993247 151.8398566 65.21461611 2\n"
						+ "76.32600187 42.39620445 57.19999999 33.92979742 124.267007 50.12745689 2\n"
						+ "45.44374959 9.906071798 44.99999999 35.53767779 163.0710405 20.31531532 2\n"
						+ "59.78526526 17.87932332 59.20646143 41.90594194 119.3191109 22.12386874 2\n"
						+ "44.91414916 10.21899563 44.63091389 34.69515353 130.0756599 37.36453993 2\n"
						+ "56.60577127 16.80020017 41.99999999 39.80557109 127.2945222 24.0185747 2\n"
						+ "71.18681115 23.89620111 43.6966651 47.29061004 119.8649383 27.28398451 2\n"
						+ "81.65603206 28.74886935 58.23282055 52.9071627 114.7698556 30.60914842 2\n"
						+ "70.95272771 20.15993121 62.85910914 50.7927965 116.1779325 32.522331 2\n"
						+ "85.35231529 15.84491006 71.66865979 69.50740523 124.4197875 76.0206034 2\n"
						+ "58.10193455 14.83763914 79.64983825 43.26429541 113.5876551 50.23787808 2\n"
						+ "94.17482232 15.38076983 67.70572132 78.79405249 114.8901128 53.25522004 2\n"
						+ "57.52235608 33.64707522 50.90985841 23.87528085 140.9817119 148.7537109 2\n"
						+ "96.65731511 19.46158117 90.21149828 77.19573393 120.6730408 64.08099841 2\n"
						+ "74.72074622 19.75694203 82.73535954 54.96380419 109.3565941 33.30606685 2\n"
						+ "77.65511874 22.4329501 93.89277881 55.22216863 123.0557067 61.2111866 2\n"
						+ "58.52162283 13.92228609 41.46785522 44.59933674 115.514798 30.3879839 2\n"
						+ "84.5856071 30.36168482 65.47948563 54.22392228 108.0102185 25.11847846 2\n"
						+ "79.93857026 18.7740711 63.31183486 61.16449915 114.787107 38.53874133 2\n"
						+ "70.39930842 13.46998624 61.19999999 56.92932218 102.3375244 25.53842852 2\n"
						+ "49.78212054 6.46680486 52.99999999 43.31531568 110.8647831 25.33564729 2\n"
						+ "77.40933294 29.39654543 63.23230243 48.0127875 118.4507311 93.56373734 2\n"
						+ "65.00796426 27.60260762 50.94751899 37.40535663 116.5811088 7.015977884 2\n"
						+ "65.01377322 9.838262375 57.73583722 55.17551084 94.73852542 49.69695462 2\n"
						+ "78.42595126 33.42595126 76.27743927 45 138.5541111 77.15517241 2\n"
						+ "63.17298709 6.330910974 62.99999999 56.84207612 110.6440206 42.60807567 2\n"
						+ "68.61300092 15.0822353 63.01469619 53.53076561 123.4311742 39.49798659 2\n"
						+ "63.90063261 13.7062037 62.12433389 50.19442891 114.1292425 41.42282844 2\n"
						+ "84.99895554 29.61009772 83.35219438 55.38885782 126.9129899 71.32117542 2\n"
						+ "42.02138603 -6.554948347 67.89999999 48.57633437 111.5857819 27.33867086 2\n"
						+ "69.75666532 19.27929659 48.49999999 50.47736873 96.49136982 51.1696403 2\n"
						+ "80.98807441 36.84317181 86.96060151 44.1449026 141.0881494 85.87215224 2\n"
						+ "129.8340406 8.404475005 48.38405705 121.4295656 107.690466 418.5430821 2\n"
						+ "70.48410444 12.48948765 62.41714208 57.99461679 114.1900488 56.90244779 2\n"
						+ "86.04127982 38.75066978 47.87140494 47.29061004 122.0929536 61.98827709 2\n"
						+ "65.53600255 24.15748726 45.77516991 41.3785153 136.4403015 16.37808564 2\n"
						+ "60.7538935 15.7538935 43.19915768 45 113.0533309 31.69354839 2\n"
						+ "54.74177518 12.09507205 40.99999999 42.64670314 117.6432188 40.3823266 2\n"
						+ "83.87994081 23.07742686 87.14151223 60.80251395 124.6460723 80.55560527 2\n"
						+ "80.07491418 48.06953097 52.40343873 32.00538321 110.7099121 67.72731595 2\n"
						+ "65.66534698 10.54067533 56.48913545 55.12467166 109.1627768 53.93202006 2\n"
						+ "74.71722805 14.32167879 32.5 60.39554926 107.1822176 37.01708012 2\n"
						+ "48.06062649 5.687032126 57.05716117 42.37359436 95.44375749 32.83587702 2\n"
						+ "70.67689818 21.70440224 59.18116082 48.97249594 103.0083545 27.8101478 2\n"
						+ "80.43342782 16.998479 66.53601753 63.43494882 116.4389807 57.78125 2\n"
						+ "90.51396072 28.27250132 69.8139423 62.2414594 100.8921596 58.82364821 2\n"
						+ "77.23689752 16.73762214 49.77553438 60.49927538 110.6903772 39.7871542 2\n"
						+ "50.06678595 9.120340183 32.16846267 40.94644577 99.71245318 26.76669655 2\n"
						+ "69.78100617 13.77746531 57.99999999 56.00354085 118.9306656 17.91456046 2\n"
						+ "69.62628302 21.12275138 52.76659472 48.50353164 116.8030913 54.81686729 2\n"
						+ "81.75441933 20.12346562 70.56044038 61.63095371 119.4250857 55.50688907 2\n"
						+ "52.20469309 17.21267289 78.09496877 34.9920202 136.9725168 54.93913416 2\n"
						+ "77.12134424 30.3498745 77.48108264 46.77146974 110.6111484 82.09360704 2\n"
						+ "88.0244989 39.84466878 81.77447308 48.17983012 116.6015376 56.76608323 2\n"
						+ "83.39660609 34.31098931 78.42329287 49.08561678 110.4665164 49.67209559 2\n"
						+ "72.05403412 24.70073725 79.87401586 47.35329687 107.1723576 56.42615873 2\n"
						+ "85.09550254 21.06989651 91.73479193 64.02560604 109.062312 38.03283108 2\n"
						+ "69.56348614 15.4011391 74.43849743 54.16234705 105.0673556 29.70121083 2\n"
						+ "89.5049473 48.90365265 72.0034229 40.60129465 134.6342912 118.3533701 2\n"
						+ "85.29017283 18.27888963 100.7442198 67.0112832 110.6607005 58.88494802 2\n"
						+ "60.62621697 20.5959577 64.53526221 40.03025927 117.2255542 104.8592474 2\n"
						+ "60.04417717 14.30965614 58.03886519 45.73452103 105.1316639 30.40913315 2\n"
						+ "85.64378664 42.68919513 78.7506635 42.95459151 105.1440758 42.88742577 2\n"
						+ "85.58171024 30.45703858 78.23137949 55.12467166 114.8660487 68.37612182 2\n"
						+ "55.08076562 -3.759929872 55.99999999 58.84069549 109.9153669 31.77358318 2\n"
						+ "65.75567895 9.832874231 50.82289501 55.92280472 104.3949585 39.30721246 2\n"
						+ "79.24967118 23.94482471 40.79669829 55.30484647 98.62251165 36.7063954 2\n"
						+ "81.11260488 20.69044356 60.68700588 60.42216132 94.01878339 40.51098228 2\n"
						+ "48.0306238 3.969814743 58.34451924 44.06080905 125.3509625 35.00007784 2\n"
						+ "63.40448058 14.11532726 48.13680562 49.28915333 111.9160075 31.78449499 2\n"
						+ "57.28694488 15.1493501 63.99999999 42.13759477 116.7353868 30.34120327 2\n"
						+ "41.18776972 5.792973871 42.86739151 35.39479584 103.3488802 27.66027669 2\n"
						+ "66.80479632 14.55160171 72.08491177 52.25319461 82.45603817 41.6854736 2\n"
						+ "79.4769781 26.73226755 70.65098189 52.74471055 118.5886691 61.70059824 2\n"
						+ "44.21646446 1.507074501 46.11033909 42.70938996 108.6295666 42.81048066 2\n"
						+ "57.03509717 0.34572799 49.19800263 56.68936918 103.0486975 52.16514503 2\n"
						+ "64.27481758 12.50864276 68.70237672 51.76617482 95.25245421 39.40982612 2\n"
						+ "92.02630795 35.39267395 77.41696348 56.633634 115.72353 58.05754155 2\n"
						+ "67.26314926 7.194661096 51.69688681 60.06848816 97.8010854 42.13694325 2\n"
						+ "118.1446548 38.44950127 50.83851954 79.69515353 81.0245406 74.04376736 2\n"
						+ "115.9232606 37.51543601 76.79999999 78.40782459 104.6986033 81.19892712 2\n"
						+ "53.94165809 9.306594428 43.10049819 44.63506366 124.3978211 25.0821266 2\n"
						+ "83.7031774 20.26822858 77.1105979 63.43494882 125.4801739 69.279571 2\n"
						+ "56.99140382 6.87408897 57.00900516 50.11731485 109.978045 36.81011057 2\n"
						+ "72.34359434 16.42078962 59.86901238 55.92280472 70.08257486 12.07264427 2\n"
						+ "95.38259648 24.82263131 95.15763273 70.55996517 89.3075466 57.66084135 2\n"
						+ "44.25347645 1.101086714 38 43.15238973 98.27410705 23.9106354 2\n"
						+ "64.80954139 15.17407796 58.83999352 49.63546343 111.679961 21.40719845 2\n"
						+ "78.40125389 14.04225971 79.69426258 64.35899418 104.7312342 12.39285327 2\n"
						+ "56.66829282 13.45820343 43.76970978 43.21008939 93.69220863 21.10812135 2\n"
						+ "50.82502875 9.064729049 56.29999999 41.7602997 78.99945411 23.04152435 2\n"
						+ "61.41173702 25.38436364 39.09686927 36.02737339 103.4045971 21.84340688 2\n"
						+ "56.56382381 8.961261611 52.57784639 47.6025622 98.77711506 50.70187326 2\n"
						+ "67.02766447 13.28150221 66.15040334 53.74616226 100.7154129 33.98913551 2\n"
						+ "80.81777144 19.23898066 61.64245116 61.57879078 89.47183446 44.167602 2\n"
						+ "80.65431956 26.34437939 60.89811835 54.30994017 120.1034928 52.46755185 2\n"
						+ "68.72190982 49.4318636 68.0560124 19.29004622 125.0185168 54.69128928 2\n"
						+ "37.90391014 4.47909896 24.71027447 33.42481118 157.848799 33.60702661 2\n"
						+ "64.62400798 15.22530262 67.63216653 49.39870535 90.298468 31.32641123 2\n"
						+ "75.43774787 31.53945399 89.59999999 43.89829388 106.8295898 54.96578902 2\n"
						+ "71.00194076 37.51577195 84.53709256 33.48616882 125.1642324 67.77118983 2\n"
						+ "81.05661087 20.80149217 91.78449512 60.2551187 125.430176 38.18178176 2\n"
						+ "91.46874146 24.50817744 84.62027202 66.96056402 117.3078968 52.62304673 2\n"
						+ "81.08232025 21.25584028 78.76675639 59.82647997 90.07187999 49.159426 2\n"
						+ "60.419932 5.265665422 59.8142356 55.15426658 109.0330745 30.26578534 2\n"
						+ "85.68094951 38.65003527 82.68097744 47.03091424 120.8407069 61.95903428 2\n"
						+ "82.4065243 29.27642195 77.05456489 53.13010235 117.0422439 62.76534831 2\n"
						+ "43.7182623 9.811985315 51.99999999 33.90627699 88.43424213 40.88092253 2\n"
						+ "86.472905 40.30376567 61.14101155 46.16913933 97.4041888 55.75222146 2\n"
						+ "74.46908181 33.28315665 66.94210105 41.18592517 146.4660009 124.9844057 2\n"
						+ "70.25043628 10.34012252 76.37007032 59.91031376 119.2370072 32.66650243 2\n"
						+ "72.64385013 18.92911726 67.99999999 53.71473287 116.9634162 25.38424676 2\n"
						+ "71.24176388 5.268270454 85.99958417 65.97349342 110.703107 38.2598637 2\n"
						+ "63.7723908 12.76338484 65.36052425 51.00900596 89.82274067 55.99545386 2\n"
						+ "58.82837872 37.57787321 125.7423855 21.25050551 135.6294176 117.3146829 2\n"
						+ "74.85448008 13.90908417 62.69325884 60.9453959 115.2087008 33.17225512 2\n"
						+ "75.29847847 16.67148361 61.29620362 58.62699486 118.8833881 31.57582292 2\n"
						+ "63.36433898 20.02462134 67.49870507 43.33971763 130.9992576 37.55670552 2\n"
						+ "67.51305267 33.2755899 96.28306169 34.23746278 145.6010328 88.30148594 2\n"
						+ "76.31402766 41.93368293 93.2848628 34.38034472 132.2672855 101.2187828 2\n"
						+ "73.63596236 9.711317947 62.99999999 63.92464442 98.72792982 26.97578722 2\n"
						+ "56.53505139 14.37718927 44.99154663 42.15786212 101.7233343 25.77317356 2\n"
						+ "80.11157156 33.94243223 85.10160773 46.16913933 125.5936237 100.2921068 2\n"
						+ "95.48022873 46.55005318 58.99999999 48.93017555 96.68390337 77.28307195 2\n"
						+ "74.09473084 18.82372712 76.03215571 55.27100372 128.4057314 73.38821617 2\n"
						+ "87.67908663 20.36561331 93.82241589 67.31347333 120.9448288 76.73062904 2\n"
						+ "48.25991962 16.41746236 36.32913708 31.84245726 94.88233607 28.34379914 2\n"
						+ "38.50527283 16.96429691 35.11281407 21.54097592 127.6328747 7.986683227 1\n"
						+ "54.92085752 18.96842952 51.60145541 35.952428 125.8466462 2.001642472 1\n"
						+ "44.36249017 8.945434892 46.90209626 35.41705528 129.220682 4.994195288 1\n"
						+ "48.3189305 17.45212105 47.99999999 30.86680945 128.9803079 -0.910940567 1\n"
						+ "45.70178875 10.65985935 42.5778464 35.0419294 130.1783144 -3.38890999 1\n"
						+ "30.74193812 13.35496594 35.90352597 17.38697218 142.4101072 -2.005372903 1\n"
						+ "50.91310144 6.6769999 30.89652243 44.23610154 118.151531 -1.057985526 1\n"
						+ "38.12658854 6.557617408 50.44507473 31.56897113 132.114805 6.338199339 1\n"
						+ "51.62467183 15.96934373 35 35.6553281 129.385308 1.00922834 1\n"
						+ "64.31186727 26.32836901 50.95896417 37.98349826 106.1777511 3.118221289 1\n"
						+ "44.48927476 21.78643263 31.47415392 22.70284212 113.7784936 -0.284129366 1\n"
						+ "54.9509702 5.865353416 52.99999999 49.08561678 126.9703283 -0.631602951 1\n"
						+ "56.10377352 13.10630665 62.63701952 42.99746687 116.2285032 31.17276727 1\n"
						+ "69.3988184 18.89840693 75.96636144 50.50041147 103.5825398 -0.44366081 1\n"
						+ "89.83467631 22.63921678 90.56346144 67.19545953 100.5011917 3.040973261 1\n"
						+ "59.72614016 7.724872599 55.34348527 52.00126756 125.1742214 3.235159224 1\n"
						+ "63.95952166 16.06094486 63.12373633 47.8985768 142.3601245 6.298970934 1\n"
						+ "61.54059876 19.67695713 52.89222856 41.86364163 118.6862678 4.815031084 1\n"
						+ "38.04655072 8.30166942 26.23683004 29.7448813 123.8034132 3.885773488 1\n"
						+ "43.43645061 10.09574326 36.03222439 33.34070735 137.4396942 -3.114450861 1\n"
						+ "65.61180231 23.13791922 62.58217893 42.47388309 124.1280012 -4.083298414 1\n"
						+ "53.91105429 12.93931796 38.99999999 40.97173633 118.1930354 5.074353176 1\n"
						+ "43.11795103 13.81574355 40.34738779 29.30220748 128.5177217 0.970926407 1\n"
						+ "40.6832291 9.148437195 31.02159252 31.53479191 139.1184721 -2.511618596 1\n"
						+ "37.7319919 9.386298276 41.99999999 28.34569362 135.740926 13.68304672 1\n"
						+ "63.92947003 19.97109671 40.17704963 43.95837332 113.0659387 -11.05817866 1\n"
						+ "61.82162717 13.59710457 63.99999999 48.22452261 121.779803 1.296191194 1\n"
						+ "62.14080535 13.96097523 57.99999999 48.17983012 133.2818339 4.955105669 1\n"
						+ "69.00491277 13.29178975 55.5701429 55.71312302 126.6116215 10.83201105 1\n"
						+ "56.44702568 19.44449915 43.5778464 37.00252653 139.1896903 -1.859688529 1\n"
						+ "41.6469159 8.835549101 36.03197484 32.8113668 116.5551679 -6.054537956 1\n"
						+ "51.52935759 13.51784732 35 38.01151027 126.7185156 13.92833085 1\n"
						+ "39.08726449 5.536602477 26.93203835 33.55066201 131.5844199 -0.75946135 1\n"
						+ "34.64992241 7.514782784 42.99999999 27.13513962 123.9877408 -4.082937601 1\n"
						+ "63.02630005 27.33624023 51.60501665 35.69005983 114.5066078 7.439869802 1\n"
						+ "47.80555887 10.68869819 53.99999999 37.11686068 125.3911378 -0.402523218 1\n"
						+ "46.63786363 15.85371711 39.99999999 30.78414653 119.3776026 9.06458168 1\n"
						+ "49.82813487 16.73643493 28 33.09169994 121.4355585 1.91330704 1\n"
						+ "47.31964755 8.573680295 35.56025198 38.74596726 120.5769719 1.630663508 1\n"
						+ "50.75329025 20.23505957 37 30.51823068 122.343516 2.288487746 1\n"
						+ "36.15782981 -0.810514093 33.62731353 36.96834391 135.9369096 -2.092506504 1\n"
						+ "40.74699612 1.835524271 49.99999999 38.91147185 139.2471502 0.668556793 1\n"
						+ "42.91804052 -5.845994341 57.99999999 48.76403486 121.6068586 -3.362044654 1\n"
						+ "63.79242525 21.34532339 65.99999999 42.44710185 119.5503909 12.38260373 1\n"
						+ "72.95564397 19.57697146 61.00707117 53.37867251 111.2340468 0.813491154 1\n"
						+ "67.53818154 14.65504222 58.00142908 52.88313932 123.6322597 25.9702063 1\n"
						+ "54.75251965 9.752519649 47.99999999 45 123.0379985 8.235294118 1\n"
						+ "50.16007802 -2.970024337 41.99999999 53.13010235 131.8024914 -8.290203373 1\n"
						+ "40.34929637 10.19474845 37.96774659 30.15454792 128.0099272 0.458901373 1\n"
						+ "63.61919213 16.93450781 49.34926218 46.68468432 117.0897469 -0.357811974 1\n"
						+ "54.14240778 11.93511014 42.99999999 42.20729763 122.2090834 0.153549242 1\n"
						+ "74.97602148 14.92170492 53.73007172 60.05431656 105.6453997 1.594747729 1\n"
						+ "42.51727249 14.37567126 25.32356538 28.14160123 128.9056892 0.75702014 1\n"
						+ "33.78884314 3.675109986 25.5 30.11373315 128.3253556 -1.776111234 1\n"
						+ "54.5036853 6.819910138 46.99999999 47.68377516 111.7911722 -4.406769011 1\n"
						+ "48.17074627 9.594216702 39.71092029 38.57652956 135.6233101 5.360050572 1\n"
						+ "46.37408781 10.21590237 42.69999999 36.15818544 121.2476572 -0.54202201 1\n"
						+ "52.86221391 9.410371613 46.98805181 43.4518423 123.0912395 1.856659161 1\n"
						+ "57.1458515 16.48909145 42.84214764 40.65676005 113.8061775 5.0151857 1\n"
						+ "37.14014978 16.48123972 24 20.65891006 125.0143609 7.366425398 1\n"
						+ "51.31177106 8.875541276 56.99999999 42.43622979 126.4722584 -2.144043911 1\n"
						+ "42.51561014 16.54121618 41.99999999 25.97439396 120.631941 7.876730692 1\n"
						+ "39.35870531 7.011261806 37 32.3474435 117.8187599 1.904048199 1\n"
						+ "35.8775708 1.112373561 43.45725694 34.76519724 126.9239062 -1.632238263 1\n"
						+ "43.1919153 9.976663803 28.93814927 33.21525149 123.4674001 1.741017579 1\n"
						+ "67.28971201 16.7175142 50.99999999 50.5721978 137.5917777 4.960343813 1\n"
						+ "51.32546366 13.63122319 33.25857782 37.69424047 131.3061224 1.78886965 1\n"
						+ "65.7563482 13.20692644 43.99999999 52.54942177 129.3935728 -1.982120038 1\n"
						+ "40.41336566 -1.329412398 30.98276809 41.74277806 119.3356546 -6.173674823 1\n"
						+ "48.80190855 18.01776202 51.99999999 30.78414653 139.1504066 10.44286169 1\n"
						+ "50.08615264 13.43004422 34.45754051 36.65610842 119.1346221 3.089484465 1\n"
						+ "64.26150724 14.49786554 43.90250363 49.76364169 115.3882683 5.951454368 1\n"
						+ "53.68337998 13.44702168 41.58429713 40.23635831 113.9137026 2.737035292 1\n"
						+ "48.99595771 13.11382047 51.87351997 35.88213725 126.3981876 0.535471617 1\n"
						+ "59.16761171 14.56274875 43.19915768 44.60486296 121.0356423 2.830504124 1\n"
						+ "67.80469442 16.55066167 43.25680184 51.25403274 119.6856451 4.867539941 1\n"
						+ "61.73487533 17.11431203 46.89999999 44.6205633 120.9201997 3.087725997 1\n"
						+ "33.04168754 -0.324678459 19.0710746 33.366366 120.3886112 9.354364925 1\n"
						+ "74.56501543 15.72431994 58.61858244 58.84069549 105.417304 0.599247113 1\n"
						+ "44.43070103 14.17426387 32.2434952 30.25643716 131.7176127 -3.604255336 1\n"
						+ "36.42248549 13.87942449 20.24256187 22.543061 126.0768612 0.179717077 1\n"
						+ "51.07983294 14.20993529 35.95122893 36.86989765 115.8037111 6.905089963 1\n"
						+ "34.75673809 2.631739646 29.50438112 32.12499844 127.1398495 -0.460894198 1\n"
						+ "48.90290434 5.587588658 55.49999999 43.31531568 137.1082886 19.85475919 1\n"
						+ "46.23639915 10.0627701 37 36.17362905 128.0636203 -5.100053328 1\n"
						+ "46.42636614 6.620795049 48.09999999 39.80557109 130.3500956 2.449382401 1\n"
						+ "39.65690201 16.20883944 36.67485694 23.44806258 131.922009 -4.968979881 1\n"
						+ "45.57548229 18.75913544 33.77414297 26.81634684 116.7970069 3.131909921 1\n"
						+ "66.50717865 20.89767207 31.72747138 45.60950658 128.9029049 1.517203356 1\n"
						+ "82.90535054 29.89411893 58.25054221 53.01123161 110.7089577 6.079337831 1\n"
						+ "50.67667667 6.461501271 35 44.2151754 116.5879699 -0.214710615 1\n"
						+ "89.01487529 26.07598143 69.02125897 62.93889386 111.4810746 6.061508401 1\n"
						+ "54.60031622 21.48897426 29.36021618 33.11134196 118.3433212 -1.471067262 1\n"
						+ "34.38229939 2.062682882 32.39081996 32.31961651 128.3001991 -3.365515555 1\n"
						+ "45.07545026 12.30695118 44.58317718 32.76849908 147.8946372 -8.941709421 1\n"
						+ "47.90356517 13.61668819 36 34.28687698 117.4490622 -4.245395422 1\n"
						+ "53.93674778 20.72149628 29.22053381 33.21525149 114.365845 -0.421010392 1\n"
						+ "61.44659663 22.6949683 46.17034732 38.75162833 125.6707246 -2.707879517 1\n"
						+ "45.25279209 8.693157364 41.5831264 36.55963472 118.5458418 0.214750167 1\n"
						+ "33.84164075 5.073991409 36.64123294 28.76764934 123.9452436 -0.199249089 1\n\n");
		session.setAttribute("concluido", "Processamento conclu&#xed;do.");
		session.setAttribute("saida1",
				"Entre com:<br/>p linhas<br/>q colunas<br/>x_{i, q} a classificar<br/>x_{i, j}, 1 <= i <= p, 1 <= j <= q<br/>[necessario se q = 3] xini, xfim, xstep, yini, yfim, ystep");
		session.setAttribute("saida2", "Entre com:<br/>p linhas<br/>q colunas<br/>k clusters<br/>"
				+ "v linhas de previsoes<br/>x_{i, q} a classificar<br/>x_{i, j}, 1 <= i <= p + v, 1 <= j <= q<br/>[necessario se q = 3] xini, xfim, xstep, yini, yfim, ystep");
		return "bayes_pt";
	}

	@RequestMapping("/fuzzy_pt/abrir")
	public String fuzzyPT(HttpSession session, final Map<String, Object> modelMap) {
		modelMap.put("message", "Esta vers&#xe3;o tem granulo.");
		String valor1 = "livro\n" + "-1 126 -0.1 28\n" + "0.0002\n" + "3 3 500\n" + "1 6 1\n" + "1.5 5.5 1\n";
		String valor2 = "curva\n" + "-6.4 6.4 -10 41\n" + "0.01 0.01001\n" + "5 1 50\n"
				+ "-6.3 -6.2999 6.3 6.3001 0.1\n" + "-6.3 -6.2999 6.3 6.3001 0.1\n";
		modelMap.put("valor1", valor1);
		modelMap.put("valor2", valor2);
		session.setAttribute("valor1", valor1);
		session.setAttribute("valor2", valor2);
		session.setAttribute("fuzzy_concluido", "Processamento conclu&#xed;do.");
		session.setAttribute("fuzzy1",
				"Entre com:<br/>comando = (livro, lista, square, exp, plus, minus, times, over, equals, lessthan, le, gauss)<br/>xleft xright ybottom ytop<br/>alfa<br/>nGaussianas nVari&#xe1;veis n&#xc9;pocas<br/>ou [xi_t xf_t step_t xi_v xf_v step_v]<br/>ou [nPontosT nPontosV nRetro xt(i) ydt(i) xv(i) ydv(i)]");
		session.setAttribute("fuzzy2", "");
		return "fuzzy_pt";
	}

	@RequestMapping("/bayes_en/abrir")
	public String bayesEN(final Map<String, Object> modelMap) {
		modelMap.put("message", "This module divides an integer number by 100 and shows quotient and remainder.");
		modelMap.put("valor1", "1234");
		return "bayes_en";
	}

	@PostMapping("/bayes_pt/selecionar1")
	public String bayesPTSelecionar1(HttpSession session, String valor1, Map<String, Object> modelMap) {

		Util.myThread(session, null, valor1, 1);

		modelMap.put("message", "Tarefa tipo 1 iniciada com sucesso.");
		modelMap.put("valor1", valor1);
		return "bayes_pt";
	}

	@PostMapping("/bayes_pt/selecionar2")
	public String bayesPTSelecionar2(HttpSession session, String valor2, Map<String, Object> modelMap) {

		Util.myThread(session, null, valor2, 2);

		modelMap.put("message", "Tarefa tipo 2 iniciada com sucesso.");
		modelMap.put("valor2", valor2);
		session.setAttribute("valor2", valor2);
		return "bayes_pt";
	}

	@PostMapping("/fuzzy_pt/selecionar1")
	public String fuzzyPTSelecionar1(HttpSession session, HttpServletRequest req, String valor1,
			Map<String, Object> modelMap) {

		Util.myThread(session, null, valor1, 3);

		modelMap.put("message", "Tarefa tipo 1 iniciada com sucesso.");
		modelMap.put("valor1", valor1);
		session.setAttribute("valor1", valor1);
		Object obj = session.getAttribute("valor2");
		if (obj != null)
			modelMap.put("valor2", obj.toString());
		return "fuzzy_pt";
	}

	@PostMapping("/fuzzy_pt/selecionar2")
	public String fuzzyPTSelecionar2(HttpSession session, HttpServletRequest req, String valor2,
			Map<String, Object> modelMap) {

		Util.myThread(session, null, valor2, 4);

		modelMap.put("message", "Tarefa tipo 2 iniciada com sucesso.");
		modelMap.put("valor2", valor2);
		session.setAttribute("valor2", valor2);
		Object obj = session.getAttribute("valor1");
		if (obj != null)
			modelMap.put("valor1", obj.toString());
		return "fuzzy_pt";
	}

	@RequestMapping("/bayes_en/selecionar")
	public String bayesENSelecionar(String valor1, Map<String, Object> modelMap) throws SQLException {

		valor1 = SNum.Valida(SNum.FracValida(valor1));
		SFrac qr = new SFrac();
		qr = SNum.Divide(valor1, "100");

		modelMap.put("message", "Bayes previewed with sucess.");
		modelMap.put("valor1", valor1);
		modelMap.put("valor2", qr.n);
		modelMap.put("valor3", qr.d);
		return "bayes_en";
	}

	@RequestMapping("/facebook_loader/abrir")
	public String fbLoader(HttpSession session, HttpServletRequest req, final Map<String, Object> modelMap) {
		modelMap.put("message", "");
		session.setAttribute("concluido", "");
		session.setAttribute("saida1", "");
		session.setAttribute("saida2", "");
		Util.myThread(session, req, "", -1);
		return "facebook_loader";
	}

}
