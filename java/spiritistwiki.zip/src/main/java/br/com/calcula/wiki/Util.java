package br.com.calcula.wiki;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.Date;
import java.text.SimpleDateFormat;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import br.com.calcula.wiki.entidades.MyTask;

public class Util {

	private static String acentuado = "�����������������������";
	private static String semAcento = "AAAAAUUUUEEEEIIIIOOOOOC";
	private static Integer linhasPorPagina = 100000;
	public static byte clBlack = (byte) 0;
	public static byte clBlue = (byte) 0xD2;
	public static byte clGreen = (byte) 0x71;
	public static byte clRed = (byte) 0x4F;
	public static byte clWhite = (byte) 0xFF;
	public static Double infty = 1.75e308;
	public static Double _infty = -1.75e308;

	public static Integer getLinhasPorPagina() {
		return linhasPorPagina;
	}

	public static String quotedStr(String s) {
		s = s.replace("'", "''");
		s = s.replace("\n", "' || chr(10) ||\n                 '");
		s = s.replace("</p>", "</p>' || chr(10) ||\n                 '");
		return "'" + s + "'";
	}

	public static String doubleQuotedStr(String s) {
		if (s == null)
			return "\"\"";
		//s = convertISOtoUTF8(s);
		s = s.replace("\"", "\\\"").replace("\r", "\\r").replace("\t", " ");
		if (s.contains("<"))
			s = s.replace("\n", "\\n");
		else
			s = s.replace("\n", "<br/>");
		do {
			s = s.replace("  ", " ");
		} while (s.contains("  "));
		return "\"" + s + "\"";
	}

	public static String toDateStr(String s) {
		return "to_date('" + s + "', 'DD/MM/YYYY')";
	}


	// https://gist.github.com/Lukkian/1953132
	public static String convertUTF8toISO(String str) {
		return new String(str.getBytes(StandardCharsets.ISO_8859_1), StandardCharsets.UTF_8);
	}

	public static String convertISOtoUTF8(String str) {
		return new String(str.getBytes(StandardCharsets.UTF_8), StandardCharsets.ISO_8859_1);
	}

	public static String delete(String s, int pos, int qtde) {
		String t = "";
		if (pos >= 1)
			t = s.substring(0, pos - 1);
		if (pos + qtde - 1 <= s.length())
			if (pos + qtde - 1 < 0)
				t = t + s;
			else
				t = t + s.substring(pos + qtde - 1, s.length());
		return t;
	}

	public static String insert(String sub, String s, int i) {
		if (i - 1 >= 0)
			return s.substring(0, i - 1) + sub + s.substring(i - 1, s.length());

		if (i < 1)
			i = 1;
		return sub + s.substring(i - 1, s.length());
	}

	public static String charLeftConcat(char c, String b) {
		b = "�" + b;
		return b.replace('�', c);
	}

	public static String char2String(char c) {
		String s = "�";
		return s.replace('�', c);
	}

	public static boolean charInSet(char ch, String s) {
		for (int i = 0;i < s.length();i++)
			if (ch == s.charAt(i))
				return true;

		return false;
	}

	public static String toString2(ArrayList<String> memo) {
		String s = "";
		for (int i = 0;i < memo.size();i++)
			s = s + memo.get(i);
		return s;
	}

	public static String translate(String oldStr) {
		oldStr = oldStr.toUpperCase();
		for (int i = 0;i < semAcento.length();i++)
			oldStr = oldStr.replace(acentuado.charAt(i), semAcento.charAt(i));
		return oldStr;
	}

	public static Double[][] matrixDouble(Double[] x, int nVariaveis) {
		Double[][] Result = new Double[1][nVariaveis];
		for (int i = 0;i < nVariaveis;i++)
			Result[0][i] = x[i];
		return Result;
	}

	public static Interval[][] matrixInterval(Interval[] x, int nVariaveis) {
		Interval[][] Result = new Interval[1][nVariaveis];
		for (int i = 0;i < nVariaveis;i++)
			Result[0][i] = new Interval(x[i]);
		return Result;
	}

	public static void myThread(HttpSession session, HttpServletRequest req, String valor1, Integer numeroBotao) {
		MyTask task = new MyTask(session, req, valor1, numeroBotao);
		ExecutorService executorService = Executors.newCachedThreadPool();
		executorService.execute(task);
		executorService.shutdown();
		session.setAttribute("concluido", "Rodando");
	}

	public static void println(String s) {
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SSS ");
		String hh = df.format(new Date());
		System.out.println(hh + s);
	}

	public static void print(String s) {
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SSS ");
		String hh = df.format(new Date());
		System.out.print(hh + s);
	}
}
