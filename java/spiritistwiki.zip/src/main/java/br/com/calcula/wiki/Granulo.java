package br.com.calcula.wiki;

public class Granulo {
	public Double min;
	public Double max;

	public Boolean invalido() {
		if (this.max.equals(Util._infty))
			return true;
		if (this.min.equals(Util.infty))
			return true;
		if (this.min > this.max)
			return true;
		if (this.min < Util._infty)
			return true;
		if (this.max > Util.infty)
			return true;
		return false;
	}

	public Granulo() {
		this.min = null;
		this.max = null;
	}

	public Granulo(Double min, Double max) {
		this.min = min;
		this.max = max;
	}

	public Granulo(Double min) {
		this.min = min;
		this.max = null;
	}

	public Granulo(Granulo z) {
		this.min = z.min;
		this.max = z.max;
	}

	public void set(Double min, Double max) {
		this.min = min;
		this.max = max;
	}

	public void set(Granulo y) {
		this.min = y.min;
		this.max = y.max;
	}

	public void xchg() {
		Double x = this.min;
		this.min = this.max;
		this.max = x;
	}

	public Double[] split() {
		Double[] Result = new Double[width];
		Double dx = (this.max - this.min) / (double) width;
		Double atual = this.min;
		for (Integer i = 0; i < width; i++, atual += dx)
			Result[i] = atual;

		return Result;
	}

	public Granulo plus(Granulo y) {
		if (this.invalido())
			return new Granulo(0.0, 0.0);

		Granulo Result = new Granulo(Util.infty, Util._infty);
		Double[] v = this.split(), w = y.split(), z = new Double[width2];
		Integer k = 0;
		for (Integer i = 0; i < width; i++)
			for (Integer j = 0; j < width; j++) {
				z[k] = v[i] + w[j];
				if (z[k] < Result.min)
					Result.min = z[k];
				if (z[k] > Result.max)
					Result.max = z[k];
				k++;
			}

		return Result;
	}

	public Granulo oposto() {
		return new Granulo(-this.max, -this.min);
	}

	public Granulo minus(Granulo y) {
		return this.plus(y.oposto());
	}

	public Granulo timesConstant(Double y) {
		if (this.invalido())
			return new Granulo(0.0, 0.0);
		Granulo z;
		if (y < 0) {
			z = this.oposto();
			y = -y;
		} else
			z = new Granulo(this);

		if (!z.min.equals(Util._infty))
			z.min = y * z.min;
		if (!z.max.equals(Util.infty))
			z.max = y * z.max;
		return z;
	}

	public Granulo plusConstant(Double y) {
		Granulo z = new Granulo(y, y);
		return this.plus(z);
	}

	public Granulo square() {
		if (this.invalido())
			return new Granulo(0.0, 0.0);

		Granulo Result = new Granulo(Util.infty, Util._infty);
		Double[] v = this.split(), z = new Double[width];
		for (Integer k = 0; k < width; k++) {
			z[k] = v[k] * v[k];
			if (z[k] < Result.min)
				Result.min = z[k];
			if (z[k] > Result.max)
				Result.max = z[k];
		}

		return Result;
	}

	public Granulo exponential() {
		if (this.invalido())
			return new Granulo(0.0, 0.0);

		Granulo Result = new Granulo(Util.infty, Util._infty);
		Double[] v = this.split(), z = new Double[width];
		for (Integer k = 0; k < width; k++) {
			z[k] = Math.exp(v[k]);
			if (z[k] < Result.min)
				Result.min = z[k];
			if (z[k] > Result.max)
				Result.max = z[k];
		}

		return Result;
	}

	public Granulo cube() {
		if (this.invalido())
			return new Granulo(0.0, 0.0);

		Granulo Result = new Granulo(Util.infty, Util._infty);
		Double[] v = this.split(), z = new Double[width];
		for (Integer k = 0; k < width; k++) {
			z[k] = v[k] * v[k] * v[k];
			if (z[k] < Result.min)
				Result.min = z[k];
			if (z[k] > Result.max)
				Result.max = z[k];
		}

		return Result;
	}

	public Granulo sin() {
		if (this.invalido())
			return new Granulo(0.0, 0.0);

		Granulo Result = new Granulo(Util.infty, Util._infty);
		Double[] v = this.split(), z = new Double[width];
		for (Integer k = 0; k < width; k++) {
			z[k] = Math.sin(v[k]);
			if (z[k] < Result.min)
				Result.min = z[k];
			if (z[k] > Result.max)
				Result.max = z[k];
		}

		return Result;
	}

	public Granulo sqrt() {
		if (this.invalido())
			return new Granulo(0.0, 0.0);

		Granulo Result = new Granulo(Util.infty, Util._infty);
		Double[] v = this.split(), z = new Double[width];
		for (Integer k = 0; k < width; k++) {
			if (v[k] >= 0.0)
				z[k] = Math.sqrt(v[k]);
			else
				z[k] = 0.0;
			if (z[k] < Result.min)
				Result.min = z[k];
			if (z[k] > Result.max)
				Result.max = z[k];
		}

		return Result;
	}

	public Granulo times(Granulo y) {
		if (this.invalido())
			return new Granulo(0.0, 0.0);

		Granulo Result = new Granulo(Util.infty, Util._infty);
		Double[] v = this.split(), w = y.split(), z = new Double[width2];
		Integer k = 0;
		for (Integer i = 0; i < width; i++)
			for (Integer j = 0; j < width; j++) {
				z[k] = v[i] * w[j];
				if (z[k] < Result.min)
					Result.min = z[k];
				if (z[k] > Result.max)
					Result.max = z[k];
				k++;
			}

		return Result;
	}

	public Granulo over(Granulo y) {
		if (this.invalido())
			return new Granulo(0.0, 0.0);

		Granulo Result = new Granulo(Util.infty, Util._infty);
		Double[] v = this.split(), w = y.split(), z = new Double[width2];
		Integer k = 0;
		for (Integer i = 0; i < width; i++)
			for (Integer j = 0; j < width; j++) {
				if (w[j].equals(0.0))
					z[k] = 0.0;
				else
					z[k] = v[i] / w[j];
				if (z[k] < Result.min)
					Result.min = z[k];
				if (z[k] > Result.max)
					Result.max = z[k];
				k++;
			}

		return Result;
	}

	public Boolean le(Granulo y) {
		Boolean r = this.equals(y);
		if (this.max < y.min) // 2.11 page 20
			r = true;
		return r;
	}

	public Boolean lessThan(Granulo y) {
		return (this.max < y.min);// 2.11 page 20
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Granulo other = (Granulo) obj;
		if (max == null) {
			if (other.max != null)
				return false;
		} else if (!max.equals(other.max))
			return false;
		if (min == null) {
			if (other.min != null)
				return false;
		} else if (!min.equals(other.min))
			return false;
		return true;
	}

	public String graph() {
		return min.toString() + "\n" + max.toString() + "\n";
	}

	@Override
	public String toString() {
		if (this.invalido())
			return "Invalid Granulo";

		String s1, s2;
		if (min.equals(Util._infty))
			s1 = "- infty";
		else
			s1 = min.toString();
		if (max.equals(Util.infty))
			s2 = "infty";
		else
			s2 = max.toString();
		return "Granulo [min=" + s1 + ", max=" + s2 + "]";
	}

	public Granulo gauss(Granulo c, Granulo sigma) {
		Granulo temp1 = c.minus(this);
		temp1 = temp1.over(sigma);
		Granulo temp2 = temp1.square();
		temp1 = temp2.timesConstant(-0.5);
		return temp1.exponential();
	}

	public Double avg() {
		if (min.equals(Util._infty))
			return min;

		if (max.equals(Util.infty))
			return max;

		return 0.5 * (min + max);
	}

	public static Integer width = 10;
	public static Integer width2 = 100;
}
