package br.com.calcula.wiki;

public class DoubleVector {
	public Double[] x;

	public Double getX() {
		return x[0];
	}

	public DoubleVector(Integer n, Double x) {
		this.x = new Double[n];
		this.x[0] = x;
	}

	public DoubleVector(Integer n) {
		this.x = new Double[n];
	}

	public boolean equals(DoubleVector f) {
		return getX().equals(f.getX());
	}

	public boolean equals(Double y) {
		return getX().equals(y);
	}

	@Override
	public String toString() {
		return getX().toString();
	}

	public Double times(Double y) {
		Double xx = this.getX();
		if (xx > y) { // x <= y
			xx = y;
			y = this.getX();
		}

		if (xx.equals(Util.infty))
			return Util.infty;
		else if (xx.equals(Util._infty)) {
			if (y < 0)
				return Util.infty;
			else if (y.equals(0.0))
				return 0.0;
			return Util._infty;
		}
		else if (y.equals(Util.infty))
			return Util.infty;
		return xx * y;
	}

	public Double over(Double y) {
		Double xx = this.getX();
		if (y < 0) { // y >= 0
			xx = -xx;
			y = -y;
		}
		if (Util.infty.equals(Math.abs(xx))) {
			if (y.equals(Util.infty))
				return Util.infty;
			return xx;
		}
		if (y.equals(Util.infty))
			return 0.0;
		if (y.equals(0.0))
			if (xx >= 0.0)
				return Util.infty;
			else
				return Util._infty;
		return xx / y;
	}

	public Double square() {
		return getX() * getX();
	}

	public Double cube() {
		return getX() * square();
	}

	public Double gauss(Double c, Double sigma) {
		DoubleVector f = new DoubleVector(1, (c - getX()) / sigma);
		return Math.exp(-0.5 * f.square());
	}

	public Double mu(Double a, Double b, Double c) {
		Double dx, dy, u, v;
		if (a.equals(b)) {
			if (getX() <= a)
				return 1.0;// 1 rampa zero
			if (getX() >= c)
				return 0.0;
			dy = -1.0;// Delta y = Cy - By
			dx = c - b;// Delta x = Cx - Bx
			u = dy / dx;
			v = 1.0 - u * b;// By = u Bx + v
			return u * getX() + v;// Ry = u Rx + v
		}

		if (b.equals(c)) {
			if (getX() >= c)
				return 1.0;
			if (getX() <= a)
				return 0.0;// 0 rampa 1

			dy = 1.0;// Delta y = By - Ay
			dx = b - a;// Delta x = Bx - Ax
			u = dy / dx;
			v = 1.0 - u * b;// By = u Bx + v
			return u * getX() + v;// Ry = u Rx + v
		}

		if ((getX() <= a) || (getX() >= c))
			return 0.0;

		if ((a < getX()) && (getX() < b)) {
			dy = 1.0;// Delta y = By - Ay
			dx = b - a;// Delta x = Bx - Ax
			u = dy / dx;
			v = 1.0 - u * b;// By = u Bx + v
			return u * getX() + v;// Ry = u Rx + v
		}

		dy = -1.0;// Delta y = Cy - By
		dx = c - b;// Delta x = Cx - Bx
		u = dy / dx;
		v = 1.0 - u * b;// By = u Bx + v
		return u * getX() + v;// Ry = u Rx + v
	}

	public Double[] [] cartesiano(Integer nPontos, Integer nVariaveis, Integer nPower) {
		Double[] [] mat = new Double[nPower][nVariaveis];
		// {0,1}^3 = 01010101 x 00110011 x 00001111
		Integer rep = 1;
		for (Integer v = 0;v < nVariaveis;v++, rep *= nPontos) {
			Integer j = 0;
			Integer k = 0;
			for (Integer i = 0;i < nPower;i++) {
				mat[i][v] = x[j];
				k++;
				if (k >= rep) {
					k = 0;
					j++;
					if (j >= nPontos)
						j = 0;
				}
			}
		}

		return mat;
	}
}
