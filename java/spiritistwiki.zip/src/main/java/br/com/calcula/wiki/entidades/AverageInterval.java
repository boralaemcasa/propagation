package br.com.calcula.wiki.entidades;

import br.com.calcula.wiki.Interval;

public class AverageInterval {
	public SaidaInterval saida;
	public Integer epocas;
	public Double ape;
	public Interval alpha;
	public Interval[] q;
	public Interval[][] p;
	public Interval[][] c;
	public Interval[][] sigma;

	public AverageInterval() {
		q = null;
	}

	public void copy(AverageInterval obj, Integer nGaussianas, Integer nVariaveis) {
		Integer j, v;
		if (q == null) {
			q = new Interval[nGaussianas];
			p = new Interval[nGaussianas][nVariaveis];
			c = new Interval[nGaussianas][nVariaveis];
			sigma = new Interval[nGaussianas][nVariaveis];
			alpha = new Interval();
			for (j = 0; j < nGaussianas; j++) {
				for (v = 0; v < nVariaveis; v++) {
					c[j][v] = new Interval();
					sigma[j][v] = new Interval();
					p[j][v] = new Interval();
				}
				q[j] = new Interval();
			}
		}
		alpha.set(obj.alpha);
		ape = obj.ape;
		//epocas = obj.epocas;
		saida = obj.saida;
		for (j = 0; j < nGaussianas; j++) {
			for (v = 0; v < nVariaveis; v++) {
				c[j][v].set(obj.c[j][v]);
				sigma[j][v].set(obj.sigma[j][v]);
				p[j][v].set(obj.p[j][v]);
			}
			q[j].set(obj.q[j]);
		}
	}

	public void copy(AverageError obj, Integer nGaussianas, Integer nVariaveis) {
		Integer j, v;
		if (q == null) {
			q = new Interval[nGaussianas];
			p = new Interval[nGaussianas][nVariaveis];
			c = new Interval[nGaussianas][nVariaveis];
			sigma = new Interval[nGaussianas][nVariaveis];
			//alpha = new Interval();
			for (j = 0; j < nGaussianas; j++) {
				for (v = 0; v < nVariaveis; v++) {
					c[j][v] = new Interval();
					sigma[j][v] = new Interval();
					p[j][v] = new Interval();
				}
				q[j] = new Interval();
			}
		}
		//alpha.set(obj.alpha);
		//ape = obj.ape;
		//epocas = obj.epocas;
		//saida = obj.saida;
		for (j = 0; j < nGaussianas; j++) {
			for (v = 0; v < nVariaveis; v++) {
				c[j][v].set(obj.c[j][v], obj.c[j][v]);
				sigma[j][v].set(obj.sigma[j][v], obj.sigma[j][v]);
				p[j][v].set(obj.p[j][v], obj.p[j][v]);
			}
			q[j].set(obj.q[j], obj.q[j]);
		}
	}
}
