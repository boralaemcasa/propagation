package br.com.calcula.wiki.entidades;

import br.com.calcula.wiki.Interval;

public class SaidaInterval {
	public Interval [] ys;
	public Interval [] omega;
	public Interval [] z;
	public Interval denom;
}
