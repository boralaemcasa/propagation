package br.com.calcula.wiki.entidades;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import br.com.calcula.wiki.Bayes;
import br.com.calcula.wiki.DoubleVector;
import br.com.calcula.wiki.Interval;
import br.com.calcula.wiki.Memo;
import br.com.calcula.wiki.SNum;
import br.com.calcula.wiki.Util;

public class MyTask implements Runnable {

	private HttpSession session;
	private HttpServletRequest req;
	private String valor1;
	private String saida1;
	private String saida2;
	private String saida3;
	private String concluded;
	private Integer numeroBotao;

	public String getSaida1() {
		return saida1;
	}

	public String fplus(Double x1, Double x2, Double y1, Double y2) {
		Interval x = new Interval(x1, x2);
		Interval y = new Interval(y1, y2);
		Interval z = x.plus(y);
		return z.toString();
	}

	public String fminus(Double x1, Double x2, Double y1, Double y2) {
		Interval x = new Interval(x1, x2);
		Interval y = new Interval(y1, y2);
		Interval z = x.minus(y);
		return z.toString();
	}

	public String ftimes(Double x1, Double x2, Double y1, Double y2) {
		Interval x = new Interval(x1, x2);
		Interval y = new Interval(y1, y2);
		Interval z = x.times(y);
		return z.toString();
	}

	public String fover(Double x1, Double x2, Double y1, Double y2) {
		Interval x = new Interval(x1, x2);
		Interval y = new Interval(y1, y2);
		Interval z = x.over(y);
		Interval w = z.times(y);
		return z.toString() + "\nConferindo: " + w.toString();
	}

	public String fsquare(Double x1, Double x2) {
		Interval x = new Interval(x1, x2);
		Interval z = x.square();
		return z.toString();
	}

	public String fexp(Double x1, Double x2) {
		Interval x = new Interval(x1, x2);
		Interval z = x.exponential();
		return z.toString();
	}

	public String fgauss(Double x1, Double x2, Double c1, Double c2, Double s1, Double s2) {
		Interval x = new Interval(x1, x2);
		Interval c = new Interval(c1, c2);
		Interval s = new Interval(s1, s2);
		Interval z = x.gauss(c, s);
		return z.toString();
	}

	public String fequals(Double x1, Double x2, Double y1, Double y2) {
		Interval x = new Interval(x1, x2);
		Interval y = new Interval(y1, y2);
		if (x.equals(y))
			return "equals = true";

		return "equals = false";
	}

	public String flessthan(Double x1, Double x2, Double y1, Double y2) {
		Interval x = new Interval(x1, x2);
		Interval y = new Interval(y1, y2);
		if (x.lessThan(y))
			return "lessthan = true";

		return "lessthan = false";
	}

	public String fle(Double x1, Double x2, Double y1, Double y2) {
		Interval x = new Interval(x1, x2);
		Interval y = new Interval(y1, y2);
		if (x.le(y))
			return "le = true";

		return "le = false";
	}

	public void setSaida1(String saida1) {
		this.saida1 = saida1;
		String attr = "saida1";
		if (numeroBotao > 2)
			attr = "fuzzy1";
		session.setAttribute(attr, saida1.replace("\n", "<br/>"));
	}

	public String getSaida2() {
		return saida2;
	}

	public void setSaida2(String saida2) {
		this.saida2 = saida2;
		String attr = "saida2";
		if (numeroBotao > 2)
			attr = "fuzzy2";
		session.setAttribute(attr, saida2.replace("\n", "<br/>"));
	}

	public String getSaida3() {
		return saida3;
	}

	public void setSaida3(String saida3) {
		this.saida3 = saida3;
		session.setAttribute("fuzzy3", saida3);
	}

	public HttpSession getSession() {
		return session;
	}

	public void setSession(HttpSession session) {
		this.session = session;
	}

	public MyTask(HttpSession session, HttpServletRequest req, String valor1, Integer numeroBotao) {
		this.session = session;
		this.req = req;
		this.valor1 = valor1;
		this.numeroBotao = numeroBotao;
		session.setAttribute("numeroBotao", numeroBotao.toString());
		if (numeroBotao <= 2)
			concluded = "concluido";
		else
			concluded = "fuzzy_concluido";
	}

	public void run() {
		String s = "";
		try {
			session.setAttribute(concluded, "Rodando.");
			s = getAllEmployees();
			setSaida1(getSaida1() + "\n" + s);
			setSaida2(getSaida2() + "\n" + s);
			session.setAttribute(concluded, s);
		} catch (Exception e) {
			setSaida1(getSaida1() + "\n" + e.getMessage());
			setSaida2(getSaida2() + "\n" + e.getMessage());
		}
		if (!s.equals("Erro: requisi&#xe7;&#xe3;o = NULL."))
			session.setAttribute(concluded, "Processamento conclu&#xed;do.");
	}

	public static int MAXX = 32;
	public static String MAXXV = "32";
	public static int MAXY = 32768;
	public static String MAXYV = "32768";
	public static int DEZ = 10;

	public String getAllEmployees() {
		if (numeroBotao.equals(-1))
			return facebookLoader();

		if (numeroBotao.equals(4))
			return comFuzzyInterval();

		if (numeroBotao.equals(3))
			return comFuzzyDouble();

		if (numeroBotao.equals(2))
			return comKMeans();

		return semKMeans();
	}

	public String semKMeans() {
		valor1 = valor1.replace(" ", "\n");

		Integer x = valor1.indexOf("\n");
		if (x < 0)
			return "Linha n&#xe3;o encontrada.";
		String q = valor1.substring(x + 1);
		String p = valor1.substring(0, x);
		p = SNum.Valida(SNum.FracValida(p));
		Integer pN = Integer.parseInt(p);

		if (pN > MAXY)
			return "M&#xe1;ximo de linhas = " + MAXYV + ".";

		x = q.indexOf("\n");
		if (x < 0)
			return "Coluna n&#xe3;o encontrada.";
		String resto = q.substring(x + 1);
		q = q.substring(0, x);
		q = SNum.Valida(SNum.FracValida(q));
		Integer qN = Integer.parseInt(q);

		if (qN > MAXX)
			return "M&#xe1;ximo de colunas = " + MAXXV + ".";

		x = resto.indexOf("\n");
		if (x < 0)
			return "Alvo a classificar n&#xe3;o encontrado.";
		String target = resto.substring(0, x);
		target = SNum.FracValida(target);
		resto = resto.substring(x + 1);

		String[][] matriz = new String[pN][qN];
		String[] soma = new String[qN];
		String[] sd = new String[qN];

		for (x = 0; x < qN; x++) {
			soma[x] = "0";
			sd[x] = "0";
		}

		Integer i = 0, j;
		while (i < pN) {
			j = 0;
			while (j < qN) {
				x = resto.indexOf("\n");
				if (x < 0) {
					i++;
					j++;
					return "C&#xe9;lula da matriz[" + i.toString() + "][" + j.toString() + "] n&#xe3;o encontrada.";
				}
				matriz[i][j] = SNum.FracValida(resto.substring(0, x));
				soma[j] = SNum.FracAdd(soma[j], matriz[i][j]);
				resto = resto.substring(x + 1);
				j++;
			}
			i++;
		}

		j = 0;
		while (j < qN) {
			soma[j] = SNum.FracDiv(soma[j], p);// media
			i = 0;
			while (i < pN) {
				sd[j] = SNum.FracAdd(sd[j], SNum.FracPower(SNum.FracSub(matriz[i][j], soma[j]), "2"));
				i++;
			}
			j++;
		}

		String xini = "0", xfim = "1", xstep = "1/10", yini = "0", yfim = "1", ystep = "1/10";

		if (qN.equals(3)) {
			x = resto.indexOf("\n");
			if (x < 0)
				return "xini n&#xe3;o encontrado.";
			xini = resto.substring(0, x);
			xini = SNum.FracValida(xini);
			resto = resto.substring(x + 1);

			x = resto.indexOf("\n");
			if (x < 0)
				return "xfim n&#xe3;o encontrado.";
			xfim = resto.substring(0, x);
			xfim = SNum.FracValida(xfim);
			resto = resto.substring(x + 1);

			x = resto.indexOf("\n");
			if (x < 0)
				return "xstep n&#xe3;o encontrado.";
			xstep = resto.substring(0, x);
			xstep = SNum.FracValida(xstep);
			resto = resto.substring(x + 1);

			x = resto.indexOf("\n");
			if (x < 0)
				return "yini n&#xe3;o encontrado.";
			yini = resto.substring(0, x);
			yini = SNum.FracValida(yini);
			resto = resto.substring(x + 1);

			x = resto.indexOf("\n");
			if (x < 0)
				return "yfim n&#xe3;o encontrado.";
			yfim = resto.substring(0, x);
			yfim = SNum.FracValida(yfim);
			resto = resto.substring(x + 1);

			x = resto.indexOf("\n");
			if (x < 0)
				return "ystep n&#xe3;o encontrado.";
			ystep = resto.substring(0, x);
			ystep = SNum.FracValida(ystep);
			resto = resto.substring(x + 1);
		}

		matriz = Bayes.ordenar(matriz, pN, qN);
		setSaida1("Princ&#xED;pio do processamento 1 = simples\n\n");
		setSaida2("Princ&#xED;pio do processamento 1 = simples\n\n");
		String anterior = matriz[0][qN - 1];
		Integer contador = 0, classes = 0, targetClass = 0, treinN = 0, testeN = 0;
		Integer[] xcN = new Integer[2];
		String[] sEquiv = new String[2];
		xcN[0] = 0;
		xcN[1] = 0;
		i = 1;
		while (i <= pN) {
			if (matriz[i - 1][qN - 1].equals(anterior))
				contador++;
			else {
				classes++;
				setSaida1(saida1 + "Classe com " + contador.toString() + " elemento(s).\n");
				if (classes.equals(1)) {
					xcN[0] = contador;
					sEquiv[0] = matriz[i - 2][qN - 1];
				} else if (classes.equals(2)) {
					xcN[1] = contador;
					sEquiv[1] = matriz[i - 2][qN - 1];
				}
				if (targetClass.equals(0) && anterior.equals(target))
					targetClass = classes;
				contador = 1;
			}
			setSaida1(saida1 + i + ":");
			j = 1;
			while (j <= qN) {
				setSaida1(saida1 + " " + matriz[i - 1][j - 1].replace("_", "/"));
				j++;
			}
			anterior = matriz[i - 1][qN - 1];
			i++;
			setSaida1(saida1 + "\n");
		}

		// última
		classes++;
		if (classes.equals(1)) {
			xcN[0] = contador;
			sEquiv[0] = matriz[i - 2][qN - 1];
		} else if (classes.equals(2)) {
			xcN[1] = contador;
			sEquiv[1] = matriz[i - 2][qN - 1];
		}
		if (targetClass.equals(0) && matriz[pN - 1][qN - 1].equals(target))
			targetClass = classes;
		Util.println(targetClass.toString());

		if (targetClass.equals(0))
			return "Tentativa de classificar elemento inexistente na ultima coluna.";

		setSaida1(saida1 + "Classe com " + contador.toString() + " elemento(s).\n");
		setSaida1(saida1 + classes.toString() + " classes.\n");
		Integer dez;

		if (!classes.equals(2)) {
			setSaida1(saida1 + "m&#xe9;dia\n");
			setSaida2(saida2 + "desvio padr&#xe3;o\n");
			j = 0;
			while (j < qN) {
				setSaida1(saida1 + " " + soma[j].replace("_", "/"));
				setSaida2(saida2 + " " + SNum.FracPower(SNum.FracDiv(sd[j], p), "1_2").replace("_", "/"));
				j++;
			}
		} else {
			targetClass--;// 0 ou 1
			Integer offset = 0;
			String[] acuracia = new String[DEZ];
			String[][] cov1 = null, cov2 = null;
			String[][] teste = null;
			String[][] pp = null;
			String[] m1 = new String[qN];
			String[] m2 = new String[qN];
			String det1 = "", det2 = "";
			String[][] inverse1 = null, inverse2 = null;

			for (dez = 0; dez < DEZ; dez++) {
				Util.println("dez = " + dez.toString());

				testeN = xcN[targetClass] / 10;
				if (offset + testeN > xcN[targetClass])
					testeN = xcN[targetClass] - offset;

				if (testeN.equals(0))
					return "Dez por cento para teste deu zero. Nada a fazer. Tente de novo com dez ou mais linhas.";

				teste = new String[testeN][qN];
				pp = new String[testeN][2];
				treinN = xcN[targetClass] - testeN;

				String[][] trein = new String[treinN][qN];
				if (targetClass.equals(0))
					i = 0;
				else
					i = xcN[0];
				for (j = 0; j < offset; i++, j++) {
					trein[j] = matriz[i];
				}

				for (j = 0; j < testeN; i++, j++) {
					teste[j] = matriz[i];
				}

				for (j = offset; j < treinN; i++, j++) {
					trein[j] = matriz[i];
				}

				String[][] xc2 = new String[xcN[1 - targetClass]][qN];
				if (targetClass.equals(0))
					i = xcN[0];
				else
					i = 0;
				for (j = 0; j < xcN[1 - targetClass]; i++, j++) {
					xc2[j] = matriz[i];
					// Util.println("fff " + xc2[j][0] + " " + xc2[j][1]);
				}

				// calcular a média de trein e de xc2
				for (x = 0; x < qN; x++) {
					m1[x] = "0";
					m2[x] = "0";
				}

				for (i = 0; i < treinN; i++)
					for (j = 0; j < qN; j++) {
						m1[j] = SNum.FracAdd(m1[j], trein[i][j]);
					}

				for (j = 0; j < qN; j++)
					m1[j] = SNum.FracDiv(m1[j], treinN.toString());

				for (i = 0; i < xcN[1 - targetClass]; i++)
					for (j = 0; j < qN; j++) {
						m2[j] = SNum.FracAdd(m2[j], xc2[i][j]);
					}

				for (j = 0; j < qN; j++) {
					m2[j] = SNum.FracDiv(m2[j], xcN[1 - targetClass].toString());
					// Double d = SNum.FracToDouble(m2[j]);
					// Util.println("media = " + d.toString());
				}

				cov1 = Bayes.cov(trein, treinN, qN - 1, m1);
				cov2 = Bayes.cov(xc2, xcN[1 - targetClass], qN - 1, m2);

				Util.println("det 1");
				det1 = Bayes.det(cov1, 2);
				Util.println("det 2");
				det2 = Bayes.det(cov2, 2);

				try {
					Util.println("inversa 1");
					inverse1 = Bayes.inversa(cov1, det1, 2);
					Util.println("inversa 2");
					inverse2 = Bayes.inversa(cov2, det2, 2);
				} catch (Exception e) {
					return e.getMessage();
				}

				for (i = 0; i < testeN; i++) {
					pp[i][0] = SNum.FracMul(Bayes.pdfnvar(teste[i], m1, det1, inverse1, 2), treinN.toString());
					pp[i][1] = SNum.FracMul(Bayes.pdfnvar(teste[i], m2, det2, inverse2, 2),
							xcN[1 - targetClass].toString());
					Double d1 = SNum.FracToDouble(pp[i][0]);
					Double d2 = SNum.FracToDouble(pp[i][1]);
					if (Bayes.loggy)
						Util.println("p0 = " + d1.toString() + " p1 = " + d2.toString());
					setSaida2(saida2 + "p" + i.toString() + "0 = " + d1.toString() + "\n" + "p" + i.toString() + "1 = "
							+ d2.toString() + "\n");
				}

				Integer acertos = 0;
				for (i = 0; i < testeN; i++) {
					String denom = pp[i][1];
					if (!denom.equals("0")) {
						String f = SNum.FracDiv(pp[i][0], denom);
						if (SNum.FracCompare(f, "1") >= 0)
							acertos++;// M = targetClass + 1;
					} else
						Util.println(i.toString() + "denom = 0");// nao incrementar acertos significa M !=
																		// targetClass + 1
				}

				if (acertos.equals(testeN)) {
					acuracia[dez] = "1000";
					break;
				}
				acuracia[dez] = SNum.FracDiv(SNum.FracMul(acertos.toString(), "100"), testeN.toString());
				setSaida2(saida2 + "\n");

				offset += testeN;
			}

			Integer max = 0;
			if (acuracia[dez].equals("1000"))
				max = dez;
			else {
				for (dez = 0; dez < DEZ; dez++) {
					setSaida2(saida2 + "acur&#xe1;cia[" + dez.toString() + "] = " + acuracia[dez].replace("_", "/")
							+ "%\n");
					if (SNum.FracCompare(acuracia[dez], acuracia[max]) > 0)
						max = dez;
				}
				if (max.equals(DEZ - 1))
					dez = DEZ - 1;// nao repita
			}

			setSaida2(saida2 + "max = " + max.toString() + "\n");

			if (!max.equals(dez)) {
				offset = testeN * max;
				// refazer tudo para este offset
				testeN = xcN[targetClass] / 10;
				if (offset + testeN > xcN[targetClass])
					testeN = xcN[targetClass] - offset;

				treinN = xcN[targetClass] - testeN;

				String[][] trein = new String[treinN][qN];
				if (targetClass.equals(0))
					i = 0;
				else
					i = xcN[0];
				for (j = 0; j < offset; i++, j++) {
					trein[j] = matriz[i];
				}

				for (j = 0; j < testeN; i++, j++) {
					teste[j] = matriz[i];
				}

				for (j = offset; j < treinN; i++, j++) {
					trein[j] = matriz[i];
				}

				String[][] xc2 = new String[xcN[1 - targetClass]][qN];
				if (targetClass.equals(0))
					i = xcN[0];
				else
					i = 0;
				for (j = 0; j < xcN[1 - targetClass]; i++, j++) {
					xc2[j] = matriz[i];
				}

				// calcular a média de trein e de xc2
				for (x = 0; x < qN; x++) {
					m1[x] = "0";
					m2[x] = "0";
				}

				for (i = 0; i < treinN; i++)
					for (j = 0; j < qN; j++) {
						m1[j] = SNum.FracAdd(m1[j], trein[i][j]);
					}

				for (j = 0; j < qN; j++)
					m1[j] = SNum.FracDiv(m1[j], treinN.toString());

				for (i = 0; i < xcN[1 - targetClass]; i++)
					for (j = 0; j < qN; j++) {
						m2[j] = SNum.FracAdd(m2[j], xc2[i][j]);
					}

				for (j = 0; j < qN; j++)
					m2[j] = SNum.FracDiv(m2[j], xcN[1 - targetClass].toString());

				cov1 = Bayes.cov(trein, treinN, qN - 1, m1);
				cov2 = Bayes.cov(xc2, xcN[1 - targetClass], qN - 1, m2);

				Util.println("det 1");
				det1 = Bayes.det(cov1, 2);
				Util.println("det 2");
				det2 = Bayes.det(cov2, 2);

				try {
					Util.println("inversa 1");
					inverse1 = Bayes.inversa(cov1, det1, 2);
					Util.println("inversa 2");
					inverse2 = Bayes.inversa(cov2, det2, 2);
				} catch (Exception e) {
					return e.getMessage();
				}
			}
			setSaida2(saida2 + "\n");

			// agora a previsão
			if (qN.equals(3)) {
				Integer M = 0;

				for (String sy = yfim; SNum.FracCompare(sy, yini) >= 0; sy = SNum.FracSub(sy, ystep)) {
					if (Bayes.loggy)
						Util.println("sy = " + sy);
					for (String sx = xini; SNum.FracCompare(sx, xfim) <= 0; sx = SNum.FracAdd(sx, xstep)) {
						i = 0;
						teste[i][0] = sx;
						teste[i][1] = sy;
						try {
							pp[i][0] = SNum.FracMul(Bayes.pdfnvar(teste[i], m1, det1, inverse1, 2), treinN.toString());
							pp[i][1] = SNum.FracMul(Bayes.pdfnvar(teste[i], m2, det2, inverse2, 2),
									xcN[1 - targetClass].toString());
						} catch (Exception e) {
							return e.getMessage();
						}
						Double d1 = SNum.FracToDouble(pp[i][0]);
						Double d2 = SNum.FracToDouble(pp[i][1]);
						if (Bayes.loggy)
							Util.println("p0 = " + d1.toString() + " p1 = " + d2.toString());

						String denom = pp[i][1];
						if (denom.equals("0")) {
							M = 1 - targetClass;
							Util.println("denom = 0");// nao incrementar acertos significa M != targetClass + 1
						} else {
							String f = SNum.FracDiv(pp[i][0], denom);
							// Util.println("f =" + f);
							if (SNum.FracCompare(f, "1") >= 0)
								M = targetClass;
							else
								M = 1 - targetClass;
						}
						setSaida2(saida2 + sEquiv[M]);
					}
					setSaida2(saida2 + "\n");
				}

			}
		}

		Util.println("[fim 1] verifique");
		return "Processamento conclu&#xed;do.";
	}

	public String comKMeans() {
		valor1 = valor1.replace(" ", "\n");

		Integer x = valor1.indexOf("\n");
		if (x < 0)
			return "Linha n&#xe3;o encontrada.";
		String q = valor1.substring(x + 1);
		String p = valor1.substring(0, x);
		p = SNum.Valida(SNum.FracValida(p));
		Integer pN = Integer.parseInt(p);

		if (pN > MAXY)
			return "M&#xe1;ximo de linhas = " + MAXYV + ".";

		x = q.indexOf("\n");
		if (x < 0)
			return "Coluna n&#xe3;o encontrada.";
		String resto = q.substring(x + 1);
		q = q.substring(0, x);
		q = SNum.Valida(SNum.FracValida(q));
		Integer qN = Integer.parseInt(q);

		if (qN > MAXX)
			return "M&#xe1;ximo de colunas = " + MAXXV + ".";

		x = resto.indexOf("\n");
		if (x < 0)
			return "Numero de clusters n&#xe3;o encontrado.";
		String k = resto.substring(0, x);
		k = SNum.FracValida(k);
		Integer kN = Integer.parseInt(k);
		resto = resto.substring(x + 1);

		if (kN > MAXY)
			return "M&#xe1;ximo de clusters = " + MAXYV + ".";

		x = resto.indexOf("\n");
		if (x < 0)
			return "Numero de linhas de previsoes n&#xe3;o encontrado.";
		String nPrevisoes = resto.substring(0, x);
		nPrevisoes = SNum.FracValida(nPrevisoes);
		Integer vN = Integer.parseInt(nPrevisoes);
		resto = resto.substring(x + 1);

		x = resto.indexOf("\n");
		if (x < 0)
			return "Alvo a classificar n&#xe3;o encontrado.";
		String target = resto.substring(0, x);
		target = SNum.FracValida(target);
		resto = resto.substring(x + 1);

		String[][] matriz = new String[pN][qN + 1];
		setSaida1("Princ&#xED;pio do processamento 2 = k_means.\n\nProcurando centros\n");
		setSaida2("Princ&#xED;pio do processamento 2 = k_means\n\n");
		Integer i = 0, j;
		while (i < pN) {
			j = 0;
			while (j < qN) {
				x = resto.indexOf("\n");
				if (x < 0) {
					i++;
					j++;
					return "C&#xe9;lula da matriz[" + i.toString() + "][" + j.toString() + "] n&#xe3;o encontrada.";
				}
				matriz[i][j] = SNum.FracValida(resto.substring(0, x));
				resto = resto.substring(x + 1);
				j++;
			}
			matriz[i][qN] = matriz[i][qN - 1];
			i++;
			if ((i + 1) % 100 == 0)
				setSaida1(getSaida1() + "Lida a linha " + i.toString() + "\n");
		}

		String[][] previsoes = new String[vN][qN];
		i = 0;
		while (i < vN) {
			j = 0;
			while (j < qN) {
				x = resto.indexOf("\n");
				if (x < 0) {
					i++;
					j++;
					return "C&#xe9;lula da previs&#xe3;o[" + i.toString() + "][" + j.toString()
							+ "] n&#xe3;o encontrada.";
				}
				previsoes[i][j] = SNum.FracValida(resto.substring(0, x));
				resto = resto.substring(x + 1);
				j++;
			}
			i++;
			if ((i + 1) % 100 == 0)
				setSaida1(getSaida1() + "Lida a previsao " + i.toString() + "\n");
		}

		String xini = "0", xfim = "1", xstep = "1/10", yini = "0", yfim = "1", ystep = "1/10";

		if (qN.equals(3)) {
			x = resto.indexOf("\n");
			if (x < 0)
				return "xini n&#xe3;o encontrado.";
			xini = resto.substring(0, x);
			xini = SNum.FracValida(xini);
			resto = resto.substring(x + 1);

			x = resto.indexOf("\n");
			if (x < 0)
				return "xfim n&#xe3;o encontrado.";
			xfim = resto.substring(0, x);
			xfim = SNum.FracValida(xfim);
			resto = resto.substring(x + 1);

			x = resto.indexOf("\n");
			if (x < 0)
				return "xstep n&#xe3;o encontrado.";
			xstep = resto.substring(0, x);
			xstep = SNum.FracValida(xstep);
			resto = resto.substring(x + 1);

			x = resto.indexOf("\n");
			if (x < 0)
				return "yini n&#xe3;o encontrado.";
			yini = resto.substring(0, x);
			yini = SNum.FracValida(yini);
			resto = resto.substring(x + 1);

			x = resto.indexOf("\n");
			if (x < 0)
				return "yfim n&#xe3;o encontrado.";
			yfim = resto.substring(0, x);
			yfim = SNum.FracValida(yfim);
			resto = resto.substring(x + 1);

			x = resto.indexOf("\n");
			if (x < 0)
				return "ystep n&#xe3;o encontrado.";
			ystep = resto.substring(0, x);
			ystep = SNum.FracValida(ystep);
			resto = resto.substring(x + 1);
		}

		qN++;
		q = qN.toString();
		matriz = Bayes.ordenar(matriz, pN, qN);
		Bayes.kmeans(this, matriz, pN, qN - 2, kN, qN - 2);
		String anterior = matriz[0][qN - 1];
		Integer contador = 0, classes = 0, targetClass = 0, treinN = 0, testeN = 0;
		Integer[] xcN = new Integer[2];
		String[] sEquiv = new String[2];
		xcN[0] = 0;
		xcN[1] = 0;
		i = 1;
		while (i <= pN) {
			if (matriz[i - 1][qN - 1].equals(anterior))
				contador++;
			else {
				classes++;
				setSaida1(saida1 + "Classe com " + contador.toString() + " elemento(s).\n");
				if (classes.equals(1)) {
					xcN[0] = contador;
					sEquiv[0] = matriz[i - 2][qN - 1];
					if (Bayes.loggy)
						Util.println("seq 0 = " + sEquiv[0]);
				} else if (classes.equals(2)) {
					xcN[1] = contador;
					sEquiv[1] = matriz[i - 2][qN - 1];
					if (Bayes.loggy)
						Util.println("seq 1 = " + sEquiv[1]);
				}
				if (targetClass.equals(0) && anterior.equals(target))
					targetClass = classes;
				contador = 1;
			}
			setSaida1(saida1 + i + ":");
			j = 1;
			while (j <= qN) {
				setSaida1(saida1 + " " + matriz[i - 1][j - 1].replace("_", "/"));
				j++;
			}
			anterior = matriz[i - 1][qN - 1];
			i++;
			setSaida1(saida1 + "\n");
		}

		// última
		classes++;
		if (classes.equals(1)) {
			xcN[0] = contador;
			sEquiv[0] = matriz[i - 2][qN - 1];
			if (Bayes.loggy)
				Util.println("seq 0 = " + sEquiv[0]);
		} else if (classes.equals(2)) {
			xcN[1] = contador;
			sEquiv[1] = matriz[i - 2][qN - 1];
			if (Bayes.loggy)
				Util.println("seq 1 = " + sEquiv[1]);
		}
		if (targetClass.equals(0) && matriz[pN - 1][qN - 1].equals(target))
			targetClass = classes;
		Util.println(targetClass.toString());

		if (targetClass.equals(0))
			return "Tentativa de classificar elemento inexistente na ultima coluna.";

		setSaida1(saida1 + "Classe com " + contador.toString() + " elemento(s).\n");
		setSaida1(saida1 + classes.toString() + " classes.\n");
		Integer dez;

		if (!classes.equals(2))
			return "Necessario exatamente 2 classes.";

		targetClass--;// 0 ou 1
		Integer offset = 0;
		String[] acuracia = new String[DEZ];
		String[][] cov1 = null, cov2 = null;
		String[][] teste = null;
		String[][] pp = null;
		String[] m1 = new String[qN];
		String[] m2 = new String[qN];
		String det1 = "", det2 = "";
		String[][] inverse1 = null, inverse2 = null;

		if (Bayes.loggy)
			Util.println("flag");
		Integer[] flag = new Integer[kN];
		for (j = 0; j < kN; j++)
			flag[j] = 0;
		for (i = 0; i < pN; i++) {
			if (matriz[i][qN - 1].equals(sEquiv[0]) && (targetClass.equals(0))) {
				j = Integer.parseInt(matriz[i][qN - 2]);
				flag[j]++;
			} else if (matriz[i][qN - 1].equals(sEquiv[1]) && (targetClass.equals(1))) {
				j = Integer.parseInt(matriz[i][qN - 2]);
				flag[j]++;
			}
		}

		for (dez = 0; dez < DEZ; dez++) {
			Util.println("dez = " + dez.toString());

			testeN = xcN[targetClass] / 10;
			if (offset + testeN > xcN[targetClass])
				testeN = xcN[targetClass] - offset;

			if (testeN.equals(0))
				return "Dez por cento para teste deu zero. Nada a fazer. Tente de novo com dez ou mais linhas.";

			teste = new String[testeN][qN];
			pp = new String[testeN][2];
			treinN = xcN[targetClass] - testeN;
			String[][] trein = new String[treinN][qN];
			if (targetClass.equals(0))
				i = 0;
			else
				i = xcN[0];

			if (Bayes.loggy)
				Util.println("trein 1");
			for (j = 0; j < offset; i++, j++) {
				trein[j] = matriz[i];
			}

			if (Bayes.loggy)
				Util.println("teste");
			teste = new String[testeN][qN];
			for (j = 0; j < testeN; i++, j++) {
				teste[j] = matriz[i];
			}

			if (Bayes.loggy)
				Util.println("trein 2");
			for (j = offset; j < treinN; i++, j++) {
				trein[j] = matriz[i];
			}

			String[][] xc2 = new String[xcN[1 - targetClass]][qN];
			if (targetClass.equals(0))
				i = xcN[0];
			else
				i = 0;
			if (Bayes.loggy)
				Util.println("xc2");
			for (j = 0; j < xcN[1 - targetClass]; i++, j++) {
				xc2[j] = matriz[i];
				// Util.println("fff " + xc2[j][0] + " " + xc2[j][1]);
			}

			// calcular a média de trein e de xc2
			for (x = 0; x < qN; x++) {
				m1[x] = "0";
				m2[x] = "0";
			}

			if (Bayes.loggy)
				Util.println("trein media");
			for (i = 0; i < treinN; i++)
				for (j = 0; j < qN; j++) {
					m1[j] = SNum.FracAdd(m1[j], trein[i][j]);
				}

			for (j = 0; j < qN; j++)
				m1[j] = SNum.FracDiv(m1[j], treinN.toString());

			if (Bayes.loggy)
				Util.println("xc2 media");
			for (i = 0; i < xcN[1 - targetClass]; i++)
				for (j = 0; j < qN; j++) {
					m2[j] = SNum.FracAdd(m2[j], xc2[i][j]);
				}

			for (j = 0; j < qN; j++) {
				m2[j] = SNum.FracDiv(m2[j], xcN[1 - targetClass].toString());
				// Double d = SNum.FracToDouble(m2[j]);
				// Util.println("media = " + d.toString());
			}

			Util.println("cov 1");
			cov1 = Bayes.cov(trein, treinN, qN - 2, m1);
			Util.println("cov 2");
			cov2 = Bayes.cov(xc2, xcN[1 - targetClass], qN - 2, m2);

			Util.println("det 1");
			det1 = Bayes.det(cov1, qN - 2);
			Util.println("det 2");
			det2 = Bayes.det(cov2, qN - 2);

			try {
				Util.println("inversa 1");
				inverse1 = Bayes.inversa(cov1, det1, qN - 2);
				Util.println("inversa 2");
				inverse2 = Bayes.inversa(cov2, det2, qN - 2);
			} catch (Exception e) {
				return e.getMessage();
			}

			for (i = 0; i < testeN; i++) {
				Util.println("i = " + i.toString() + " pdfnvar");
				pp[i][0] = SNum.FracMul(Bayes.pdfnvar(teste[i], m1, det1, inverse1, qN - 2), treinN.toString());
				pp[i][1] = SNum.FracMul(Bayes.pdfnvar(teste[i], m2, det2, inverse2, qN - 2),
						xcN[1 - targetClass].toString());
				Double d1 = SNum.FracToDouble(pp[i][0]);
				Double d2 = SNum.FracToDouble(pp[i][1]);
				if (Bayes.loggy)
					Util.println("p0 = " + d1.toString() + " p1 = " + d2.toString());
				setSaida2(saida2 + "p" + i.toString() + "0 = " + d1.toString() + "\n" + "p" + i.toString() + "1 = "
						+ d2.toString() + "\n");
			}

			if (Bayes.loggy)
				Util.println("acertos");
			Integer acertos = 0;
			for (i = 0; i < testeN; i++) {
				String numerador = "0", denom = "0";
				for (j = 0; j < kN; j++)
					if (flag[j] > 0)
						numerador = SNum.FracAdd(numerador, pp[i][0]);
					else
						denom = SNum.FracAdd(denom, pp[i][1]);
				if (!denom.equals("0")) {
					String f = SNum.FracDiv(numerador, denom);
					if (SNum.FracCompare(f, "1") >= 0)
						acertos++;// M = targetClass + 1;
				} else
					Util.println(i.toString() + " denom = 0");// nao incrementar acertos significa M !=
																	// targetClass + 1
			}

			if (acertos.equals(testeN)) {
				acuracia[dez] = "1000";
				break;
			}
			acuracia[dez] = SNum.FracDiv(SNum.FracMul(acertos.toString(), "100"), testeN.toString());
			setSaida2(saida2 + "\n");

			offset += testeN;
		}

		Integer max = 0;
		if (acuracia[dez].equals("1000"))
			max = dez;
		else {
			for (dez = 0; dez < DEZ; dez++) {
				setSaida2(
						saida2 + "acur&#xe1;cia[" + dez.toString() + "] = " + acuracia[dez].replace("_", "/") + "%\n");
				if (SNum.FracCompare(acuracia[dez], acuracia[max]) > 0)
					max = dez;
			}
			if (max.equals(DEZ - 1))
				dez = DEZ - 1;
		}

		if (!max.equals(dez)) {
			setSaida2(saida2 + "max = " + max.toString() + "\n");

			offset = testeN * max;
			// refazer tudo para este offset
			testeN = xcN[targetClass] / 10;
			if (offset + testeN > xcN[targetClass])
				testeN = xcN[targetClass] - offset;
			treinN = xcN[targetClass] - testeN;

			String[][] trein = new String[treinN][qN];
			if (targetClass.equals(0))
				i = 0;
			else
				i = xcN[0];
			if (Bayes.loggy)
				Util.println("repeat trein 1");
			for (j = 0; j < offset; i++, j++) {
				trein[j] = matriz[i];
			}

			if (Bayes.loggy)
				Util.println("repeat teste");
			for (j = 0; j < testeN; i++, j++) {
				teste[j] = matriz[i];
			}

			if (Bayes.loggy)
				Util.println("repeat trein 2");
			for (j = offset; j < treinN; i++, j++) {
				trein[j] = matriz[i];
			}

			String[][] xc2 = new String[xcN[1 - targetClass]][qN];
			if (targetClass.equals(0))
				i = xcN[0];
			else
				i = 0;
			if (Bayes.loggy)
				Util.println("repeat xc2");
			for (j = 0; j < xcN[1 - targetClass]; i++, j++) {
				xc2[j] = matriz[i];
			}

			// calcular a média de trein e de xc2
			for (x = 0; x < qN; x++) {
				m1[x] = "0";
				m2[x] = "0";
			}

			if (Bayes.loggy)
				Util.println("repeat trein media");
			for (i = 0; i < treinN; i++)
				for (j = 0; j < qN; j++) {
					m1[j] = SNum.FracAdd(m1[j], trein[i][j]);
				}

			for (j = 0; j < qN; j++)
				m1[j] = SNum.FracDiv(m1[j], treinN.toString());

			if (Bayes.loggy)
				Util.println("repeat xc2 media");
			for (i = 0; i < xcN[1 - targetClass]; i++)
				for (j = 0; j < qN; j++) {
					m2[j] = SNum.FracAdd(m2[j], xc2[i][j]);
				}

			for (j = 0; j < qN; j++)
				m2[j] = SNum.FracDiv(m2[j], xcN[1 - targetClass].toString());

			Util.println("repeat cov1");
			cov1 = Bayes.cov(trein, treinN, qN - 2, m1);
			Util.println("repeat cov2");
			cov2 = Bayes.cov(xc2, xcN[1 - targetClass], qN - 2, m2);

			Util.println("repeat det 1");
			det1 = Bayes.det(cov1, qN - 2);
			Util.println("repeat det 2");
			det2 = Bayes.det(cov2, qN - 2);

			try {
				Util.println("repeat inversa 1");
				inverse1 = Bayes.inversa(cov1, det1, qN - 2);
				Util.println("repeat inversa 2");
				inverse2 = Bayes.inversa(cov2, det2, qN - 2);
			} catch (Exception e) {
				return e.getMessage();
			}

			setSaida2(saida2 + "\n");
		}
		Integer M = 0;

		// agora a previsão
		if (!qN.equals(4)) {
			for (i = 0; i < vN; i++) {
				pp[i][0] = SNum.FracMul(Bayes.pdfnvar(previsoes[i], m1, det1, inverse1, qN - 2), treinN.toString());
				pp[i][1] = SNum.FracMul(Bayes.pdfnvar(previsoes[i], m2, det2, inverse2, qN - 2),
						xcN[1 - targetClass].toString());
				Double d1 = SNum.FracToDouble(pp[i][0]);
				Double d2 = SNum.FracToDouble(pp[i][1]);
				if (Bayes.loggy)
					Util.println("p0 = " + d1.toString() + " p1 = " + d2.toString());

				String denom = pp[i][1];
				if (denom.equals("0")) {
					M = 1 - targetClass;
					Util.println("denom = 0");// nao incrementar acertos significa M != targetClass + 1
				} else {
					String f = SNum.FracDiv(pp[i][0], denom);
					// Util.println("f =" + f);
					if (SNum.FracCompare(f, "1") >= 0)
						M = targetClass;
					else
						M = 1 - targetClass;
				}
				setSaida2(saida2 + sEquiv[M]);
			}
		} else
			for (String sy = yfim; SNum.FracCompare(sy, yini) >= 0; sy = SNum.FracSub(sy, ystep)) {
				if (Bayes.loggy)
					Util.println("sy = " + sy);
				for (String sx = xini; SNum.FracCompare(sx, xfim) <= 0; sx = SNum.FracAdd(sx, xstep)) {
					i = 0;
					teste[i][0] = sx;
					teste[i][1] = sy;
					pp[i][0] = SNum.FracMul(Bayes.pdfnvar(teste[i], m1, det1, inverse1, qN - 2), treinN.toString());
					pp[i][1] = SNum.FracMul(Bayes.pdfnvar(teste[i], m2, det2, inverse2, qN - 2),
							xcN[1 - targetClass].toString());
					Double d1 = SNum.FracToDouble(pp[i][0]);
					Double d2 = SNum.FracToDouble(pp[i][1]);
					if (Bayes.loggy)
						Util.println("p0 = " + d1.toString() + " p1 = " + d2.toString());

					String denom = pp[i][1];
					if (denom.equals("0")) {
						M = 1 - targetClass;
						Util.println("denom = 0");// nao incrementar acertos significa M != targetClass + 1
					} else {
						String f = SNum.FracDiv(pp[i][0], denom);
						// Util.println("f =" + f);
						if (SNum.FracCompare(f, "1") >= 0)
							M = targetClass;
						else
							M = 1 - targetClass;
					}
					setSaida2(saida2 + sEquiv[M]);
				}
				setSaida2(saida2 + "\n");
			}

		Util.println("[fim 2] verifique");
		return "Processamento conclu&#xed;do.";
	}

	public String comFuzzyDouble() {
		Memo memo = new Memo(valor1);
		if (!memo.readOutput())
			return "output n&#xe3;o encontrado.";
		Double xleft = memo.readDouble(), xright, ybottom, ytop, alpha, xit, xft, tmp;
		if (memo.error)
			return "xleft n&#xe3;o encontrado.";

		xright = memo.readDouble();
		if (memo.error)
			return "xright n&#xe3;o encontrado.";

		if (memo.output.equals("square"))
			return fsquare(xleft, xright);

		if (memo.output.equals("exp"))
			return fexp(xleft, xright);

		ybottom = memo.readDouble();
		if (memo.error)
			return "ybottom n&#xe3;o encontrado.";

		ytop = memo.readDouble();
		if (memo.error)
			return "ytop n&#xe3;o encontrado.";

		if (memo.output.equals("plus"))
			return fplus(xleft, xright, ybottom, ytop);

		if (memo.output.equals("minus"))
			return fminus(xleft, xright, ybottom, ytop);

		if (memo.output.equals("times"))
			return ftimes(xleft, xright, ybottom, ytop);

		if (memo.output.equals("over"))
			return fover(xleft, xright, ybottom, ytop);

		if (memo.output.equals("equals"))
			return fequals(xleft, xright, ybottom, ytop);

		if (memo.output.equals("lessthan"))
			return flessthan(xleft, xright, ybottom, ytop);

		if (memo.output.equals("le"))
			return fle(xleft, xright, ybottom, ytop);

		alpha = memo.readDouble();
		if (memo.error)
			return "alfa n&#xe3;o encontrado.";

		tmp = memo.readDouble();
		if (memo.error)
			return "nGaussianas n&#xe3;o encontrado.";

		Integer nGaussianas = tmp.intValue(), nPontosT = 0, nPontosV = 0, nVariaveis, nEpocas, i, j, v, nRetro = 0;

		if (memo.output.equals("gauss"))
			return fgauss(xleft, xright, ybottom, ytop, alpha, tmp);

		nVariaveis = memo.readInt();
		if (memo.error)
			return "nVari&#xe1;veis n&#xe3;o encontrado.";

		nEpocas = memo.readInt();
		if (memo.error)
			return "n&#xc9;pocas n&#xe3;o encontrado.";

		setSaida1("Princ&#xED;pio do processamento 1 = simples\n\n");
		setSaida2("Princ&#xED;pio do processamento 1 = simples\n\n");
		Double[][] xt = null, xv = null;
		Double[] ydt = null, ydv = null;

		if (memo.output.equals("lista")) {

			nPontosT = memo.readInt();
			if (memo.error)
				return "nPontosT n&#xe3;o encontrado.";

			nPontosV = memo.readInt();
			if (memo.error)
				return "nPontosV n&#xe3;o encontrado.";

			nRetro = memo.readInt();
			if (memo.error)
				return "nRetro n&#xe3;o encontrado.";

			xt = new Double[nPontosT][nVariaveis];
			xv = new Double[nPontosV][nVariaveis];
			ydt = new Double[nPontosT];
			ydv = new Double[nPontosV];
			xit = Util.infty;
			xft = 0.0;
			for (i = 0; i < nPontosT; i++)
				for (v = 0; v < nVariaveis; v++) {

					tmp = memo.readDouble();
					if (memo.error)
						return "xt_{" + i.toString() + ", " + v.toString() + "} n&#xe3;o encontrado.";
					if (tmp < xit)
						xit = tmp;
					if (tmp > xft)
						xft = tmp;
					xt[i][v] = tmp;
				}

			for (i = 0; i < nPontosT; i++) {
				ydt[i] = memo.readDouble();
				if (memo.error)
					return "ydt_" + i.toString() + " n&#xe3;o encontrado.";
			}

			for (i = 0; i < nPontosV; i++)
				for (v = 0; v < nVariaveis; v++) {
					xv[i][v] = memo.readDouble();
					if (memo.error)
						return "xv_{" + i.toString() + ", " + v.toString() + "} n&#xe3;o encontrado.";
				}

			for (i = 0; i < nPontosV; i++) {
				ydv[i] = memo.readDouble();
				if (memo.error)
					return "ydv_" + i.toString() + " n&#xe3;o encontrado.";
			}
		} else {
			xit = memo.readDouble();
			if (memo.error)
				return "xi_t n&#xe3;o encontrado.";

			xft = memo.readDouble();
			if (memo.error)
				return "xf_t n&#xe3;o encontrado.";

			Double stept = memo.readDouble();
			if (memo.error)
				return "step_t n&#xe3;o encontrado.";

			Double xiv = memo.readDouble();
			if (memo.error)
				return "xi_v n&#xe3;o encontrado.";

			Double xfv = memo.readDouble();
			if (memo.error)
				return "xf_v n&#xe3;o encontrado.";

			Double stepv = memo.readDouble();
			if (memo.error)
				return "step_v n&#xe3;o encontrado.";

			tmp = (xft - xit) / stept + 1.0;
			nPontosT = tmp.intValue();
			DoubleVector xvect = new DoubleVector(nPontosT);
			tmp = xit;
			for (i = 0; i < nPontosT; i++) {
				xvect.x[i] = tmp;
				tmp += stept;
			}
			j = nPontosT;
			for (i = 1; i < nVariaveis; i++)
				j *= nPontosT;
			xt = xvect.cartesiano(nPontosT, nVariaveis, j);
			nPontosT = j;

			tmp = (xfv - xiv) / stepv + 1.0;
			nPontosV = tmp.intValue();
			DoubleVector xvecv = new DoubleVector(nPontosV);
			tmp = xiv;
			for (i = 0; i < nPontosV; i++) {
				xvecv.x[i] = tmp;
				tmp += stepv;
			}
			j = nPontosV;
			for (i = 1; i < nVariaveis; i++)
				j *= nPontosV;
			xv = xvecv.cartesiano(nPontosV, nVariaveis, j);
			nPontosV = j;

			ydt = new Double[nPontosT];
			for (i = 0; i < nPontosT; i++)
				if (nVariaveis.equals(3) && memo.output.equals("livro")) {
					tmp = xt[i][2];
					ydt[i] = 1.0 + Math.sqrt(xt[i][0]) + 1.0 / xt[i][1] + Math.sqrt(tmp) / tmp;
				} else {
					ydt[i] = 0.0;
					for (v = 0; v < nVariaveis; v++)
						ydt[i] += Math.abs(xt[i][v]);
				}

			ydv = new Double[nPontosV];
			for (i = 0; i < nPontosV; i++)
				if (nVariaveis.equals(3) && memo.output.equals("livro")) {
					tmp = xv[i][2];
					ydv[i] = 1.0 + Math.sqrt(xv[i][0]) + 1.0 / xv[i][1] + Math.sqrt(tmp) / tmp;
				} else {
					ydv[i] = 0.0;
					for (v = 0; v < nVariaveis; v++)
						ydv[i] += Math.abs(xv[i][v]);
				}
		}

		if ((nVariaveis > 1) || memo.output.equals("lista")) {
			nRetro++;
			xleft = -1.0;
			if (memo.output.equals("lista"))
				xright = 1.0 + (double) (nRetro * nPontosV);
			else
				xright = 1.0 + (double) nPontosV;
		}
		setSaida1(getSaida1() + "\nNro de pontos treinamento = " + nPontosT.toString()
				+ "\nNro de pontos valida&#xE7;&#xe3;o = " + nPontosV.toString());
		setSaida3(memo.output + "\n" + xleft.toString() + "\n" + xright.toString() + "\n" + ybottom.toString() + "\n"
				+ ytop.toString() + "\n" + nPontosV.toString() + "\n");
		if (nVariaveis.equals(1) && (!memo.output.equals("lista"))) {
			for (i = 0; i < nPontosV; i++)
				setSaida3(getSaida3() + xv[i][0].toString() + "\n" + ydv[i].toString() + "\n");
		} else
			for (i = 0; i < nPontosV; i++)
				setSaida3(getSaida3() + i.toString() + "\n" + ydv[i].toString() + "\n");

		AverageError[] erro = new AverageError[8];
		erro[0] = calcularAPE(alpha, nEpocas, nPontosT, nPontosV, xt, xv, ydt, ydv, nVariaveis, nGaussianas, xit, xft,
				false, false, false);
		erro[1] = calcularAPE(alpha, nEpocas, nPontosT, nPontosV, xt, xv, ydt, ydv, nVariaveis, nGaussianas, xit, xft,
				false, false, true);
		erro[2] = calcularAPE(alpha, nEpocas, nPontosT, nPontosV, xt, xv, ydt, ydv, nVariaveis, nGaussianas, xit, xft,
				false, true, false);
		erro[3] = calcularAPE(alpha, nEpocas, nPontosT, nPontosV, xt, xv, ydt, ydv, nVariaveis, nGaussianas, xit, xft,
				false, true, true);
		erro[4] = calcularAPE(alpha, nEpocas, nPontosT, nPontosV, xt, xv, ydt, ydv, nVariaveis, nGaussianas, xit, xft,
				true, false, false);
		erro[5] = calcularAPE(alpha, nEpocas, nPontosT, nPontosV, xt, xv, ydt, ydv, nVariaveis, nGaussianas, xit, xft,
				true, false, true);
		erro[6] = calcularAPE(alpha, nEpocas, nPontosT, nPontosV, xt, xv, ydt, ydv, nVariaveis, nGaussianas, xit, xft,
				true, true, false);
		erro[7] = calcularAPE(alpha, nEpocas, nPontosT, nPontosV, xt, xv, ydt, ydv, nVariaveis, nGaussianas, xit, xft,
				true, true, true);
		i = 0;
		while ((i < 7) && (erro[i].ape.equals(0.0) || erro[i].ape.isNaN()))
			i++;
		for (j = i + i; j < 8; j++)
			if (!erro[j].ape.equals(0.0))
				if (!erro[j].ape.isNaN())
					if (erro[j].ape < erro[i].ape)
						i = j;

		setSaida1(getSaida1() + "\nAverage Error " + erro[i].ape.toString() + "%\nalfa = " + erro[i].alpha.toString());

		if (nVariaveis.equals(1) && (!memo.output.equals("lista"))) {
			for (j = 0; j < nPontosV; j++)
				setSaida3(getSaida3() + xv[j][0].toString() + "\n" + erro[i].saida.ys[j].toString() + "\n");
		} else
			for (j = 0; j < nPontosV; j++)
				setSaida3(getSaida3() + j.toString() + "\n" + erro[i].saida.ys[j].toString() + "\n");

		if (!memo.output.equals("lista"))
			setSaida2(getSaida2() + "\n<a href=\"/grafico\" target=\"_blank\">Gr&#xe1;fico</a>\n");
		else
			setSaida2(getSaida2() + "\nPasso 1: ");

		setSaida2(getSaida2() + "&#xc9;pocas = " + erro[i].epocas.toString());

		for (j = 1; j <= nGaussianas; j++) {
			setSaida2(getSaida2() + "\nq_" + j.toString() + " = " + erro[i].q[j - 1].toString());
			for (v = 1; v <= nVariaveis; v++)
				setSaida2(getSaida2() + "\np_{" + j.toString() + ", " + v.toString() + "} = "
						+ erro[i].p[j - 1][v - 1].toString() + "\nc_{" + j.toString() + ", " + v.toString() + "} = "
						+ erro[i].c[j - 1][v - 1].toString() + "\nsigma_{" + j.toString() + ", " + v.toString() + "} = "
						+ erro[i].sigma[j - 1][v - 1].toString());
		}

		if (!memo.output.equals("lista")) {
			Util.println("[fim 1] verifique");
			return "Processamento conclu&#xed;do.";
		}

		// retroalimentaçao

		setSaida2(getSaida2() + "\nPasso 2");
		AverageInterval obj = new AverageInterval();
		obj.copy(erro[i], nGaussianas, nVariaveis);
		Interval[][] ixv = new Interval[nPontosV][nVariaveis];
		for (j = 0; j < nPontosV; j++) {
			for (v = 1; v < nVariaveis; v++)
				ixv[j][v] = new Interval(xv[j][v - 1], xv[j][v - 1]);
			tmp = 2.0 * Math.abs(erro[i].saida.ys[j] - ydv[j]);
			ixv[j][0] = new Interval(erro[i].saida.ys[j] - tmp, erro[i].saida.ys[j] + tmp);
		}

		obj.saida = memo.calcularSaidaInterval(ixv, nVariaveis, nGaussianas, nPontosV, obj.c, obj.sigma, obj.p, obj.q);
		for (j = 0, i = nPontosV; j < nPontosV; j++, i++) {
			String s = i.toString() + "\n" + i.toString() + "\n" + obj.saida.ys[j].graph();
			setSaida3(getSaida3() + s);
		}

		for (Integer passo = 3; passo <= nRetro; passo++) {
			setSaida2(getSaida2() + "\nPasso " + passo.toString());
			for (j = 0; j < nPontosV; j++) {
				for (v = 1; v < nVariaveis; v++)
					ixv[j][v].set(ixv[j][v - 1]);
				ixv[j][0].set(obj.saida.ys[j]);
			}

			obj.saida = memo.calcularSaidaInterval(ixv, nVariaveis, nGaussianas, nPontosV, obj.c, obj.sigma, obj.p,
					obj.q);
			for (j = 0; j < nPontosV; j++, i++) {
				String s = i.toString() + "\n" + i.toString() + "\n" + obj.saida.ys[j].graph();
				setSaida3(getSaida3() + s);
			}
		}

		setSaida2(getSaida2() + "\n<a href=\"/grafico\" target=\"_blank\">Gr&#xe1;fico</a>");
		Util.println("[fim lista] verifique");
		return "Processamento conclu&#xed;do.";
	}

	public String comFuzzyInterval() {
		Memo memo = new Memo(valor1);
		return memo.fuzzyInterval(this);
	}

	public SaidaDouble calcularSaidaDouble(Double[][] X, Integer nVariaveis, Integer nGaussianas, Integer nPontos,
			Double[][] c, Double[][] sigma, Double[][] p, Double[] q) {
		SaidaDouble Result = new SaidaDouble();
		Result.omega = new Double[nGaussianas];
		Result.z = new Double[nGaussianas];
		Result.ys = new Double[nPontos];
		Double[] ysd = new Double[nPontos];
		Double tmp;
		for (Integer k = 0; k < nPontos; k++) {
			Double ysn = 0.0;
			ysd[k] = 0.0;
			for (Integer j = 0; j < nGaussianas; j++) {
				Result.omega[j] = 1.0;
				Result.z[j] = q[j];
				for (Integer v = 0; v < nVariaveis; v++) {
					DoubleVector f = new DoubleVector(1, X[k][v]);
					Result.omega[j] *= f.gauss(c[j][v], sigma[j][v]);
					tmp = p[j][v] * X[k][v];
					Result.z[j] += tmp;
				}
				tmp = Result.omega[j] * Result.z[j];
				ysn += tmp;
				ysd[k] += Result.omega[j];
			}

			Result.ys[k] = ysn / ysd[k];
		}
		Result.denom = ysd[0];
		return Result;
	}

	public AverageError calcularAPE(Double alpha, Integer nEpocas, Integer nPontosT, Integer nPontosV, Double[][] xt,
			Double[][] xv, Double[] ydt, Double[] ydv, Integer nVariaveis, Integer nGaussianas, Double xit, Double xft,
			Boolean normalizar, Boolean limitar, Boolean copiar) {
		if (normalizar)
			System.out.print("1");
		else
			System.out.print("0");
		if (limitar)
			System.out.print("1");
		else
			System.out.print("0");
		if (copiar)
			System.out.print("1 ");
		else
			System.out.print("0 ");
		Double tmp, apeAnt = Util.infty;
		Integer j, k, v;
		Double[] dq = new Double[nGaussianas];
		Double[][] dp = new Double[nGaussianas][nVariaveis];
		Double[][] dc = new Double[nGaussianas][nVariaveis];
		Double[][] dsigma = new Double[nGaussianas][nVariaveis];
		AverageError obj = new AverageError(), Result = new AverageError();
		obj.alpha = alpha;
		obj.q = new Double[nGaussianas];
		obj.p = new Double[nGaussianas][nVariaveis];
		obj.c = new Double[nGaussianas][nVariaveis];
		obj.sigma = new Double[nGaussianas][nVariaveis];
		tmp = (xft - xit) / (nGaussianas - 1.0);
		for (k = 0; k < nGaussianas; k++) {
			obj.q[k] = Math.random();
			for (v = 0; v < nVariaveis; v++) {
				obj.p[k][v] = Math.random();
				obj.c[k][v] = xit + tmp * k;
				obj.sigma[k][v] = 0.5 * tmp / Math.sqrt(2.0 * Math.log(2.0));
			}
		}

		Integer[] shuffle = new Integer[nPontosT];
		obj.saida = null;
		for (obj.epocas = 0; (obj.epocas < 500) && (obj.epocas < nEpocas); obj.epocas++) {
			for (k = 0; k < nPontosT; k++)
				shuffle[k] = k;
			for (k = 0; k < 1000; k++) {// mil embaralhadas
				j = (int) (Math.random() * 1000000.0) % nPontosT;
				v = (int) (Math.random() * 1000000.0) % nPontosT;
				Integer t = shuffle[v];
				shuffle[v] = shuffle[j];
				shuffle[j] = t;
			}

			for (k = 0; k < nPontosT; k++) {
				obj.saida = calcularSaidaDouble(Util.matrixDouble(xt[shuffle[k]], nVariaveis), nVariaveis, nGaussianas,
						1, obj.c, obj.sigma, obj.p, obj.q);
				Double max = 0.0;
				for (j = 0; j < nGaussianas; j++) {
					Double dysdwj = (obj.saida.z[j] - obj.saida.ys[0]) / obj.saida.denom;
					Double dysdyj = obj.saida.omega[j];
					Double dedys = obj.saida.ys[0] - ydt[shuffle[k]];
					if (normalizar)
						dedys /= Math.abs(dedys);
					for (v = 0; v < nVariaveis; v++) {
						DoubleVector f = new DoubleVector(1, obj.sigma[j][v]);
						Double sq = f.square();
						Double cu = obj.sigma[j][v] * sq;
						Double difx = xt[shuffle[k]][v] - obj.c[j][v];
						Double dwjdcij = obj.saida.omega[j] * difx / sq;
						difx *= difx;
						Double dwjdsij = obj.saida.omega[j] * difx / cu;
						Double dyjdpij = xt[shuffle[k]][v];
						dc[j][v] = dedys * dysdwj * dwjdcij;
						if (dc[j][v] > max)
							max = dc[j][v];
						dsigma[j][v] = dedys * dysdwj * dwjdsij;
						if (dsigma[j][v] > max)
							max = dsigma[j][v];
						dp[j][v] = dedys * dysdyj * dyjdpij;
						if (dp[j][v] > max)
							max = dp[j][v];
					}
					dq[j] = dedys * dysdyj;
					if (dq[j] > max)
						max = dq[j];

				}
				if (limitar && (max > 100.0))
					alpha *= 0.01;
				for (j = 0; j < nGaussianas; j++) {
					for (v = 0; v < nVariaveis; v++) {
						tmp = alpha * dc[j][v];
						obj.c[j][v] -= tmp;
						tmp = alpha * dsigma[j][v];
						obj.sigma[j][v] -= tmp;
						tmp = alpha * dp[j][v];
						obj.p[j][v] -= tmp;
					}
					tmp = alpha * dq[j];
					obj.q[j] -= tmp;
				}
			}
			if (copiar) {
				obj.saida = calcularSaidaDouble(xv, nVariaveis, nGaussianas, nPontosV, obj.c, obj.sigma, obj.p, obj.q);
				obj.ape = 0.0;
				for (v = 0; v < nPontosV; v++) {
					tmp = obj.saida.ys[v];
					if (!tmp.equals(0.0)) {
						tmp = (tmp - ydv[v]) / tmp;
						obj.ape += Math.abs(tmp);
					}
				}
				obj.ape /= (double) nPontosV / 100.0;
				if ((obj.ape > 0.0) && (obj.ape < apeAnt) || obj.epocas.equals(0)) {
					Result.copy(obj, nGaussianas, nVariaveis);
					apeAnt = obj.ape;
				} else
					obj.copy(Result, nGaussianas, nVariaveis);
			}
		}

		if (copiar)
			obj.copy(Result, nGaussianas, nVariaveis);
		obj.saida = calcularSaidaDouble(xv, nVariaveis, nGaussianas, nPontosV, obj.c, obj.sigma, obj.p, obj.q);
		obj.ape = 0.0;
		for (j = 0; j < nPontosV; j++) {
			tmp = (obj.saida.ys[j] - ydv[j]) / obj.saida.ys[j];
			obj.ape += Math.abs(tmp);
		}
		obj.ape /= (double) nPontosV / 100.0;
		Util.println(obj.ape.toString());
		return obj;
	}

	public String facebookLoader() {
		setSaida1("Princ&#xED;pio do processamento\n\n");
		setSaida2("");

		if (req == null)
			return "Erro: requisi&#xe7;&#xe3;o = NULL.";

		String nomearq;
		if (req.getServerPort() == 8081)
			nomearq = req.getScheme() + "://" + req.getServerName() + ":" + req.getServerPort()
					+ "/facebook/your_posts_1.html";
		else
			nomearq = req.getScheme() + "://" + req.getServerName() + "/facebook/your_posts_1.html";

		ByteArrayOutputStream out = new ByteArrayOutputStream();
		try {
			URL u = new URL(nomearq);
			InputStream fis = u.openStream();

			byte buf[] = new byte[16384];
			int s;
			while ((s = fis.read(buf, 0, 16384)) > 0) {
				out.write(buf, 0, s);
				// tl += s;
			}

			fis.close();
		} catch (IOException e) {
			return "Erro: requisi&#xe7;&#xe3;o = NULL.";
		}
		try {
			saida1 = out.toString("UTF-8");
		} catch (UnsupportedEncodingException e) {
			saida1 = "UTF-8 n&#xe3;o suportado.";
		}
		return "Processamento conclu&#xed;do.";
	}

}
