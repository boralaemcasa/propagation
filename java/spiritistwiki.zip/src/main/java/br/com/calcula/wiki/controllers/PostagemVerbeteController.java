package br.com.calcula.wiki.controllers;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import br.com.calcula.wiki.Interval;
import br.com.calcula.wiki.Memo;
import br.com.calcula.wiki.Util;
import br.com.calcula.wiki.XY;

@RestController
public class PostagemVerbeteController {

	private XY q;
	private XY bottomLeft;
	private XY topRight;
	private byte[] img;

	@GetMapping("/")
	public ModelAndView index() {
		return new ModelAndView("index");
	}

	@GetMapping("/grafico")
	public ModelAndView graph() {
		return new ModelAndView("grafico");
	}

	@GetMapping("/webs/ufmg")
	public ModelAndView webs_ufmg() {
		return new ModelAndView("webs/ufmg");
	}

	@GetMapping("/facebook/comments")
	public ModelAndView f1() {
		return new ModelAndView("facebook/comments");
	}

	@GetMapping("/facebook/posts_and_comments")
	public ModelAndView f2() {
		return new ModelAndView("facebook/posts_and_comments");
	}

	@GetMapping("/facebook/your_posts_1")
	public ModelAndView f3() {
		return new ModelAndView("facebook/your_posts_1");
	}

	@GetMapping("/facebook/your_posts_2")
	public ModelAndView f4() {
		return new ModelAndView("facebook/your_posts_2");
	}

	@GetMapping("/facebook/your_posts_2021")
	public ModelAndView f5() {
		return new ModelAndView("facebook/your_posts_2021");
	}

	@GetMapping("/principal")
	public ModelAndView principal() {
		return new ModelAndView("principal");
	}

	@GetMapping("/listaAnexos")
	public ModelAndView listaAnexos() throws SQLException {
		ModelAndView mv = new ModelAndView("listaAnexos");
		return mv;
	}

	@GetMapping("/main")
	public ModelAndView main2() {
		return new ModelAndView("main");
	}

	@GetMapping("/saida1")
	public String saida(HttpSession session) {
		String s;
		try {
			s = session.getAttribute("saida1").toString();
		} catch (Exception e) {
			s = "Error 404";
		}
		return s;
	}

	@GetMapping("/saida2")
	public String saida2(HttpSession session) {
		String s;
		try {
			s = session.getAttribute("saida2").toString();
		} catch (Exception e) {
			s = "Error 404";
		}
		return s;
	}

	@GetMapping("/concluido")
	public String concluido(HttpSession session, HttpServletRequest req) {
		String s;
		try {
			s = session.getAttribute("concluido").toString();
		} catch (Exception e) {
			s = "Error 404";
		}
		if (s.equals("Erro: requisi&#xe7;&#xe3;o = NULL."))
			Util.myThread(session, req, "", -1);
		return s;
	}

	@GetMapping("/fuzzy1")
	public String fuzzy1(HttpSession session) {
		String s;
		try {
			s = session.getAttribute("fuzzy1").toString();
		} catch (Exception e) {
			s = "Error 404";
		}
		return s;
	}

	@GetMapping("/fuzzy2")
	public String fuzzy2(HttpSession session) {
		String s;
		try {
			s = session.getAttribute("fuzzy2").toString();
		} catch (Exception e) {
			s = "Error 404";
		}
		return s;
	}

	@GetMapping("/fuzzy_concluido")
	public String fuzzyConcluido(HttpSession session) {
		String s;
		try {
			s = session.getAttribute("fuzzy_concluido").toString();
		} catch (Exception e) {
			s = "Error 404";
		}
		return s;
	}

	int posx(Double a) {
		return (int) ((a - bottomLeft.x) * q.x);
	}

	int posy(Double b) {
		return (int) ((topRight.y - b) * q.y);
	}

	public void putPixel(int x, int y, byte cor) {
		if ((767 - y >= 0) && (767 - y < 768))
			if ((x >= 0) && (x < 1024))
				try {
					img[1078 + 1024 * (767 - y) + x] = cor;
				} catch (Exception e) {

				}
	}

	public void pontoXY(Double x, Double y, int raio, byte cor) {
		int px = posx(x);
		int py = posy(y);
		for (int i = -raio; i <= raio; i++)
			for (int j = -raio; j <= raio; j++)
				putPixel(px + i, py + j, cor);
	}

	public void lineXY(Double xi, Double yi, Double xf, Double yf, Double step, byte cor) {
		Double dx = xf - xi;
		Double dy = yf - yi;
		for (Double t = 0.0; t < 1.0; t += step)
			pontoXY(xi + t * dx, yi + t * dy, 0, cor);
	}

	public void circulo(int x, int y) {
		for (int i = 1; i <= 4; i++)
			for (int j = 1; j <= 4; j++)
				putPixel(x + i, y + j, Util.clBlack);
	}

	@GetMapping("/grafico.bmp")
	public byte[] baixarGrafico(HttpSession session, HttpServletRequest req) {
		try {
			String s = session.getAttribute("numeroBotao").toString();
			if (s.equals("4"))
				return baixarGraficoInterval(session, req);
		} catch (Exception e) {
		}

		return baixarGraficoDouble(session, req);
	}

	void line(Integer x1, Integer y1, Integer x2, Integer y2, byte cor) {
		if (x1.equals(x2))
			for (int y = y1; y <= y2; y++)
				putPixel(x1, y, cor);
		if (y1.equals(y2))
			for (int x = x1; x <= x2; x++)
				putPixel(x, y1, cor);
	}

	void display(char numb, int larg, int alt, int col, int li) {
		numb -= 48;
		String[] filamento = new String[10];
		filamento[0] = "1111110";
		filamento[1] = "0110000";
		filamento[2] = "1101101";
		filamento[3] = "1111001";
		filamento[4] = "0110011";
		filamento[5] = "1011011";
		filamento[6] = "1011111";
		filamento[7] = "1110010";
		filamento[8] = "1111111";
		filamento[9] = "1111011";
		byte cor;
		if (filamento[numb].charAt(0) == '1')
			cor = Util.clBlack;
		else
			cor = Util.clWhite;
		line(col + 3, li, col + 2 + larg - 1, li, cor);
		line(col + 4, li + 1, col + 2 + larg - 2, li + 1, cor);
		line(col + 5, li + 2, col + 2 + larg - 3, li + 2, cor);
		line(col + 6, li + 3, col + 2 + larg - 4, li + 3, cor);
		line(col + 7, li + 4, col + 2 + larg - 5, li + 4, cor);
		if (filamento[numb].charAt(1) == '1')
			cor = Util.clBlack;
		else
			cor = Util.clWhite;
		line(col + larg, li + 5, col + larg, li + alt - 4, cor);
		line(col + 1 + larg, li + 4, col + 1 + larg, li + alt - 3, cor);
		line(col + 2 + larg, li + 3, col + 2 + larg, li + alt - 2, cor);
		line(col + 3 + larg, li + 2, col + 3 + larg, li + alt - 3, cor);
		line(col + 4 + larg, li + 1, col + 4 + larg, li + alt - 4, cor);
		if (filamento[numb].charAt(2) == '1')
			cor = Util.clBlack;
		else
			cor = Util.clWhite;
		line(col + larg, li + alt + 4, col + larg, li + 2 * alt - 5, cor);
		line(col + 1 + larg, li + alt + 3, col + 1 + larg, li + 2 * alt - 4, cor);
		line(col + 2 + larg, li + alt + 2, col + 2 + larg, li + 2 * alt - 3, cor);
		line(col + 3 + larg, li + alt + 3, col + 3 + larg, li + 2 * alt - 2, cor);
		line(col + 4 + larg, li + alt + 4, col + 4 + larg, li + 2 * alt - 1, cor);
		if (filamento[numb].charAt(3) == '1')
			cor = Util.clBlack;
		else
			cor = Util.clWhite;
		line(col + 7, li + 2 * alt - 4, col + 2 + larg - 5, li + 2 * alt - 4, cor);
		line(col + 6, li + 2 * alt - 3, col + 2 + larg - 4, li + 2 * alt - 3, cor);
		line(col + 5, li + 2 * alt - 2, col + 2 + larg - 3, li + 2 * alt - 2, cor);
		line(col + 4, li + 2 * alt - 1, col + 2 + larg - 2, li + 2 * alt - 1, cor);
		line(col + 3, li + 2 * alt, col + 2 + larg - 1, li + 2 * alt, cor);
		if (filamento[numb].charAt(4) == '1')
			cor = Util.clBlack;
		else
			cor = Util.clWhite;
		line(col, li + alt + 4, col, li + 2 * alt - 1, cor);
		line(col + 1, li + alt + 3, col + 1, li + 2 * alt - 2, cor);
		line(col + 2, li + alt + 2, col + 2, li + 2 * alt - 3, cor);
		line(col + 3, li + alt + 3, col + 3, li + 2 * alt - 4, cor);
		line(col + 4, li + alt + 4, col + 4, li + 2 * alt - 5, cor);
		if (filamento[numb].charAt(5) == '1')
			cor = Util.clBlack;
		else
			cor = Util.clWhite;
		line(col, li + 1, col, li + alt - 4, cor);
		line(col + 1, li + 2, col + 1, li + alt - 3, cor);
		line(col + 2, li + 3, col + 2, li + alt - 2, cor);
		line(col + 3, li + 4, col + 3, li + alt - 3, cor);
		line(col + 4, li + 5, col + 4, li + alt - 4, cor);
		if (filamento[numb].charAt(6) == '1')
			cor = Util.clBlack;
		else
			cor = Util.clWhite;
		line(col + 7, li + alt - 2, col + larg - 3, li + alt - 2, cor);
		line(col + 6, li + alt - 1, col + larg - 2, li + alt - 1, cor);
		line(col + 5, li + alt, col + larg - 1, li + alt, cor);
		line(col + 6, li + alt + 1, col + larg - 2, li + alt + 1, cor);
		line(col + 7, li + alt + 2, col + larg - 3, li + alt + 2, cor);
	}

	public void showTime() {
		int dist = 30, top = 10, height = 90, width = 300, alt = (height - 47) / 2, larg = (width - 196) / 6;
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.HOUR, -3);
		Date hora = cal.getTime();
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SSS");
		String hh = df.format(hora);
		circulo(10 + 2 * larg + 2 * dist - dist / 2, top + alt / 2);
		circulo(10 + 2 * larg + 2 * dist - dist / 2, top + alt + alt / 2);
		circulo(10 + 4 * larg + 4 * dist - dist / 2 + 5, top + alt / 2);
		circulo(10 + 4 * larg + 4 * dist - dist / 2 + 5, top + alt + alt / 2);
		display(hh.charAt(11), larg, alt, 10, top);
		display(hh.charAt(12), larg, alt, 10 + larg + dist, top);
		display(hh.charAt(14), larg, alt, 10 + 2 * larg + 2 * dist + 5, top);
		display(hh.charAt(15), larg, alt, 10 + 3 * larg + 3 * dist + 5, top);
		display(hh.charAt(17), larg, alt, 10 + 4 * larg + 4 * dist + 10, top);
		display(hh.charAt(18), larg, alt, 10 + 5 * larg + 5 * dist + 10, top);
	}

	public byte[] baixarGraficoDouble(HttpSession session, HttpServletRequest req) {
		String nomearq;
		if (req.getServerPort() == 8081)
			nomearq = req.getScheme() + "://" + req.getServerName() + ":" + req.getServerPort() + "/img/esqueleto.bmp";
		else
			nomearq = req.getScheme() + "://" + req.getServerName() + "/img/esqueleto.bmp";

		try {
			URL u = new URL(nomearq);
			InputStream fis = u.openStream();
			img = new byte[787510];
			fis.read(img, 0, 1077);
			for (int i = 1078; i < 787510; i++) // 1024 * 768 + 1078
				img[i] = Util.clWhite;
			fis.close();
		} catch (IOException e) {
			img = new byte[1];
			img[0] = 0;
			return img;
		}

		String resto;
		try {
			resto = session.getAttribute("fuzzy3").toString();
		} catch (Exception e) {
			resto = "Error 404";
		}

		Memo memo = new Memo(resto);
		if (!memo.readOutput())
			return img;

		bottomLeft = new XY();
		topRight = new XY();
		bottomLeft.x = memo.readDouble();
		if (memo.error)
			return img;

		topRight.x = memo.readDouble();
		if (memo.error)
			return img;

		bottomLeft.y = memo.readDouble();
		if (memo.error)
			return img;

		topRight.y = memo.readDouble();
		if (memo.error)
			return img;

		q = new XY(1024.0 / (topRight.x - bottomLeft.x), 768.0 / (topRight.y - bottomLeft.y));
		Double step = q.x, t, z = 0.0, tt = 0.0, nn = 0.0;
		Interval xi = new Interval();
		Interval xf = new Interval();
		if (q.y > step)
			step = q.y;
		step = 0.1 / step;

		for (t = bottomLeft.x; t <= topRight.x; t += step)
			pontoXY(t, 0.0, 0, Util.clBlack);
		for (t = bottomLeft.y; t <= topRight.y; t += step)
			pontoXY(0.0, t, 0, Util.clBlack);
		showTime();
		Integer n = memo.readInt();
		if (memo.error)
			return img;

		if (memo.output.equals("lista")) {
			z = (double) n;
			for (; posx(z) < topRight.x; z += (double) n)
				for (t = bottomLeft.y; t <= topRight.y; t += step) {
					pontoXY(z, t, 0, Util.clBlack);
				}
		}

		Integer contador = 0;
		for (; contador < 2 * n;) {
			xi.min = memo.readDouble();
			if (memo.error)
				return img;

			xf.min = memo.readDouble();
			if (memo.error)
				return img;

			byte cor;
			if (n - contador > 0)
				cor = Util.clBlue;
			else
				cor = Util.clRed;

			pontoXY(xi.min, xf.min, 3, cor);
			if (contador % n != 0)
				lineXY(t, z, xi.min, xf.min, step, cor);
			t = xi.min;
			z = xf.min;
			contador++;
		}
		// passo 2
		for (;;) {
			xi = memo.readInterval();
			if (memo.error)
				return img;

			xf = memo.readInterval();
			if (memo.error)
				return img;

			pontoXY(xi.min, xf.min, 3, Util.clGreen);
			if (contador % n != 0)
				lineXY(tt, nn, xi.min, xf.min, step, Util.clGreen);
			tt = xi.min;
			nn = xf.min;

			pontoXY(xi.max, xf.max, 3, Util.clRed);
			lineXY(t, z, xi.max, xf.max, step, Util.clRed);
			t = xi.max;
			z = xf.max;
			contador++;
		}
	}

	public byte[] baixarGraficoInterval(HttpSession session, HttpServletRequest req) {
		String nomearq;
		if (req.getServerPort() == 8081)
			nomearq = req.getScheme() + "://" + req.getServerName() + ":" + req.getServerPort() + "/img/esqueleto.bmp";
		else
			nomearq = req.getScheme() + "://" + req.getServerName() + "/img/esqueleto.bmp";

		try {
			URL u = new URL(nomearq);
			InputStream fis = u.openStream();
			img = new byte[787510];
			fis.read(img, 0, 1077);
			for (int i = 1078; i < 787510; i++) // 1024 * 768+ 1078
				img[i] = (byte) 255;
			fis.close();
		} catch (IOException e) {
			img = new byte[1];
			img[0] = 0;
			return img;
		}

		String resto;
		try {
			resto = session.getAttribute("fuzzy3").toString();
		} catch (Exception e) {
			resto = "Error 404";
		}

		bottomLeft = new XY();
		topRight = new XY();
		Integer x = resto.indexOf("\n");
		if (x < 0)
			return img;
		String target = resto.substring(0, x);
		resto = resto.substring(x + 1);
		try {
			bottomLeft.x = Double.parseDouble(target);
		} catch (NumberFormatException e) {
			return img;
		}

		x = resto.indexOf("\n");
		if (x < 0)
			return img;
		target = resto.substring(0, x);
		resto = resto.substring(x + 1);
		try {
			topRight.x = Double.parseDouble(target);
		} catch (NumberFormatException e) {
			return img;
		}

		x = resto.indexOf("\n");
		if (x < 0)
			return img;
		target = resto.substring(0, x);
		resto = resto.substring(x + 1);
		try {
			bottomLeft.y = Double.parseDouble(target);
		} catch (NumberFormatException e) {
			return img;
		}

		x = resto.indexOf("\n");
		if (x < 0)
			return img;
		target = resto.substring(0, x);
		resto = resto.substring(x + 1);
		try {
			topRight.y = Double.parseDouble(target);
		} catch (NumberFormatException e) {
			return img;
		}

		q = new XY(1024.0 / (topRight.x - bottomLeft.x), 768.0 / (topRight.y - bottomLeft.y));
		Double step = q.x;
		if (q.y > step)
			step = q.y;
		step = 0.1 / step;

		Double t = bottomLeft.x, xx, yy, tt = 0.0, z = 0.0;
		while (t <= topRight.x) {
			pontoXY(t, 0.0, 0, Util.clBlack);
			t = t + step;
		}
		t = bottomLeft.y;
		while (t <= topRight.y) {
			pontoXY(0.0, t, 0, Util.clBlack);
			t = t + step;
		}
		showTime();
		x = resto.indexOf("\n");
		if (x < 0)
			return img;
		target = resto.substring(0, x);
		resto = resto.substring(x + 1);
		Double nn;
		Integer n;
		try {
			nn = Double.parseDouble(target);
			n = nn.intValue();
		} catch (NumberFormatException e) {
			return img;
		}

		Boolean notFirst = false;
		for (;;) {
			x = resto.indexOf("\n");
			if (x < 0)
				return img;
			target = resto.substring(0, x);
			resto = resto.substring(x + 1);
			Interval xi = new Interval();
			try {
				xi.min = Double.parseDouble(target);
			} catch (NumberFormatException e) {
				return img;
			}

			x = resto.indexOf("\n");
			if (x < 0)
				return img;
			target = resto.substring(0, x);
			resto = resto.substring(x + 1);
			try {
				xi.max = Double.parseDouble(target);
			} catch (NumberFormatException e) {
				return img;
			}

			x = resto.indexOf("\n");
			if (x < 0)
				return img;
			target = resto.substring(0, x);
			resto = resto.substring(x + 1);
			Interval y = new Interval();
			try {
				y.min = Double.parseDouble(target);
			} catch (NumberFormatException e) {
				return img;
			}

			x = resto.indexOf("\n");
			if (x < 0)
				return img;
			target = resto.substring(0, x);
			resto = resto.substring(x + 1);
			try {
				y.max = Double.parseDouble(target);
			} catch (NumberFormatException e) {
				return img;
			}

			byte cor;
			if (n > 0) {
				cor = Util.clBlue;
				xx = xi.avg();
				yy = y.avg();
			} else {
				pontoXY(xi.min, y.min, 3, Util.clGreen);
				if (notFirst)
					lineXY(t, z, xi.min, y.min, step, Util.clGreen);
				t = xi.min;
				z = y.min;
				cor = Util.clRed;
				xx = xi.max;
				yy = y.max;
			}

			pontoXY(xx, yy, 3, cor);
			if (notFirst)
				lineXY(tt, nn, xx, yy, step, cor);
			tt = xx;
			nn = yy;
			n--;
			notFirst = !n.equals(0);
		}
	}

}
