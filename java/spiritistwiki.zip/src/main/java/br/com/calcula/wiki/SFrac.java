package br.com.calcula.wiki;

public class SFrac {
	public String n, d;

	public static final int halfYPositive = 0;
	public static final int halfYNegative = 1;
	public static final int halfXPositive = 2;
	public static final int halfXNegative = 3;
	public static final int halfAll = 4;

	public static SFrac Str2Frac(String x) {
		SFrac Result = new SFrac();
		int i = x.indexOf('_');
		if (i > 0) {
			Result.n = x.substring(0, i);
			Result.d = x;
			Result.d = Util.delete(Result.d, 1, i + 1);
		} else {
			Result.n = x;
			Result.d = "1";
		}
		return Result;
	}

	public static boolean coprime(String x, String y) {
		if (x.endsWith("."))
			x = Util.delete(x, x.length(), 1);
		return SNum.mdc(x, y).equals("1");
	}

	public static boolean bloqueio(String x, String y, boolean co_prime, int halfMode, boolean checkTwoHalves) {
		boolean Result;

		if (x.endsWith(".") && checkTwoHalves)
			Result = true;
		else if (co_prime && (!coprime(x, y)) && checkTwoHalves)
			Result = true;
		else if ((halfMode == halfYPositive) && Util.charInSet(y.charAt(0), "0-"))
			Result = true;
		else if ((halfMode == halfXPositive) && Util.charInSet(x.charAt(0), "0-"))
			Result = true;
		else if ((halfMode == halfYNegative) && (y.charAt(0) != '-'))
			Result = true;
		else if ((halfMode == halfXNegative) && (x.charAt(0) != '-'))
			Result = true;
		else
			Result = false;

		return Result;
	}

	// Basta checkar em [theta_0, theta_0 + pi/4]
	public static int region(String x, String y) {
		int Result;

		if ((SNum.SNumCompare(y, "0") >= 0) && (SNum.SNumCompare(y, x) < 0))
			Result = 1;
		else if ((SNum.SNumCompare(y, x) >= 0) && (SNum.SNumCompare(x, "0") > 0))
			Result = 2;
		else if ((SNum.SNumCompare(x, "0") <= 0) && (SNum.SNumCompare(y, SNum.SNumOposto(x)) > 0))
			Result = 3;
		else if ((SNum.SNumCompare(y, SNum.SNumOposto(x)) <= 0) && (SNum.SNumCompare(y, "0") > 0))
			Result = 4;
		else if ((SNum.SNumCompare(y, "0") <= 0) && (SNum.SNumCompare(y, x) > 0))
			Result = 5;
		else if ((SNum.SNumCompare(y, x) <= 0) && (SNum.SNumCompare(x, "0") < 0))
			Result = 6;
		else if ((SNum.SNumCompare(x, "0") >= 0) && (SNum.SNumCompare(y, SNum.SNumOposto(x)) < 0))
			Result = 7;
		else
			Result = 8;

		return Result;
	}

	public static SFrac Incrementar(String p, String q, boolean co_prime, int halfMode, String n) {
		SFrac Result = new SFrac();
		while (SNum.SNumCompare(n, "0") > 0) {
			Result = Incrementar(p, q, co_prime, halfMode);
			p = Result.n;
			q = Result.d;
			n = SNum.Subtrai(n, "1");
		}
		return Result;
	}

	public static SFrac Incrementar(String p, String q, boolean co_prime, int halfMode) {
		SFrac Result = new SFrac();
		String m, rr, x, y;
		int i, reg;

		if (co_prime) {
			m = SNum.mdc(p, q);
			Result = SNum.Divide(p, m);
			x = Result.n;
			rr = Result.d;
			Result = SNum.Divide(q, m);
			y = Result.n;
			rr = Result.d;
		} else {
			x = p;
			y = q;
		}

		rr = SNum.Soma(SNum.Multiplica(x, x), SNum.Multiplica(y, y));
		if ((halfMode == halfXNegative) && (SNum.SNumCompare(x, "0") > 0)) {
			x = "0";
			y = SNum.FracPower(rr, "1_2");
		} else if ((halfMode == halfYNegative) && (SNum.SNumCompare(y, "0") > 0)) {
			x = SNum.SNumOposto(SNum.FracPower(rr, "1_2"));
			y = "0";
		} else if ((halfMode == halfXPositive) && (SNum.SNumCompare(x, "0") < 0)) {
			x = "0";
			y = SNum.SNumOposto(SNum.FracPower(rr, "1_2"));
		} else if ((halfMode == halfYPositive) && (SNum.SNumCompare(y, "0") < 0)) {
			x = SNum.FracPower(rr, "1_2");
			y = "0";
		}
		if (!SNum.Soma(SNum.Multiplica(x, x), SNum.Multiplica(y, y)).equals(rr))
			x = x + ".";

		reg = region(x, y);
		i = -2;

		do {
			if (x.endsWith("."))
				x = Util.delete(x, x.length(), 1);
			if ((SNum.SNumCompare(y, "0") > 0) || y.equals("0") && (SNum.SNumCompare(x, "0") > 0)) {
				while (SNum.SNumCompare(SNum.Subtrai(x, "1"), SNum.SNumOposto(SNum.FracPower(rr, "1_2"))) > 0) {
					x = SNum.Subtrai(x, "1");
					y = SNum.FracPower(SNum.Subtrai(rr, SNum.Multiplica(x, x)), "1_2");
					if (!SNum.Soma(SNum.Multiplica(x, x), SNum.Multiplica(y, y)).equals(rr))
						x = x + ".";

					if (!bloqueio(x, y, co_prime, halfMode, true)) {
						Result.n = x;
						Result.d = y;
						return Result;
					}

					if ((region(x, y) != reg) && (!bloqueio(x, y, co_prime, halfMode, false))) {
						i++;
						if (i == 1)
							break;
						reg = region(x, y);
					}
					if (x.endsWith("."))
						x = Util.delete(x, x.length(), 1);
				}

				if (i < 1) {
					if (x.endsWith("."))
						x = Util.delete(x, x.length(), 1);
					if (co_prime) {
						x = SNum.SNumOposto(SNum.FracPower(SNum.Subtrai(rr, "1"), "1_2"));
						y = "-1";
					} else {
						x = SNum.SNumOposto(SNum.FracPower(rr, "1_2"));
						y = "0";
					}
					if (!SNum.Soma(SNum.Multiplica(x, x), SNum.Multiplica(y, y)).equals(rr))
						x = x + ".";

					if (!bloqueio(x, y, co_prime, halfMode, true)) {
						Result.n = x;
						Result.d = y;
						return Result;
					}
					if (x.endsWith("."))
						x = Util.delete(x, x.length(), 1);
					if (!co_prime)
						x = SNum.Subtrai(x, "1");// y = 0 is welcome. x = x - 1 + 1
				}
			}

			if (i < 1) {
				if (x.endsWith("."))
					x = Util.delete(x, x.length(), 1);
				while (SNum.SNumCompare(SNum.Soma(x, "1"), SNum.FracPower(rr, "1_2")) < 0) {
					x = SNum.Soma(x, "1");
					y = SNum.SNumOposto(SNum.FracPower(SNum.Subtrai(rr, SNum.Multiplica(x, x)), "1_2"));
					if (!SNum.Soma(SNum.Multiplica(x, x), SNum.Multiplica(y, y)).equals(rr))
						x = x + ".";
					if (!bloqueio(x, y, co_prime, halfMode, true)) {
						Result.n = x;
						Result.d = y;
						return Result;
					}

					if ((region(x, y) != reg) && (!bloqueio(x, y, co_prime, halfMode, false))) {
						i++;
						if (i == 1)
							break;
						reg = region(x, y);
					}
					if (x.endsWith("."))
						x = Util.delete(x, x.length(), 1);
				}
			}

			rr = SNum.Soma(rr, "1");
			if (co_prime) {
				x = SNum.FracPower(SNum.Subtrai(rr, "1"), "1_2");
				y = "1";
			} else {
				x = SNum.FracPower(rr, "1_2");
				y = "0";
			}
			if (!SNum.Soma(SNum.Multiplica(x, x), SNum.Multiplica(y, y)).equals(rr))
				x = x + ".";

			if (!bloqueio(x, y, co_prime, halfMode, true)) {
				Result.n = x;
				Result.d = y;
				return Result;
			}

			reg = 1;// region(x, y);
			i = -2;

			if (x.endsWith("."))
				x = Util.delete(x, x.length(), 1);
			if (!co_prime)
				x = SNum.Soma(x, "1");// y = 0 is welcome. x = x + 1 - 1
		} while (true);

		// return Result;
	}

}
