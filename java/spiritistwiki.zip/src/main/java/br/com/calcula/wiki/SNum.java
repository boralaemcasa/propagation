package br.com.calcula.wiki;

import java.util.ArrayList;

public class SNum {

	public static Double FracToDouble(String s) {
		SFrac qr = SFrac.Str2Frac(s);
		int offset;
		if (qr.n.startsWith("-"))
			offset = 1;
		else
			offset = 0;
		Integer x = qr.n.length() - 1 - offset;
		qr.n += "e" + x.toString();
		qr.n = Util.insert(".", qr.n, 2 + offset);
		if (qr.d.startsWith("-"))
			offset = 1;
		else
			offset = 0;
		x = qr.d.length() - 1 - offset;
		qr.d += "e" + x.toString();
		qr.d = Util.insert(".", qr.d, 2 + offset);
		return Double.parseDouble(qr.n) / Double.parseDouble(qr.d);
	}

	public static String DoubleToFrac(Double x) {
		String denom = "1";
		while (!x.equals(Math.floor(x))) {
			x *= 10.0;
			denom = denom + "0";
		}
		String num = x.toString().toUpperCase();
		int i = num.indexOf("E");
		if (i >= 0) {
			String expoente = num.substring(i + 1);
			Integer e = Integer.parseInt(expoente);
			num = num.substring(0, i);
			num = Util.delete(num, num.indexOf(".") + 1, 1);
			while (num.length() < e)
				num = num + "0";
		}
		else if (num.endsWith(".0"))
			num = num.substring(0, num.length() - 2);
		return FracReduz(num + "_" + denom);
	}

	public static String ZeroLTrim(String s) {
		while ((s.charAt(0) == '0') && (s.length() > 1) && (s.charAt(1) != '_'))
			s = Util.delete(s, 1, 1);
		return s;
	}

	public static String Soma(String y, String z) {

		if (y.equals("0"))
			return z;
		if (z.equals("0"))
			return y;

		int i, x;
		char carry;
		boolean minus;
		String Result;

		i = y.length();
		x = z.length();
		if (x > i)
			i = x;
		String a = y;
		String b = z;

		minus = false;
		if (a.charAt(0) == '-') {
			a = Util.delete(a, 1, 1);
			if (b.charAt(0) == '-') {
				b = Util.delete(b, 1, 1);
				// -a + (-b) == -(a + b)
				minus = true;
			} else {
				// -a + b == b - a
				Result = Subtrai(b, a);
				return Result;
			}
		} else if (b.charAt(0) == '-') {
			b = Util.delete(b, 1, 1);
			// a + (-b) == a - b
			Result = Subtrai(a, b);
			return Result;
		}

		if (a.length() > b.length()) {
			Result = a;
			a = b;
			b = Result;
		}

		x = b.length();
		while (a.length() < x)
			a = "0" + a;

		// 008765
		// 123400
		i = x;
		while ((i > 1) && (b.charAt(i - 1) == '0'))
			i--;

		Result = "";
		if (i <= a.length())
			Result = a.substring(i, x - i + i);
		a = Util.delete(a, i + 1, x - i);
		b = Util.delete(b, i + 1, x - i);

		carry = 0;
		for (;i >= 1;i--) {
			x = a.charAt(i - 1) - 48 + b.charAt(i - 1) - 48 + carry;
			if (x >= 10) {
				carry = 1;
				x -= 10;
			} else
				carry = 0;
			Result = Util.charLeftConcat((char) (x + 48), Result);
		}
		if (carry != 0)
			Result = "1" + Result;
		if (minus)
			Result = "-" + Result;

		return Result;
	}

	public static String Subtrai(String y, String z) {
		if (y.equals("0"))
			return SNumOposto(z);
		if (z.equals("0"))
			return y;
		if (y.equals(z))
			return "0";

		int i, x;
		char carry;
		String Result;

		i = y.length();
		x = z.length();
		if (x > i)
			i = x;
		String a = y;
		String b = z;

		if (a.charAt(0) == '-') {
			a = Util.delete(a, 1, 1);
			if (b.charAt(0) == '-') {
				b = Util.delete(b, 1, 1);
				// -a - (-b) == b - a
				Result = Subtrai(b, a);
				return Result;
			} else {
				// -a - b == -(a + b)
				String c = Soma(a, b);
				Result = c;
				Result = "-" + Result;
				return Result;
			}
		} else if (b.charAt(0) == '-') {
			b = Util.delete(b, 1, 1);
			// a - (-b) == a + b
			Result = Soma(a, b);
			return Result;
		} else if (SNumCompare(a, b) < 0) {
			// a < b ==> a - b == -(b - a)
			String c = Subtrai(b, a);
			Result = c;
			c = "-" + Result;
			return c;
		}
		// 923
		// 199
		x = a.length();
		while (b.length() < x)
			b = "0" + b;
		Result = "";
		carry = 0;
		for (i = a.length();i >= 1;i--) {
			x = a.charAt(i - 1) - 48 - b.charAt(i - 1) + 48 - carry;
			if (x < 0) {
				carry = 1;
				x += 10;
			} else
				carry = 0;
			Result = Util.charLeftConcat((char) (x + 48), Result);
		}

		Result = ZeroLTrim(Result);
		return Result;
	}

	public static String Multiplica(String y, String z) {
		if (y.equals("0") || z.equals("0"))
			return "0";
		if (y.equals("1"))
			return z;
		if (z.equals("1"))
			return y;
		if (y.equals("-1"))
			return SNumOposto(z);
		if (z.equals("-1"))
			return SNumOposto(y);
		int i, j;
		char x, carry;
		boolean minus;
		String subtotal, Result;
		ArrayList<String> multAlgarismo = new ArrayList<String>();

		String a = y;
		String b = z;

		minus = (a.charAt(0) == '-');
		if (minus)
			a = Util.delete(a, 1, 1);
		if (b.charAt(0) == '-') {
			b = Util.delete(b, 1, 1);
			minus = !minus;
		}

		multAlgarismo.add(0, "");
		multAlgarismo.add(1, "");
		for (i = 2;i <= 9;i++) {
			multAlgarismo.add(i, "");
			carry = 0;

			// multiplicar i por cada algarismo de a
			for (j = a.length();j >= 1;j--) {
				x = (char) ((a.charAt(j - 1) - 48) * i + carry);
				carry = (char) (x / 10);
				x = (char) (x % 10);
				multAlgarismo.set(i, Util.charLeftConcat((char) (x + 48), multAlgarismo.get(i)));
			}

			if (carry != 0)
				multAlgarismo.set(i, Util.charLeftConcat((char) (carry + 48), multAlgarismo.get(i)));
		}

		subtotal = "";
		Result = "0";
		for (i = b.length();i >= 1;i--)
			if (b.charAt(i - 1) != '0') {
				subtotal = "";
				// zeros aa direita
				if (i < b.length())
					for (j = 1;j <= b.length() - i;j++)
						subtotal = "0" + subtotal;

				if (b.charAt(i - 1) == '1')
					subtotal = a + subtotal;
				else
					subtotal = multAlgarismo.get(b.charAt(i - 1) - 48) + subtotal;

				// o Resultado � a soma dos subtotais
				Result = Soma(Result, subtotal);
			}

		Result = ZeroLTrim(Result);

		if (minus && (!Result.equals("0"))) {
			Result = "-" + Result;
		}

		return Result;
	}

	public static SFrac Divide(String alinha, String blinha) {
		SFrac qr = new SFrac();

		if (blinha.equals("0")) {
			qr.n = "0";
			qr.d = "0";
			return qr;
		}
		if (alinha.equals("0")) {
			qr.n = "0";
			qr.d = "0";
			return qr;
		}
		if (blinha.equals("1")) {
			qr.n = alinha;
			qr.d = "0";
			return qr;
		}
		if (alinha.equals(blinha)) {
			qr.n = "1";
			qr.d = "0";
			return qr;
		}
		String a = SNumOposto(alinha);
		if (a.equals(blinha)) {
			qr.n = "-1";
			qr.d = "0";
			return qr;
		}
		if (blinha.equals("-1")) {
			qr.n = a;
			qr.d = "0";
			return qr;
		}

		boolean minusa, minusb;
		char x;
		int index;

		a = alinha;
		String b = blinha;

		minusa = (a.charAt(0) == '-');
		minusb = (b.charAt(0) == '-');
		if (minusa)
			a = Util.delete(a, 1, 1);
		if (minusb)
			b = Util.delete(b, 1, 1);

		qr.n = "";
		index = b.length();
		if (index > a.length())
			index = a.length();
		qr.d = a.substring(0, index);
		do {
			x = 0;
			while (SNumCompare(qr.d, b) >= 0) {
				x++;
				String rr = Subtrai(qr.d, b);
				qr.d = rr;
			}
			qr.n = qr.n + Util.char2String((char) 1);
			qr.n = qr.n.replace((char) 1, (char) (x + 48));
			if (index >= a.length())
				break;

			// "baixar" o pr�ximo
			index++;
			if (qr.d.equals("0"))
				qr.d = "";// zero de resto nao vai virar zero aa esq
			qr.d = qr.d + Util.char2String((char) 1);
			qr.d = qr.d.replace((char) 1, a.charAt(index - 1));

		} while (true);

		qr.n = ZeroLTrim(qr.n);

		// 7 / 4 == ( 1, 3) a < 0, r > 0: incrementar o m�dulo do quociente
		// -7 / 4 == (-2, 1) complementar o resto
		// 7 / -4 == (-1, 3) exatamente um negativo: sinal '-' no quociente
		// -7 / -4 == ( 2, 1)
		if (minusa && (!qr.d.equals("0"))) {
			String qq = Soma(qr.n, "1");
			String rr = Subtrai(b, qr.d);
			qr.n = qq;
			qr.d = rr;
		}
		if (minusa ^ minusb)
			qr.n = "-" + qr.n;

		return qr;
	}

	public static String Potencia(String a, String b) {
		String Result, n;
		n = b;

		if ((n.charAt(0) == '0') || (n.charAt(0) == '-'))
			Result = "1";
		else {
			Result = a;
			while (!n.equals("1")) {
				Result = Multiplica(Result, a);
				n = Subtrai(n, "1");
			}
		}
		return Result;
	}

	public static String mdc(String x, String y) {
		SFrac qr = new SFrac();

		if (x.equals("0"))
			return y;

		if (y.equals("0"))
			return x;

		String xx, yy;

		xx = SNumAbs(x);
		yy = SNumAbs(y);

		if (SNumCompare(yy, xx) > 0) {
			qr.n = xx;
			xx = yy;
			yy = qr.n;
		}

		do {
			qr.n = "";
			qr.d = "";
			qr = Divide(xx, yy);
			if (qr.d.equals("1") || qr.d.equals("0"))
				break;
			xx = yy;
			yy = qr.d;
		} while (true);

		if (qr.d.equals("1")) {
			return "1";
		} else {
			return yy;
		}
	}

	public static String mmc(String x, String y) {
		SFrac qr = new SFrac();
		qr = Divide(x, mdc(x, y));
		return Multiplica(qr.n, y);
	}

	public static String SNumAbs(String a) {
		if (a.charAt(0) != '-')
			return a;
		else
			return SNumOposto(a);
	}

	public static String SNumOposto(String s) {
		String Result;

		if (s.equals("0")) {
			Result = "0";
		} else if (s.charAt(0) == '-') {
			Result = s;
			Result = Util.delete(Result, 1, 1);
		} else {
			Result = s;
			Result = "-" + Result;
		}

		return Result;
	}

	public static int SNumCompare(String a, String b) {
		if (a.endsWith("."))
			b = b + ".";
		if (b.endsWith("."))
			a = a + ".";

		boolean minus;
		int Result = 0;
		if (a.equals(b))
			return Result;
		minus = false;
		if (a.charAt(0) == '-')
			if (b.charAt(0) == '-')
				minus = true;
			else
				Result = -1;
		else if (b.charAt(0) == '-')
			Result = 1;

		if (Result != 0)
			return Result;

		if (b.charAt(0) == '0')
			return 1;
		if (a.charAt(0) == '0')
			return -1;

		int tamanho1 = a.length();
		int tamanho2 = b.length();
		if (tamanho2 > tamanho1)
			tamanho1 = tamanho2;

		String alinha = a;
		String blinha = b;

		if (minus) {
			alinha = Util.delete(alinha, 1, 1);
			blinha = Util.delete(blinha, 1, 1);
		}

		while (blinha.length() < alinha.length())
			blinha = "0" + blinha;
		while (alinha.length() < blinha.length())
			alinha = "0" + alinha;

		// positivos
		if (alinha.compareTo(blinha) > 0)
			Result = 1;
		else
			Result = -1;

		// negativos inverte
		if (minus)
			Result = -Result;
		return Result;
	}

	public static String sqrt(String n, String x) {
		String i, min, max;
		SFrac qr = new SFrac();
		String Result;

		if (x.charAt(0) == '-')
			return "0";

		min = "";
		max = "";
		Integer L = x.length();
		qr = Divide(L.toString(), n);
		i = Subtrai("1", qr.d);
		if (i.charAt(0) == '-')
			i = "0";
		while (SNumCompare(i, qr.n) <= 0) {
			max = max + "9";
			min = min + "0";
			i = Soma(i, "1");
		}
		min = Util.delete(min, 1, 1);
		min = Util.char2String((char) 1) + min;
		min = min.replace(Util.char2String((char) 1), "1");

		do {
			qr = Divide(Soma(min, max), "2");
			Result = qr.n;
			qr.d = Potencia(Result, n);
			if (qr.d.equals(x))
				return Result;
			if (SNumCompare(qr.d, x) < 0)
				min = Soma(Result, "1");
			else
				max = Subtrai(Result, "1");

		} while (SNumCompare(min, max) <= 0);

		Result = max;
		return Result;
	}

	public static String binom(String n, String p) {
		String inti, j;
		String Result = "1";
		if (n.equals(p))
			return Result;

		if (p.contains("_")) {
			if (n.contains("_"))
				p = FracSub(n, p);
		} else if (FracCompare(p, "0") < 0)
			p = FracSub(n, p);

		if (p.equals("0"))
			return Result;
		if (FracCompare(p, "0") < 0)
			return "-pi";// factorial of negative

		if (p.contains("_"))
			return "pi";// Gamma solves

		// binom(21/2, 6) = 21/2/1 * 19/2/2 * 17/2/3 * 15/2/4 * 13/2/5 * 11/2/6
		Result = n;
		inti = "2";
		j = FracSub(n, "1");
		while ((!Result.equals("0")) && (FracCompare(inti, p) <= 0)) {
			Result = FracDiv(FracMul(Result, j), inti);
			inti = Soma(inti, "1");
			j = FracSub(j, "1");
		}
		return Result;
	}

	public static String FracAdd(String x, String y) {
		if (x.equals("0"))
			return y;
		if (y.equals("0"))
			return x;
		if ((!x.contains("_")) && (!y.contains("_")))
			return Soma(x, y);

		SFrac a = new SFrac(), b = new SFrac();
		String Result;
		a = SFrac.Str2Frac(x);
		b = SFrac.Str2Frac(y);
		String anbd = Multiplica(a.n, b.d);
		String adbn = Multiplica(a.d, b.n);
		String adbd = Multiplica(a.d, b.d);
		String s = Soma(anbd, adbn);
		Result = s + "_" + adbd;
		Result = FracReduz(Result);
		return Result;
	}

	public static String FracSub(String x, String y) {
		if (x.equals("0"))
			return SNumOposto(y);
		if (y.equals("0"))
			return x;
		if (x.equals(y))
			return "0";
		if ((!x.contains("_")) && (!y.contains("_")))
			return Subtrai(x, y);
		SFrac a = new SFrac(), b = new SFrac();
		String Result;
		a = SFrac.Str2Frac(x);
		b = SFrac.Str2Frac(y);
		b.n = SNumOposto(b.n);
		String anbd = Multiplica(a.n, b.d);
		String adbn = Multiplica(a.d, b.n);
		String adbd = Multiplica(a.d, b.d);
		String s = Soma(anbd, adbn);
		Result = s + "_" + adbd;
		Result = FracReduz(Result);
		return Result;
	}

	public static String FracMul(String x, String y) {
		if (x.equals("0") || y.equals("0"))
			return "0";
		if (x.equals("1"))
			return y;
		if (y.equals("1"))
			return x;
		if (x.equals("-1"))
			return SNumOposto(y);
		if (y.equals("-1"))
			return SNumOposto(x);
		if ((!x.contains("_")) && (!y.contains("_")))
			return Multiplica(x, y);

		SFrac a = new SFrac(), b = new SFrac();
		String Result;
		a = SFrac.Str2Frac(x);
		b = SFrac.Str2Frac(y);
		String anbn = Multiplica(a.n, b.n);
		String adbd = Multiplica(a.d, b.d);
		Result = anbn + "_" + adbd;
		Result = FracReduz(Result);
		return Result;
	}

	public static String FracDiv(String x, String y) {
		if (y.equals("1"))
			return x;
		if (y.equals("-1"))
			return SNumOposto(x);
		if (x.equals("0") || y.equals("0"))
			return "0";
		if (x.equals(y))
			return "1";

		SFrac a = new SFrac(), b = new SFrac();
		String Result;
		a = SFrac.Str2Frac(x);
		b = SFrac.Str2Frac(y);
		String aux = b.n;
		b.n = b.d;
		b.d = aux;
		if (b.d.charAt(0) == '-') {
			b.n = SNumOposto(b.n);
			b.d = SNumOposto(b.d);
		}

		String anbn = Multiplica(a.n, b.n);
		String adbd = Multiplica(a.d, b.d);
		Result = anbn + "_" + adbd;
		Result = FracReduz(Result);
		return Result;
	}

	public static String FracPower(String x, String y) {
		SFrac s = new SFrac();
		String n, Result;

		if (y.equals("0"))
			return "1";

		s = SFrac.Str2Frac(y);
		if (!s.d.equals("1")) { // sqrt
			n = s.d;
			Result = FracPower(x, s.n);
			s = SFrac.Str2Frac(Result);
			s.n = sqrt(n, s.n);
			s.d = sqrt(n, s.d);
			Result = s.n;
			if ((!s.d.equals("1")) && (!s.n.equals("0")))
				Result = Result + "_" + s.d;
			return FracReduz(Result);
		}

		if (y.charAt(0) == '-') {
			x = FracDiv("1", x);
			y = SNumOposto(y);
		}

		Result = x;
		while (!y.equals("1")) {
			Result = FracMul(Result, x);
			y = Subtrai(y, "1");
		}

		return Result;
	}

	public static String FracReduz(String x) {
		if (!x.contains("_"))
			return x;

		SFrac a = new SFrac(), b = new SFrac();
		String m;

		a = SFrac.Str2Frac(x);
		if (a.d.equals(""))
			return x;
		m = mdc(a.n, a.d);
		if (!m.equals("1")) {
			b.n = a.n;
			b.d = a.d;
			// r = "";
			SFrac qr = Divide(a.n, m);
			b.n = qr.n;
			qr = Divide(a.d, m);
			b.d = qr.n;

			x = b.n;
			if (!b.d.equals("1")) {
				x = x + "_" + b.d;
			}
		} else if (a.d.equals("1"))
			x = a.n;

		return x;
	}

	public static int FracCompare(String x, String y) {
		if (y.equals("0")) {
			if (x.equals("0"))
				return 0;
			else if (x.charAt(0) == '-')
				return -1;
			else
				return 1;
		}

		if ((!x.contains("_")) && (!y.contains("_")))
			return SNumCompare(x, y);

		String dif = FracSub(x, y);
		SFrac s = SFrac.Str2Frac(dif);
		int Result = SNumCompare(s.n, "0");
		return Result;
	}

	public static String FracFloor(String x) {
		SFrac s = new SFrac(), qr = new SFrac();
		s = SFrac.Str2Frac(x);
		qr = Divide(s.n, s.d);
		return qr.n;
	}

	public static String FracGamma(String erro, String z) {
		String Result = "1";
		if (FracCompare(z, "0") <= 0)
			return Result;
		if (z.equals("1"))
			return Result;
		if (z.contains("_")) {
			if (FracCompare(erro, "0") <= 0)
				return Result;

			/*
			 * String soma = "0", termo, n = "1";do { termo = FracMul(z, ln(erro,
			 * FracAdd("1", FracDiv("1", n))));termo = FracSub(termo, ln(erro, FracAdd("1",
			 * FracDiv(z, n))));soma = FracAdd(soma, termo);n = Soma(n, "1");} while
			 * (FracCompare(SNumAbs(termo), erro) >= 0);
			 *
			 * return FracMul(FracDiv("1", z), FracExp(erro, soma));
			 */

			String endValue = FracDiv(erro, "2"), s = FracSub("1", endValue);
			Result = "0";
			do {
				Result = FracAdd(Result, FracMul(FracPower(SNumOposto(ln(erro, s)), z), erro));
				s = FracSub(s, erro);
			} while (FracCompare(s, endValue) >= 0);

			return Result;
		}

		String j;
		z = Subtrai(z, "1");// Gamma(z) = (z - 1)!

		Result = z;
		j = FracSub(z, "1");
		while (SNumCompare(j, "1") >= 0) {
			Result = FracMul(Result, j);
			j = FracSub(j, "1");
		}
		return Result;
	}

	public static String ln(String erro, String x) {
		String n, termo, s, L, Result = "0";

		if ((x.charAt(0) == '-') || x.equals("0"))
			return Result;
		if (FracCompare(erro, "0") <= 0)
			return Result;

		if (FracCompare(x, "2") >= 0) {
			Integer i = FracFloor(x).length();
			L = i.toString();
			Result = FracSub(ln(erro, FracDiv(x, Potencia("10", L))), FracMul(L, ln(erro, "1_10")));
			return Result;
		}

		// ln (x + 1) = Sigma_1 (-1)^{n + 1} / n * x^n
		x = FracSub(x, "1");
		n = "1";
		termo = x;
		Result = termo;
		do {
			n = Soma(n, "1");
			termo = SNumOposto(termo);
			termo = FracMul(termo, x);
			s = FracDiv(termo, n);
			Result = FracAdd(Result, s);
		} while ((termo.charAt(0) != '-') || (FracCompare(SNumOposto(s), erro) >= 0));

		return Result;
	}

	public static String FracLog(String b, String erro, String x) {
		String Result = "0";
		if ((x.charAt(0) == '-') || x.equals("0"))
			return Result;
		if ((b.charAt(0) == '-') || b.equals("0") || b.equals("1"))
			return Result;
		if (b.equals(x))
			return "1";
		if (FracCompare(erro, "0") <= 0)
			return Result;
		Result = ln(erro, x);
		if (!b.equals("e"))
			Result = FracDiv(Result, ln(erro, b));
		return Result;
	}

	public static String FracExp(String erro, String x) {
		String n, termo, Result = "0";

		if (FracCompare(erro, "0") <= 0)
			return Result;
		// exp x = Sigma_0 x^n / n!
		n = "1";
		termo = x;
		Result = FracAdd("1", termo);
		do {
			n = Soma(n, "1");
			termo = FracMul(termo, x);
			termo = FracDiv(termo, n);
			Result = FracAdd(Result, termo);
		} while (FracCompare(SNumAbs(termo), erro) >= 0);

		return Result;
	}

	public static String Valida(String s) {
		String Result;
		int i = 1;
		if ((s == null) || s.equals(""))
			return "0";
		Result = s;
		if (Result.charAt(0) == '-')
			i++;
		while (i <= Result.length()) {
			if ((Result.charAt(i - 1) >= '0') && (Result.charAt(i - 1) <= '9'))
				i++;
			else
				Result = Util.delete(Result, i, 1);
		}

		if (Result.equals(""))
			return "0";

		Result = ZeroLTrim(Result);
		if (Result.equals("-0"))
			Result = "0";

		return Result;
	}

	public static String FracValida(String s) {
		if (s.contains(".") || s.contains("e") || s.contains("E")) {
			Double z = null;
			try {
				z = Double.parseDouble(s);
			} catch (Exception e) {

			}

			if (z != null)
				return DoubleToFrac(z);
		}

		String Result;
		int i = 1;

		if (s.equals("0") || s.equals("") || s.equals("-"))
			return "0";
		Result = s.replace("/", "_");
		if (Result.charAt(0) == '_')
			Result = "1" + Result;
		if (Result.charAt(0) == '-')
			i++;
		while (i <= Result.length()) {
			if ((Result.charAt(i - 1) >= '0') && (Result.charAt(i - 1) <= '9') || (Result.charAt(i - 1) == '_'))
				i++;
			else
				Result = Util.delete(Result, i, 1);
		}

		if (Result.equals(""))
			Result = "0";

		if ((Result.length() > 1) && (Result.charAt(0) == '-') && (Result.charAt(1) == '0'))
			Result = Util.delete(Result, 1, 1);

		Result = Result.replaceFirst("_", " ");

		i = 1;
		if (Result.charAt(0) == '-')
			i++;
		while (i <= Result.length()) {
			if ((Result.charAt(i - 1) >= '0') && (Result.charAt(i - 1) <= '9') || (Result.charAt(i - 1) == 32))
				i++;
			else
				Result = Util.delete(Result, i, 1);
		}

		Result = Result.replaceFirst(" ", "_");
		Result = ZeroLTrim(Result);
		Result = FracReduz(Result);

		return Result;
	}

	public static Boolean isPrime(String s) {
		SFrac frac = Divide(s, "2");
		if (frac.d.equals("0"))
			return false;

		String primo = "3";
		for (;;) {
			if (SNumCompare(Multiplica(primo, primo), s) > 0)
				return true;
			frac = Divide(s, primo);
			if (frac.d.equals("0"))
				return false;
			else
				primo = Soma(primo, "2");
		}
	}

	public static String nextPrime(String s) {
		if (s.equals("2"))
			return "3";

		s = Soma(s, "2");
		if (SNumCompare(s, "7") <= 0)
			return s;

		for (;;) {
			s = Soma(s, "2");
			if (isPrime(s))
				return s;
		}
	}

	public static ArrayList<String> divisores(String s) {
		ArrayList<String> lista = new ArrayList<String>();
		ArrayList<String> lista2 = new ArrayList<String>();

		if (s.startsWith("-"))
			s = SNumOposto(s);

		if (s.equals("0")) {
			lista.add("0");
			return lista;
		}

		lista.add("1");
		if (s.equals("1"))
			return lista;

		String primo = "2";
		for (;;) {
			SFrac frac = Divide(s, primo);
			if (frac.d.equals("0")) {
				s = frac.n;

				lista2.clear();
				for (String cadaUm : lista) // se tiver 1,2,3,6
					lista2.add(Multiplica(cadaUm, primo)); // multiplique por cada um por seja 5

				for (String cadaUm : lista2)
					if (!lista.contains(cadaUm))
						lista.add(cadaUm);

				if (s.equals("1"))
					break;
			} else
				primo = nextPrime(primo);
		}

		return lista;
	}
}
