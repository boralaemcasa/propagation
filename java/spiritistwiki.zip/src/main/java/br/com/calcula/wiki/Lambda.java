package br.com.calcula.wiki;

import java.util.ArrayList;

public class Lambda {

	public static String CommandProcess(String s) {
		String t, variable;
		int i = 0;
		char ch;
		s = s.replace("_", "\\").replace("/", "_");

		while (i < s.length()) {
			if (s.charAt(i) == '\\') {
				s = Util.delete(s, i + 1, 1);
				s = Util.insert("V", s, i);
			}
			i++;
		}

		i = s.indexOf('=');
		if (i >= 0) {
			t = s.substring(i, s.length());
			s = Util.delete(s, i, s.length());
		} else
			t = "";

		ch = 1;
		variable = "";
		if ((s.length() >= 10) && (s.substring(0, 10).equals("solve for "))) {
			s = Util.delete(s, 1, 10);
			i = s.indexOf(':');
			if (i >= 0) {
				variable = s.substring(0, i);
				s = Util.delete(s, 1, i + 1);
			}

			ch = IsVariable(variable);
			if (ch != 'x')
				return "Syntax Error\nsolve for [variable]: expected. Encountered: " + ch;

			if (t.equals(""))
				return "Syntax Error\n= symbol not found";
		}
		s = s.replace(" ", "");
		String Result = WithParenthesisProcess(false, s);
		if (Result.equals(""))
			return "";
		if (!t.equals("")) {
			s = WithParenthesisProcess(false, t);
			if (s.equals(""))
				return "";
			Result = Result + "=" + s;
		}

		do {
			s = Denominator(Result);
			if (s.equals(""))
				break;

			i = Result.indexOf('=');
			if (i >= 0) {
				t = Result.substring(i, Result.length());
				Result = Util.delete(Result, i, Result.length());
			} else
				t = "";

			if (s.equals(SNum.FracValida(s))) {
				Result = Distribution(s + "*", Result);
				if (!t.equals(""))
					t = Distribution(s + "*", t);
			} else {
				Result = Distribution(Result, s);
				if (!t.equals(""))
					t = Distribution(s, t);
			}

			Result = WithParenthesisProcess(true, Result);
			if (Result.equals(""))
				return "";
			if (!t.equals("")) {
				s = WithParenthesisProcess(true, t);
				if (s.equals(""))
					return "";
				Result = Result + "=" + s;
			}
		} while (true);

		if (ch == 'x') {
			s = SolveFor(variable, Result);
			if (!s.contains("ERROR: ")) {
				i = s.indexOf("=");
				if (i >= 0) {
					t = s.substring(i + 1, s.length());
					s = Util.delete(s, i + 1, s.length());
				} else
					t = "";

				s = s.replace(" ", "");
				Result = WithParenthesisProcess(true, s);
				if (Result.equals(""))
					return "";
				if (!t.equals("")) {
					s = WithParenthesisProcess(true, t);
					if (s.equals(""))
						return "";
					Result = Result + "=" + s;
				}
			} else
				Result = s;
		}

		if ((Result.length() > 0) && (Result.charAt(0) == '+'))
			Result = Util.delete(Result, 1, 1);
		Result = Result.replace("+", " + ");
		Result = Result.replace("-", " - ");
		Result = Result.replace("=", " = ");
		Result = Result.replace(" =  + ", " = ");
		Result = Result.replace("( -", "(-");
		Result = Result.replace("( + ", "(");
		Result = Result.replace(" =  - ", " = - ").trim();
		return Result.replace("_", "/");
	}

	public static char IsVariable(String s) {
		int i = 1;
		char Result;
		if (s.equals(""))
			Result = ' ';
		else if (Util.charInSet(s.charAt(0), "abcdefghijklmnopqrstuvwxyzV")) {
			while (i < s.length())
				if (Util.charInSet(s.charAt(i), "0123456789abcdefghijklmnopqrstuvwxyz"))
					i++;
				else
					return s.charAt(i);

			Result = 'x';// good
		} else
			Result = s.charAt(0);

		return Result;
	}

	public static String WithParenthesisProcess(boolean redirect, String s) {
		String Result;
		do {
			Result = WithParenthesisMONOProcess(redirect, s);
			if (Result.contains("Error"))
				break;
			if (Result.equals(s))
				break;
			s = Result;
		} while (true);
		return Result;
	}

	public static String WithParenthesisMONOProcess(boolean redirect, String s) {
		String t, target;
		int i, k;
		Integer j, max;
		boolean maxfound;
		ArrayList<String> memo, gcd, lcm, newton, frac;

		if (redirect && (!s.contains("(")))
			return NoParenthesisProcess(s);

		max = 0;

		// trim alphabet
		i = 0;
		while (i < s.length())
			if (Util.charInSet(s.charAt(i), "0123456789+-*_^(),abcdefghijklmnopqrstuvwxyzV"))
				i++;
			else
				s = Util.delete(s, i + 1, 1);

		if (s.equals(""))
			return "";

		if (!Util.charInSet(s.charAt(0), "0123456789(+-abcdefghijklmnopqrstuvwxyzV"))
			return "Syntax Error\n+, -, variable or digit or ( expected as first character";

		j = 0;
		memo = new ArrayList<String>();
		gcd = new ArrayList<String>();
		lcm = new ArrayList<String>();
		newton = new ArrayList<String>();
		frac = new ArrayList<String>();
		i = 0;
		while (i < s.length())
			if (Util.charInSet(s.charAt(i), "+-*_")) {
				if ((i + 1 >= s.length())
						|| (!Util.charInSet(s.charAt(i + 1), "0123456789(abcdefghijklmnopqrstuvwxyzV")))
					return "Syntax Error\nVariable or digit or ( expected after " + s.charAt(i);

				t = s.substring(0, i);
				if (!t.equals(""))
					memo.add(t);
				memo.add(Util.char2String(s.charAt(i)));
				s = Util.delete(s, 1, i + 1);
				i = 0;
			} else if (Util.charInSet(s.charAt(i), "(,")) {
				if ((i + 1 >= s.length())
						|| (!Util.charInSet(s.charAt(i + 1), "+-0123456789(abcdefghijklmnopqrstuvwxyzV")))
					return "Syntax Error\n+, - or ( or digit or variable expected after " + s.charAt(i);

				if (s.charAt(i) == ',')
					if ((gcd.size() == 0) && (newton.size() == 0) && (lcm.size() == 0))
						return "Syntax Error\nComma outside gcd or binom or lcm";
					else if (newton.size() > 0)
						if (newton.get(newton.size() - 1).equals(",")
								&& newton.get(newton.size() - 2).equals(j.toString()))
							return "Syntax Error\nInvalid third parameter for binom";
						else if (newton.get(newton.size() - 1).equals(j.toString()))
							newton.add(",");

				if ((i >= 1) && Util.charInSet(s.charAt(i - 1), "0123456789") && (s.charAt(i) == '(')) {
					s = Util.insert("*", s, i);
					i++;
				}
				if (s.charAt(i) == '(') {
					j++;
					if (max < j)
						max = j;
					if (memo.size() >= 1)
						if (memo.get(memo.size() - 1).equals("gcd"))
							gcd.add(j.toString());
						else if (memo.get(memo.size() - 1).equals("binom"))
							newton.add(j.toString());
						else if (memo.get(memo.size() - 1).equals("lcm"))
							lcm.add(j.toString());
				}
				t = s.substring(0, i);
				if (!t.equals(""))
					if (t.endsWith("*")) {
						memo.add(Util.delete(t, t.length(), 1));// nao é para deletar, é para copiar só
						memo.add("*");
					} else
						memo.add(t);
				if (s.charAt(i) == '(')
					memo.add(s.charAt(i) + j.toString());
				else
					memo.add(Util.char2String(s.charAt(i)));
				s = Util.delete(s, 1, i + 1);
				i = 0;
			} else if (s.charAt(i) == ')') {
				if (frac.size() > 0)
					if (frac.get(frac.size() - 1).equals(j.toString()))
						if ((i + 1 < s.length()) && (s.charAt(i + 1) == '(')) {
							frac.remove(frac.size() - 1);
							s = Util.insert("_", s, i + 2);
						} else
							return "Syntax Error\n( expected after " + s.charAt(i);

				if ((i + 1 < s.length()) && Util.charInSet(s.charAt(i + 1), "(0123456789abcdefghijklmnopqrstuvwxyzV"))
					s = Util.insert("*", s, i + 1);
				t = s.substring(0, i);
				if (!t.equals(""))
					memo.add(t);
				memo.add(s.charAt(i) + j.toString());
				if (gcd.size() > 0)
					if (gcd.get(gcd.size() - 1).equals(j.toString()))
						gcd.remove(gcd.size() - 1);
				if (lcm.size() > 0)
					if (lcm.get(lcm.size() - 1).equals(j.toString()))
						lcm.remove(lcm.size() - 1);
				if (newton.size() > 0)
					if (newton.get(newton.size() - 1).equals(",")
							&& newton.get(newton.size() - 2).equals(j.toString())) {
						newton.remove(newton.size() - 1);
						newton.remove(newton.size() - 1);
					} else if (newton.get(newton.size() - 1).equals(j.toString()))
						return "Syntax Error\nMissing second parameter for binom";

				j--;
				if (j < 0)
					return "Syntax Error\nExcess of )";

				s = Util.delete(s, 1, i + 1);
				i = 0;
			} else if ((i + 3 < s.length())
					&& (s.substring(i, i + 3).equals("gcd") || s.substring(i, i + 3).equals("abs")
							|| s.substring(i, i + 3).equals("log") || s.substring(i, i + 3).equals("lcm"))) {
				if (s.charAt(i + 3) != '(')
					return "Syntax Error\n( expected after " + s.substring(i, i + 3);

				t = s.substring(0, i);
				if (!t.equals(""))
					memo.add(t);
				memo.add(s.substring(i, i + 3));
				s = Util.delete(s, 1, i + 3);
				i = 0;
			} else if ((i + 5 < s.length()) && (s.substring(i, i + 5).equals("binom")
					|| s.substring(i, i + 5).equals("floor") || s.substring(i, i + 5).equals("gamma"))) {
				if (s.charAt(i + 5) != '(')
					return "Syntax Error\n( expected after " + s.substring(i, i + 5);

				t = s.substring(0, i);
				if (!t.equals(""))
					memo.add(t);
				memo.add(s.substring(i, i + 5));
				s = Util.delete(s, 1, i + 5);
				i = 0;
			} else if ((i + 4 < s.length()) && s.substring(i, i + 4).equals("frac")) {
				if (s.charAt(i + 4) != '(')
					return "Syntax Error\n( expected after " + s.substring(i, i + 4);

				t = s.substring(0, i);
				if (!t.equals(""))
					memo.add(t);
				j++;
				frac.add(j.toString());
				j--;
				s = Util.delete(s, 1, i + 4);
				i = 0;
			} else
				i++;

		if (j > 0)
			return "Syntax Error\nExcess of (";

		if (!s.equals(""))
			memo.add(s);

		if (max > 0)
			do {
				maxfound = false;
				i = 0;
				while (i < memo.size()) {
					if (memo.get(i).equals("(" + max.toString())) {
						if ((i >= 1) && memo.get(i - 1).equals("gcd")) {
							j = i + 1;
							s = "";
							while ((!memo.get(j).equals(",")) && (!memo.get(j).equals(")" + max.toString()))) {
								s = s + memo.get(j);
								j++;
							}
							s = WithParenthesisProcess(true, s);
							if (s.contains("_")) // only integers allowed to gcd
								s = "1";

							while (memo.get(j).equals(",")) {
								j++;
								t = "";
								while ((!memo.get(j).equals(",")) && (!memo.get(j).equals(")" + max.toString()))) {
									t = t + memo.get(j);
									j++;
								}
								t = WithParenthesisProcess(true, t);
								if (t.contains("_")) // only integers allowed to gcd
									t = "1";
								s = SNum.mdc(s, t);
							}

							memo.set(i + 1, s);
							while (!memo.get(i + 2).equals(")" + max.toString()))
								memo.remove(i + 2);

							memo.remove(i - 1);
							i--;
						} else if ((i >= 1) && memo.get(i - 1).equals("lcm")) {
							j = i + 1;
							s = "";
							while ((!memo.get(j).equals(",")) && (!memo.get(j).equals(")" + max.toString()))) {
								s = s + memo.get(j);
								j++;
							}
							s = WithParenthesisProcess(true, s);
							if (s.contains("_")) // only integers allowed to lcm
								s = "1";

							while (memo.get(j).equals(",")) {
								j++;
								t = "";
								while ((!memo.get(j).equals(",")) && (!memo.get(j).equals(")" + max.toString()))) {
									t = t + memo.get(j);
									j++;
								}
								t = WithParenthesisProcess(true, t);
								if (t.contains("_")) // only integers allowed to lcm
									t = "1";
								s = SNum.mmc(s, t);
							}

							memo.set(i + 1, s);
							while (!memo.get(i + 2).equals(")" + max.toString()))
								memo.remove(i + 2);

							memo.remove(i - 1);
							i--;
						} else if ((i >= 1) && memo.get(i - 1).equals("binom")) {
							j = i + 1;
							s = "";
							while ((!memo.get(j).equals(",")) && (!memo.get(j).equals(")" + max.toString()))) {
								s = s + memo.get(j);
								j++;
							}
							s = WithParenthesisProcess(true, s);

							if (memo.get(j).equals(",")) {
								j++;
								t = "";
								while ((!memo.get(j).equals(",")) && (!memo.get(j).equals(")" + max.toString()))) {
									t = t + memo.get(j);
									j++;
								}
								s = SNum.binom(s, WithParenthesisProcess(true, t));
							}

							memo.set(i + 1, s);
							while (!memo.get(i + 2).equals(")" + max.toString()))
								memo.remove(i + 2);

							memo.remove(i - 1);
							i--;
						} else if ((i >= 1) && memo.get(i - 1).equals("abs")) {
							j = i + 1;
							s = "";
							while (!memo.get(j).equals(")" + max.toString())) {
								s = s + memo.get(j);
								j++;
							}
							s = WithParenthesisProcess(true, s);
							if (s.equals(SNum.FracValida(s)))
								memo.set(i + 1, SNum.SNumAbs(s));
							else
								memo.set(i + 1, "abs(" + s + ")");

							while (!memo.get(i + 2).equals(")" + max.toString()))
								memo.remove(i + 2);

							memo.remove(i - 1);
							i--;
						} else if ((i >= 1) && memo.get(i - 1).equals("log")) {
							j = i + 1;
							s = "";
							while (!memo.get(j).equals(")" + max.toString())) {
								s = s + memo.get(j);
								j++;
							}
							s = WithParenthesisProcess(true, s);
							if (s.equals(SNum.FracValida(s)))
								memo.set(i + 1, SNum.FracLog("e", "1_100", s));
							else
								memo.set(i + 1, "log(" + s + ")");
							while (!memo.get(i + 2).equals(")" + max.toString()))
								memo.remove(i + 2);

							memo.remove(i - 1);
							i--;
						} else if ((i >= 1) && memo.get(i - 1).equals("floor")) {
							j = i + 1;
							s = "";
							while (!memo.get(j).equals(")" + max.toString())) {
								s = s + memo.get(j);
								j++;
							}
							memo.set(i + 1, SNum.FracFloor(WithParenthesisProcess(true, s)));
							while (!memo.get(i + 2).equals(")" + max.toString()))
								memo.remove(i + 2);

							memo.remove(i - 1);
							i--;
						} else if ((i >= 1) && memo.get(i - 1).equals("gamma")) {
							j = i + 1;
							s = "";
							while (!memo.get(j).equals(")" + max.toString())) {
								s = s + memo.get(j);
								j++;
							}
							memo.set(i + 1, SNum.FracGamma("1_10", WithParenthesisProcess(true, s)));
							while (!memo.get(i + 2).equals(")" + max.toString()))
								memo.remove(i + 2);

							memo.remove(i - 1);
							i--;
						}
						maxfound = true;
						j = i + 1;
						s = "";
						while (!memo.get(j).equals(")" + max.toString())) {
							s = s + memo.get(j);
							j++;
						}
						if ((!s.startsWith("abs")) && (!s.startsWith("log")))
							s = WithParenthesisProcess(true, s);
						if ((i >= 1) && memo.get(i - 1).endsWith("^"))
							if (s.equals(SNum.FracValida(s))) {
								t = memo.get(i - 1);
								if (t.equals("^")) {
									t = memo.get(i - 2);
									if (t.equals(SNum.FracValida(t))) {
										s = SNum.FracPower(t, s);
										memo.remove(i - 2);
										memo.remove(i - 2);
										i -= 2;
									} else
										s = "(" + s + ")";
								} else {
									t = Util.delete(t, t.length(), 1);
									if (t.equals(SNum.FracValida(t))) {
										s = SNum.FracPower(t, s);
										memo.remove(i - 1);
										i--;
									} else
										s = "(" + s + ")";
								}
							} else {
								k = 0;
								if (s.charAt(k) == '-')
									k++;
								while ((!Util.charInSet(s.charAt(k), "+-_^")) && (k < s.length()))
									k++;
								if ((k < s.length()) && Util.charInSet(s.charAt(k), "+-_^")) {
									t = memo.get(i - 1);
									if (t.equals("^")) {
										t = memo.get(i - 2);
										s = WithParenthesisProcess(true, Distribution(t, "^(" + s + ")"));
										memo.remove(i - 2);
										memo.remove(i - 2);
										i -= 2;
									} else {
										k = 0;
										if (s.charAt(k) == '-')
											k++;
										while ((!Util.charInSet(s.charAt(k), "+-_")) && (k < s.length()))
											k++;
										if ((k < s.length()) && (!s.substring(0, k).equals("1_"))) {
											t = Util.delete(t, t.length(), 1);
											s = WithParenthesisProcess(true, Distribution(t, "^(" + s + ")"));
											memo.remove(i - 1);
											i--;
										} else
											s = "(" + s + ")";
									}
								} else {
									k = 0;
									if (s.charAt(k) == '-')
										k++;
									while (Util.charInSet(s.charAt(k), "0123456789_") && (k < s.length()))
										k++;
									t = "^" + s.substring(k, s.length());
									s = s.substring(0, k - 1);
									if (s.equals(""))
										s = "1";
									k = 2;
									if (t.charAt(1) == 'V') {
										while ((k < t.length()) && (t.charAt(k) != 'V'))
											k++;
										if (t.charAt(k) == 'V') {
											t = Util.insert("^", t, k);
											k++;
										}
									} else
										while (k < t.length()) {
											if (Util.charInSet(t.charAt(k), "abcdefghijklmnopqrstuvwxyz")) {
												t = Util.insert("^", t, k);
												k++;
											}
											k++;
										}
									memo.add(j + 1, t);
									t = memo.get(i - 1);
									if (t.equals("^")) {
										t = memo.get(i - 2);
										if (t.equals(SNum.FracValida(t))) {
											s = SNum.FracPower(t, s);
											memo.remove(i - 2);
											memo.remove(i - 2);
											i -= 2;
											j -= 2;
										}
									} else {
										t = Util.delete(t, t.length(), 1);
										if (t.equals(SNum.FracValida(t))) {
											s = SNum.FracPower(t, s);
											memo.remove(i - 1);
											i--;
											j--;
										}
									}
									if (s.contains("_") && (s.indexOf("1_") != 0))
										memo.set(j + 1, Util.insert(memo.get(j + 1), s, s.indexOf("_")));
								}
							}
						else if (i >= 1)
							if (memo.get(i - 1).equals("_")
									&& ((j + 1 >= memo.size()) || (!memo.get(j + 1).startsWith("^"))))
								if (memo.get(i - 2).equals(s)) // x / (x)
								{
									s = "1";
									memo.remove(i - 2);
									memo.remove(i - 2);
									i -= 2;
								} else {
									t = BasisDifference(memo.get(i - 2), s);// x / x^3
									if (!t.equals("")) {
										s = t;
										memo.remove(i - 2);
										memo.remove(i - 2);
										i -= 2;
									} else if (!s.equals(SNum.FracValida(s))) {
										if ((!s.startsWith("abs")) && (!s.startsWith("log")))
											s = "(" + s + ")";
										s = Distribution(memo.get(i - 2), "_" + s);
										memo.remove(i - 2);
										memo.remove(i - 2);
										i -= 2;
									}
								}
							else if (Util.charInSet(memo.get(i - 1).charAt(0), "abcdefghijklmnopqrstuvwxyzV")) {
								if ((i >= 2) && memo.get(i - 2).equals("-")) {
									s = Distribution("-" + memo.get(i - 1), "(" + s + ")");
									memo.remove(i - 2);
									i--;
								} else
									s = Distribution(memo.get(i - 1), "(" + s + ")");

								i--;
							}

						memo.set(i + 1, s);
						while (!memo.get(i + 2).equals(")" + max.toString()))
							memo.remove(i + 2);
						// showmessage(memo.text);
						memo.remove(i + 2);
						memo.remove(i);
						if ((i + 1 < memo.size()) && memo.get(i + 1).startsWith("^") && (!s.equals(SNum.FracValida(s)))
								&& ((s.length() > 1) || s.equals(SNum.FracValida(s))) && (s.startsWith("-")))
							memo.set(i, "(" + s + ")");
						else if ((i >= 1) && memo.get(i - 1).equals("-")) {
							memo.set(i, AlgebricalOpposite(memo.get(i)));
							memo.remove(i - 1);
						} else if ((i + 1 < memo.size()) && memo.get(i + 1).equals("*")
								&& ((i < 1) || (!memo.get(i - 1).endsWith("^")))) {
							j = i + 2;
							s = memo.get(j);
							if (s.startsWith("(")) {
								target = Util.delete(s, 1, 1);
								target = ")" + target;
								s = "(";
								do {
									j++;
									s = s + memo.get(j);
								} while (!memo.get(j).equals(target));
								s = Util.delete(s, s.length() - target.length() + 2, target.length());
							}
							if ((!s.equals("binom")) && (!s.equals("abs")) && (!s.equals("gcd")) && (!s.equals("lcm"))
									&& (!s.equals("floor")) && (!s.equals("log")) && (!s.equals("gamma"))) {
								if ((i >= 1) && memo.get(i - 1).equals("_")) {
									s = Distribution(memo.get(i), "_" + s);
									memo.set(i - 1, "*");
									memo.set(i, AlgebricalInverse(s));
								} else
									memo.set(i, Distribution(memo.get(i), s));
								for (j = j - i;j >= 1;j--)
									memo.remove(i + 1);
							}
						} else if ((i >= 1) && memo.get(i - 1).equals("*")
								&& ((i < 3) || (!memo.get(i - 3).equals("^")))) {
							if ((i >= 3) && memo.get(i - 3).equals("-")) {
								// eee
								s = Distribution("-" + memo.get(i - 2), s);
								if (!s.startsWith("-"))
									;
								s = Util.insert("+", s, 1);
								memo.set(i - 3, s);
								memo.remove(i - 2);
								memo.remove(i - 2);
								memo.remove(i - 2);
							} else if ((i >= 3) && memo.get(i - 3).equals("_")) {
								s = AlgebricalInverse(s);
								s = Distribution(memo.get(i - 2), s);
								if (s.startsWith("-"))
									s = "(" + s + ")";
								memo.set(i - 2, s);
								memo.remove(i - 1);
								memo.remove(i - 1);
							} else {
								memo.set(i - 2, Distribution(memo.get(i - 2), s));
								memo.remove(i - 1);
								memo.remove(i - 1);
							}
						} else if ((i >= 1) && memo.get(i - 1).equals("_")
								&& memo.get(i).equals(SNum.FracValida(memo.get(i))) && memo.get(i).contains("_")) {
							// eee
							memo.set(i - 1, "*");
							s = SNum.FracDiv("1", memo.get(i));
							if (s.startsWith("-"))
								s = "(" + s + ")";
							memo.set(i, s);
						} else if ((i + 1 < memo.size()) && memo.get(i + 1).equals("_")) {
							j = i + 2;
							s = memo.get(j);
							if (s.startsWith("(")) {
								target = Util.delete(s, 1, 1);
								target = ")" + target;
								s = "(";
								do {
									j++;
									s = s + memo.get(j);
								} while (!memo.get(j).equals(target));
								s = Util.delete(s, s.length() - target.length() + 2, target.length());
							}
							if (memo.get(i).equals(s) || s.equals("(" + memo.get(i) + ")")) // x / (x)
								if (i >= 1) {
									s = memo.get(i - 1);
									if (s.endsWith("*")) {
										s = Util.delete(s, s.length(), 1);
										memo.set(i - 1, s);
									}
									memo.remove(i);
									i--;
									j--;
								} else
									memo.set(i, Distribution(memo.get(i), "_" + s));
							else if (s.equals("log") || s.equals("abs") || s.equals("gcd") || s.equals("lcm")
									|| s.equals("floor") || s.equals("binom") || s.equals("gamma"))
								j -= 2;
							else
								memo.set(i, Distribution(memo.get(i), "_" + s));

							for (j = j - i;j >= 1;j--)
								memo.remove(i + 1);
						} else if ((i >= 1) && memo.get(i - 1).startsWith("(")) {
							if ((!memo.get(i + 1).startsWith(")")) && (!memo.get(i + 1).startsWith(","))) {
								s = memo.get(i) + memo.get(i + 1);
								s = s.replace("--", "+");
								s = s.replace("++", "+");
								s = s.replace("+-", "-");
								s = s.replace("-+", "-");
								memo.set(i, s);
								memo.remove(i + 1);
							}
						} else if ((memo.size() > i + 1) && memo.get(i + 1).startsWith(")"))
							if ((!memo.get(i - 1).startsWith("(")) && (!memo.get(i - 1).startsWith(","))) {
								s = memo.get(i - 1) + memo.get(i);
								s = s.replace("--", "+");
								s = s.replace("++", "+");
								s = s.replace("+-", "-");
								s = s.replace("-+", "-");
								memo.set(i - 1, s);
								memo.remove(i);
							}
						i = 0;
					}

					i++;
				}
				if (!maxfound)
					max--;
			} while (max > 0);

		t = Util.toString2(memo);
		if (t.contains("Error"))
			return t;
		do {
			s = NoParenthesisProcess(t);
			if (s.equals(t))
				break;
			t = s;
		} while (true);

		if (s.equals(""))
			return "0";

		return s;
	}

	public static String NoParenthesisProcess(String s) {
		int i, j;
		boolean achou;
		ArrayList<String> memo = new ArrayList<String>();

		s = s.replace("\n", "");
		if (s.equals(SNum.FracValida(s)) || s.contains("("))
			return s;

		while ((s.length() > 0) && (!Util.charInSet(s.charAt(0), "0123456789-abcdefghijklmnopqrstuvwxyzV(")))
			s = Util.delete(s, 1, 1);

		i = 0;
		while (i < s.length())
			if (Util.charInSet(s.charAt(i), "0123456789abcdefghijklmnopqrstuvwxyzV()"))
				i++;
			else if (Util.charInSet(s.charAt(i), "_+-*^") && (i < s.length() - 1))
				if (Util.charInSet(s.charAt(i + 1), "0123456789abcdefghijklmnopqrstuvwxyzV("))
					i++;
				else
					s = Util.delete(s, i + 1, 1);
			else
				s = Util.delete(s, i + 1, 1);

		i = 0;
		if ((s.length() > 0) && (s.charAt(0) == '-'))
			i++;
		while (i < s.length())
			if (s.charAt(i) == 'V') {
				memo.add(s.substring(0, i));
				s = Util.delete(s, 1, i);
				i = 1;
				while ((i < s.length()) && Util.charInSet(s.charAt(i), "0123456789abcdefghijklmnopqrstuvwxyz"))
					i++;
			} else if (Util.charInSet(s.charAt(i), "_+-*^abcdefghijklmnopqrstuvwxyz")) {
				memo.add(s.substring(0, i));
				memo.add(Util.char2String(s.charAt(i)));
				s = Util.delete(s, 1, i + 1);
				i = 0;
			} else
				i++;

		memo.add(s);

		i = 0;
		do {
			if (i == memo.size())
				break;
			if (memo.get(i).equals(""))
				memo.remove(i);
			else
				i++;
		} while (true);

		i = 1;// if priority = 2
		while (i < memo.size()) {
			if (i + 1 < memo.size())
				if (memo.get(i).equals("^"))
					if (memo.get(i - 1).equals(SNum.FracValida(memo.get(i - 1)))
							&& memo.get(i + 1).equals(SNum.FracValida(memo.get(i + 1)))) {
						memo.set(i - 1, SNum.FracPower(memo.get(i - 1), memo.get(i + 1)));
						memo.remove(i);
						memo.remove(i);
						i = 0;
					} else if (memo.get(i - 1).equals("1") || memo.get(i - 1).equals("-1")) {
						memo.remove(i);
						memo.remove(i);
						if ((i < memo.size()) && memo.get(i).equals(SNum.FracValida(memo.get(i))))
							memo.remove(i - 1);
						i = 0;
					}

			i++;
		}

		s = Util.toString2(memo);
		memo.clear();
		i = 0;
		if ((s.length() > 0) && (s.charAt(0) == '-'))
			i++;
		while (i < s.length())
			if (s.charAt(i) == 'V') {
				memo.add(s.substring(0, i));
				s = Util.delete(s, 1, i);
				i = 1;
				while ((i < s.length()) && Util.charInSet(s.charAt(i), "0123456789abcdefghijklmnopqrstuvwxyz"))
					i++;
			} else if (Util.charInSet(s.charAt(i), "_+-*abcdefghijklmnopqrstuvwxyz")) {
				memo.add(s.substring(0, i));
				memo.add(Util.char2String(s.charAt(i)));
				s = Util.delete(s, 1, i + 1);
				i = 0;
			} else
				i++;

		memo.add(s);

		i = 0;
		do {
			if (i == memo.size())
				break;
			if (memo.get(i).equals(""))
				memo.remove(i);
			else
				i++;
		} while (true);

		i = 1;// if priority = 1
		while (i < memo.size()) {
			if (i + 1 < memo.size())
				if (memo.get(i).equals("*")
						&& ((i < 2) || (memo.get(i - 2).charAt(memo.get(i - 2).length() - 1) != '^'))
						&& (memo.get(i + 1).charAt(memo.get(i + 1).length() - 1) != '^'))
					if (!memo.get(i + 1).equals(SNum.FracValida(memo.get(i + 1))))
						if (!memo.get(i - 1).equals(SNum.FracValida(memo.get(i - 1)))) {
							memo.remove(i);
							i = 0;
							do {
								i++;
								if ((i >= 1) && (i < memo.size()) && (memo.get(i - 1).charAt(0) == 'V')) // V7 x = x V7
									if (Util.charInSet(memo.get(i).charAt(0), "abcdefghijklmnopqrstuvwxyz")) {
										if ((i >= 2) && memo.get(i - 2).equals("_")) {
											s = memo.get(i);
											memo.remove(i);
											memo.add(i - 2, s);
											i--;
										} else {
											s = memo.get(i);
											memo.set(i, memo.get(i - 1));
											memo.set(i - 1, s);
										}
										i = 0;
										// showmessage(replace(memo.text, #13#10, ""));
									}
							} while (i < memo.size());
							i = 0;
						} else {
							memo.set(i - 1, memo.get(i - 1) + memo.get(i + 1));
							memo.remove(i);
							memo.remove(i);
							i = 0;
						}
					else if (!memo.get(i - 1).equals(SNum.FracValida(memo.get(i - 1)))) {
						if ((i >= 2) && memo.get(i - 2).equals(SNum.FracValida(memo.get(i - 2)))) {
							memo.set(i - 2, SNum.FracMul(memo.get(i - 2), memo.get(i + 1)));
							memo.remove(i);
							memo.remove(i);
							i = 0;
						} else {
							memo.set(i - 1, memo.get(i + 1) + memo.get(i - 1));
							memo.remove(i);
							memo.remove(i);
							i = 0;
						}
					} else if (((i + 2 >= memo.size()) || (!memo.get(i + 2).equals("_")))
							&& ((i <= 2) || (!memo.get(i - 2).equals("_")))) {
						memo.set(i - 1, SNum.FracMul(memo.get(i - 1), memo.get(i + 1)));
						memo.remove(i);
						memo.remove(i);
						i = 0;
					}

			i++;
		}

		s = Util.toString2(memo);
		memo.clear();
		i = 0;
		if ((s.length() > 0) && (s.charAt(0) == '-'))
			i++;
		while (i < s.length())
			if (s.charAt(i) == 'V') {
				memo.add(s.substring(0, i));
				s = Util.delete(s, 1, i);
				i = 1;
				while ((i < s.length()) && Util.charInSet(s.charAt(i), "0123456789abcdefghijklmnopqrstuvwxyz"))
					i++;
			} else if (Util.charInSet(s.charAt(i), "_+-*^abcdefghijklmnopqrstuvwxyz")) {
				memo.add(s.substring(0, i));
				memo.add(Util.char2String(s.charAt(i)));
				s = Util.delete(s, 1, i + 1);
				i = 0;
			} else
				i++;

		memo.add(s);

		i = 0;
		do {
			if (i == memo.size())
				break;
			if (memo.get(i).equals(""))
				memo.remove(i);
			else
				i++;
		} while (true);

		i = 1;// if priority = 2
		while (i < memo.size()) {
			if (memo.get(i).equals("^")) {
				j = i + 3;
				do {
					if ((j < memo.size()) && memo.get(j - 1).equals("_") && memo.get(i - 1).equals(memo.get(j))
							&& ((j + 1 >= memo.size()) || (!memo.get(j + 1).equals("^")))
							&& (!memo.get(i + 2).equals("+")) && (!memo.get(i + 2).equals("-"))
							&& (memo.get(i + 1).equals(SNum.FracValida(memo.get(i + 1))))) // x^3 / x
					{
						s = SNum.Subtrai(memo.get(i + 1), "1");
						if (s.equals("1")) {
						} else if (s.equals("0"))
							memo.set(i - 1, "1");
						else
							memo.set(i - 1, memo.get(i - 1) + "^" + s);
						memo.remove(j - 1);
						memo.remove(j - 1);
						memo.remove(i);
						memo.remove(i);
						i = 0;
						break;
					}
					j++;
					if (j > memo.size() - 1)
						break;
				} while ((!memo.get(j).equals("+")) && (!memo.get(j).equals("-")));

				j = i - 3;
				do {
					if ((j >= 0) && memo.get(i - 2).equals("_") && memo.get(i - 1).equals(memo.get(j))
							&& (!memo.get(j + 1).equals("^"))
							&& memo.get(i + 1).equals(SNum.FracValida(memo.get(i + 1)))
							&& ((j == 0) || (!memo.get(j - 1).equals("^")))) // x / x^3
					{
						memo.set(j, "1");
						if (memo.get(i + 1).equals("2")) {
							memo.remove(i);
							memo.remove(i);
						} else
							memo.set(i + 1, SNum.Subtrai(memo.get(i + 1), "1"));

						if (j >= 1)
							if (Util.charInSet(memo.get(i - 1).charAt(0), "abcdefghijklmnopqrstuvwxyzV"))
								memo.remove(j);
						i = 0;
						break;
					}
					j--;
					if (j < 0)
						break;
				} while ((!memo.get(j).equals("+")) && (!memo.get(j).equals("-")));

				j = i - 5;
				while ((j >= 0) && (!memo.get(j).equals("+")) && (!memo.get(j).equals("-"))
						&& (!memo.get(i - 4).equals("+")) && (!memo.get(i - 4).equals("-"))
						&& (!memo.get(i - 3).equals("+")) && (!memo.get(i - 3).equals("-"))
						&& memo.get(i + 1).equals(SNum.FracValida(memo.get(i + 1)))) {
					if ((j >= 0) && memo.get(i - 2).equals("_") && memo.get(i - 1).equals(memo.get(j))
							&& memo.get(j + 1).equals("^") && memo.get(j + 2).equals(SNum.FracValida(memo.get(j + 2)))) // x^2
																														// /
																														// x^3
					{
						s = SNum.Subtrai(memo.get(i + 1), memo.get(j + 2));
						if (s.equals("1"))
							memo.set(i - 1, "1_" + memo.get(j));
						else if (s.equals("-1"))
							memo.set(i - 1, memo.get(j));
						else if (s.equals("0"))
							memo.set(i - 1, "1");
						else if (SNum.SNumCompare(s, "1") > 0)
							memo.set(i - 1, "1_" + memo.get(j) + "^" + s);
						else
							memo.set(i - 1, memo.get(j) + "^" + SNum.SNumOposto(s));
						memo.remove(i);
						memo.remove(i);
						memo.remove(i - 2);
						memo.remove(j);
						memo.remove(j);
						memo.remove(j);
						i = 0;
						break;
					}
					j--;
				}
			}
			i++;
		}

		i = 1;// after '_'
		while (i < memo.size()) {
			if (memo.get(i).equals("_"))
				if (i + 1 < memo.size()) {
					j = i - 1;
					do {
						if ((!memo.get(j).equals(SNum.FracValida(memo.get(j)))) && memo.get(j).equals(memo.get(i + 1))
								&& ((i < 2) || (!memo.get(i - 2).equals("^")))) // x / x
						{
							memo.set(j, "1");
							memo.remove(i);
							memo.remove(i);
							if ((j >= 1) && memo.get(j - 1).equals(SNum.FracValida(memo.get(j - 1))))
								memo.remove(j);
							else if ((j + 1 < memo.size()) && (!memo.get(j + 1).equals("+"))
									&& (!memo.get(j + 1).equals("-")) && (!memo.get(j + 1).equals("^"))
									&& (!memo.get(j + 1).equals("*")) && (!memo.get(j + 1).equals("_")))
								memo.remove(j);
							else if ((j == 1) && memo.get(0).equals("-")) {
								memo.remove(1);
								if (memo.get(0).equals("-")
										|| (memo.size() > 1) && (memo.get(1).equals("+") || memo.get(1).equals("-")
												|| memo.get(1).equals("^") || memo.get(1).equals("*")))
									memo.set(0, "-1");
							}

							i = 0;
							// showmessage(replace(memo.text, #13#10, ""));
							break;
						}

						j--;
						if (j < 0)
							break;
					} while ((!memo.get(j).equals("+")) && (!memo.get(j).equals("-")) && (!memo.get(j).equals("*")));
				}
			i++;
		}

		i = 1;// after '_'
		while (i < memo.size()) {
			if (memo.get(i).equals("^")) {
				j = i + 2;
				while ((j < memo.size()) && (!memo.get(j).equals("+")) && (!memo.get(j).equals("-"))) {
					if ((i >= 1) && (j < memo.size()) && memo.get(i - 1).equals(memo.get(j))
							&& ((j + 1 >= memo.size()) || (!memo.get(j + 1).equals("^")))
							&& memo.get(i + 1).equals(SNum.FracValida(memo.get(i + 1)))) // x^3 x
					{
						s = SNum.Soma(memo.get(i + 1), "1");
						if (!s.equals("1"))
							memo.set(i - 1, memo.get(i - 1) + "^" + s);
						memo.remove(j);
						memo.remove(i);
						memo.remove(i);
						i = 0;
						break;
					}
					j++;
					if (j > memo.size() - 1)
						break;
				}

				j = i - 2;
				while ((j >= 0) && (!memo.get(j).equals("+")) && (!memo.get(j).equals("-"))
						&& (!memo.get(j).equals("("))) {
					if ((i >= 1) && (j >= 0) && memo.get(i - 1).equals(memo.get(j)) && (!memo.get(j + 1).equals("^"))
							&& memo.get(i + 1).equals(SNum.FracValida(memo.get(i + 1)))
							&& ((i < 2) || (!memo.get(i - 2).equals("_")))
							&& ((j < 1) || (!memo.get(j - 1).equals("^")))) // x x^3
					{
						s = SNum.Soma(memo.get(i + 1), "1");
						if (!s.equals("1"))
							memo.set(j, memo.get(j) + "^" + s);
						memo.remove(i - 1);
						memo.remove(i - 1);
						memo.remove(i - 1);
						i = 0;
						break;
					}
					j--;
				}

				j = i + 2;
				while ((j < memo.size()) && (!memo.get(j).equals("+")) && (!memo.get(j).equals("-"))) {
					if ((i >= 1) && (j + 1 < memo.size()) && memo.get(i - 1).equals(memo.get(j))
							&& memo.get(j + 1).equals("^") && memo.get(i + 1).equals(SNum.FracValida(memo.get(i + 1)))
							&& memo.get(j + 2).equals(SNum.FracValida(memo.get(j + 2)))) // x^3 x^2
					{
						s = SNum.Soma(memo.get(i + 1), memo.get(j + 2));
						if (!s.equals("1"))
							memo.set(i - 1, memo.get(i - 1) + "^" + s);
						memo.remove(j);
						memo.remove(j);
						memo.remove(j);
						memo.remove(i);
						memo.remove(i);
						i = 0;
						break;
					}
					j++;
					if (j > memo.size() - 1)
						break;
				}
			}

			i++;
		}

		i = 1;// if priority = 1
		while (i < memo.size()) {
			if ((i >= 1) && memo.get(i).equals("1"))
				if (Util.charInSet(memo.get(i - 1).charAt(0), "abcdefghijklmnopqrstuvwxyzV")) {
					memo.remove(i);
					i = 0;
				}

			if ((i >= 1) && memo.get(i).equals(SNum.FracValida(memo.get(i))) && (!memo.get(i - 1).equals("^"))
					&& (((i < 2) || (!memo.get(i - 2).equals("^"))) || memo.get(i - 1).equals("_"))) { // x7 = 7x

				if (Util.charInSet(memo.get(i - 1).charAt(0), "abcdefghijklmnopqrstuvwxyzV") && (i >= 2)
						&& memo.get(i - 2).equals("_")) {
					s = memo.get(i);
					memo.remove(i);
					memo.add(i - 2, s);
					i--;
					if ((i >= 4) && memo.get(i - 3).equals("_")
							&& memo.get(i - 4).equals(SNum.FracValida(memo.get(i - 4)))) {
						memo.set(i - 4, SNum.FracMul(memo.get(i - 4), s));
						memo.remove(i - 1);
					} else if ((i >= 2) && memo.get(i - 2).equals(SNum.FracValida(memo.get(i - 2)))) {
						memo.set(i - 2, SNum.FracMul(memo.get(i - 2), s));
						memo.remove(i - 1);
					}
					i = 0;
				} else if ((!memo.get(i - 1).equals("+")) && (!memo.get(i - 1).equals("-"))
						&& ((i < 2) || (!memo.get(i - 2).equals(SNum.FracValida(memo.get(i - 2)))))) { // -b^2x7 =
																										// -7b^2x
					achou = false;
					j = i - 2;
					while (j >= 0) {
						if (memo.get(j).equals("+") || memo.get(j).equals("-")) {
							j++;
							break;
						} else if (memo.get(j).equals("^")) {
							achou = true;
							break;
						}
						j--;
					}

					if (achou)
						j--;
					else if (j < 0)
						j = 0;

					if (memo.get(i).equals("_")) {
						memo.add(j, "1_" + memo.get(i + 1));
						memo.remove(i + 2);
						memo.remove(i + 1);
					} else if ((i >= 1) && memo.get(i - 1).equals("_")) {
						memo.add(j, "1_" + memo.get(i));
						memo.remove(i + 1);
						memo.remove(i);
					} else {
						memo.add(j, memo.get(i));
						memo.remove(i + 1);
					}

					if ((j + 1 < memo.size()) && memo.get(j + 1).equals(SNum.FracValida(memo.get(j + 1)))) {
						memo.set(j, SNum.FracMul(memo.get(j), memo.get(j + 1)));
						memo.remove(j + 1);
					}
					i = 0;
				}
			}

			if ((i >= 1) && memo.get(i).equals(SNum.FracValida(memo.get(i)))
					&& ((i < 3) || (!memo.get(i - 3).equals("^")))) // /x/7 = /7/x
				if ((i >= 1) && memo.get(i - 1).equals("_"))
					if (Util.charInSet(memo.get(i - 2).charAt(0), "abcdefghijklmnopqrstuvwxyzV")) {
						if ((i >= 3) && memo.get(i - 3).equals("_")) {
							s = memo.get(i);
							memo.add(i - 3, "_" + s);
							memo.remove(i + 1);
							memo.remove(i);
							/*
							 * i--;if ((i >= 4) && memo.get(i - 3).equals("_") && memo.get(i -
							 * 4).equals(SNum.FracValida(memo.get(i - 4)))) { memo.set(i - 4,
							 * SNum.FracMul(memo.get(i - 4), s));memo.remove(i - 1);} else if ((i >= 2) &&
							 * memo.get(i - 2).equals(SNum.FracValida(memo.get(i - 2)))) { memo.set(i - 2,
							 * SNum.FracMul(memo.get(i - 2), s));memo.remove(i - 1);}
							 */

						}
						i = 0;
						// showmessage(replace(memo.text, #13#10, ""));
					}

			if ((i >= 3) && memo.get(i).equals(SNum.FracValida(memo.get(i))) && memo.get(i - 1).equals("^")
					&& memo.get(i - 3).equals("^")) // ^x^7 = ^7^x
				if (Util.charInSet(memo.get(i - 2).charAt(0), "abcdefghijklmnopqrstuvwxyzV")) {
					s = memo.get(i);
					memo.set(i, memo.get(i - 2));
					memo.set(i - 2, s);

					if ((i >= 4) && memo.get(i - 4).equals(SNum.FracValida(memo.get(i - 4)))) {
						memo.set(i - 4, SNum.FracPower(memo.get(i - 4), s));
						memo.remove(i - 3);
						memo.remove(i - 3);
					}
					i = 0;
					// showmessage(replace(memo.text, #13#10, ""));
				}

			if ((i >= 1) && (memo.get(i).length() > 2) && memo.get(i).substring(0, 1).equals("1_"))
				if (Util.charInSet(memo.get(i - 1).charAt(0), "abcdefghijklmnopqrstuvwxyzV")) {
					s = memo.get(i);
					s = Util.delete(s, 1, 1);
					memo.set(i, s);
					i = 0;
				}

			j = i;
			if ((i >= 1) && Util.charInSet(memo.get(i - 1).charAt(0), "abcdefghijklmnopqrstuvwxyzV"))
				while ((!memo.get(j).equals("+")) && (!memo.get(j).equals("-")) && (!memo.get(j).equals("^"))
						&& (!memo.get(j).equals("("))) {
					if ((j < memo.size()) && Util.charInSet(memo.get(j).charAt(0), "abcdefghijklmnopqrstuvwxyzV")
							&& (!memo.get(j - 1).equals("_")) && ((i < 2) || (!memo.get(i - 2).equals("^")))) // x x
						if (memo.get(i - 1).equals(memo.get(j)))
							if ((i < 2) || (!memo.get(i - 2).equals("_"))) {
								memo.set(i - 1, memo.get(i - 1) + "^2");
								memo.remove(j);
								i = 0;
								break;
							} else {
								memo.remove(j);
								memo.remove(i - 1);
								memo.remove(i - 2);
								i = 0;
								break;
							}
					j++;
					if (j > memo.size() - 1)
						break;
				}

			i++;
		}

		if ((memo.size() > 1) && memo.get(0).equals("1")
				&& Util.charInSet(memo.get(1).charAt(0), "abcdefghijklmnopqrstuvwxyzV"))
			memo.remove(0);

		i = 1;// if priority = 1
		while (i < memo.size())

		{
			if (i + 1 < memo.size())
				if (memo.get(i).equals("*"))
					if (memo.get(i - 1).equals(SNum.FracValida(memo.get(i - 1)))
							&& memo.get(i + 1).equals(SNum.FracValida(memo.get(i + 1)))
							&& ((i + 2 >= memo.size()) || (!memo.get(i + 2).equals("^")))) {
						memo.set(i - 1, SNum.FracMul(memo.get(i - 1), memo.get(i + 1)));
						memo.remove(i);
						memo.remove(i);
						i = 0;
					}

			if ((i >= 1) && (i + 1 < memo.size()))
				if (memo.get(i).equals("_"))
					if (memo.get(i - 1).equals(SNum.FracValida(memo.get(i - 1)))
							&& memo.get(i + 1).equals(SNum.FracValida(memo.get(i + 1))))
						if ((i < 2) || (!memo.get(i - 2).equals("^"))) {
							memo.set(i - 1, SNum.FracDiv(memo.get(i - 1), memo.get(i + 1)));
							memo.remove(i);
							memo.remove(i);
							i = 0;
						}

			i++;
		}

		s = Util.toString2(memo);
		memo.clear();
		i = 0;
		if ((s.length() > 0) && (s.charAt(0) == '-'))
			i++;
		while (i < s.length())
			if (Util.charInSet(s.charAt(i), "+-")) {
				memo.add(s.substring(0, i));
				memo.add(Util.char2String(s.charAt(i)));
				s = Util.delete(s, 1, i + 1);
				i = 0;
			} else
				i++;

		memo.add(s);

		i = 0;
		do {
			if (i == memo.size())
				break;
			if (memo.get(i).equals(""))
				memo.remove(i);
			else
				i++;
		} while (true);

		i = 1;// priority = 0
		while (i < memo.size()) {
			if (i + 1 < memo.size())
				if (memo.get(i).equals("+"))
					if (memo.get(i - 1).equals(SNum.FracValida(memo.get(i - 1)))
							&& memo.get(i + 1).equals(SNum.FracValida(memo.get(i + 1)))) {
						memo.set(i - 1, SNum.FracAdd(memo.get(i - 1), memo.get(i + 1)));
						memo.remove(i);
						memo.remove(i);
						i = 0;
					}

			if ((i >= 1) && (i + 1 < memo.size()))
				if (memo.get(i).equals("-"))
					if (memo.get(i - 1).equals(SNum.FracValida(memo.get(i - 1)))
							&& memo.get(i + 1).equals(SNum.FracValida(memo.get(i + 1)))) {
						memo.set(i - 1, SNum.FracSub(memo.get(i - 1), memo.get(i + 1)));
						memo.remove(i);
						memo.remove(i);
						i = 0;
					}

			i++;
		}

		if (memo.size() > 1)
			while (memo.get(0).equals("-") && memo.get(1).equals(SNum.FracValida(memo.get(1)))) {
				memo.set(0, SNum.SNumOposto(memo.get(1)));
				memo.remove(1);
			}

		if (memo.size() == 0)
			s = "0";
		else
			s = Util.toString2(memo);

		return s.replace("+-", "-");
	}

	public static String Denominator(String s) {
		int i, j;
		boolean expoente;
		i = s.indexOf("=");
		if (i < 0)
			return "";
		i = 0;
		expoente = false;
		while (i < s.length() - 1) {
			if (s.charAt(i) == '(') {
				j = 1;
				while ((i < s.length()) && (j > 0)) {
					if (s.charAt(i) == '(')
						j++;
					else if (s.charAt(i) == ')')
						j--;

					i++;
				}
			} else if (s.charAt(i) == '^')
				expoente = true;
			else if (Util.charInSet(s.charAt(i), "+-") && expoente)
				expoente = false;
			else if ((s.charAt(i) == '_') && (!expoente))
				break;

			i++;
		}

		if (expoente || (i >= s.length()) || (s.charAt(i) != '_'))
			return "";

		s = Util.delete(s, 1, i);
		i = 1;
		if (s.charAt(0) == '(') {
			j = 0;
			while ((i < s.length()) && (j > 0)) {
				if (s.charAt(i) == '(')
					j++;
				else if (s.charAt(i) == ')')
					j--;

				i++;
			}
		} else if (s.charAt(i) == 'V')
			while (i < s.length())
				if (Util.charInSet(s.charAt(i), "0123456789^abcdefghijklmnopqrstuvwxyz"))
					i++;
				else
					break;
		else if (Util.charInSet(s.charAt(0), "0123456789abcdefghijklmnopqrstuvwxyz"))
			while (i < s.length())
				if (Util.charInSet(s.charAt(i), "0123456789^"))
					i++;
				else
					break;

		return s.substring(0, i);
	}

	public static String Distribution(String x, String y) {
		int i, j, k;
		boolean flag;
		String s, Result;

		if ((y.length() > 2) && y.substring(0, 2).equals("_(") && y.endsWith(")")) {
			Result = y;
			Result = Util.delete(Result, 1, 2);
			Result = Util.delete(Result, Result.length(), 1);
			if (Result.equals(SNum.FracValida(Result)))
				y = SNum.FracDiv("1", Result);
			else if (Result.contains("_")) {
				s = Result;
				flag = (s.charAt(0) == '-');
				if (flag)
					s = Util.delete(s, 1, 1);
				if ((!s.contains("+")) && (!s.contains("-")))
					y = AlgebricalInverse(s);
				if (flag)
					y = "-" + y;
			}
		} else if ((y.length() > 0) && (y.charAt(0) == '_')) {
			Result = y;
			Result = Util.delete(Result, 1, 1);
			// Result = Util.delete(Result, Result.length(), 1);
			if (Result.equals(SNum.FracValida(Result)))
				y = SNum.FracDiv("1", Result);
		} else if (y.startsWith("(") && y.endsWith(")")) {
			y = Util.delete(y, 1, 1);
			y = Util.delete(y, y.length(), 1);
		}

		if (y.equals("0"))
			return "0";

		if (x.equals(SNum.FracValida(x)) && y.equals(SNum.FracValida(y)))
			return SNum.FracMul(x, y);

		if (y.startsWith("-")) {
			x = AlgebricalOpposite(x);
			y = Util.delete(y, 1, 1);
		}

		if (y.startsWith("1_"))
			y = Util.delete(y, 1, 1);

		if (y.startsWith("_"))
			if ((y.length() > 1) && (y.charAt(1) == '(')) {
				flag = true;
				i = 2;
				while (i < y.length()) {
					if (Util.charInSet(y.charAt(i), "+-*_")) {
						flag = false;
						break;
					}
					i++;
				}

				if (flag) {
					y = Util.delete(y, 2, 1);
					y = Util.delete(y, y.length(), 1);
					i = 2;
					if ((y.length() > 1) && (y.charAt(1) == 'V')) {
						while ((i < y.length()) && (y.charAt(i) != 'V'))
							i++;
						if ((i < y.length()) && (y.charAt(i) != 'V')) {
							y = Util.insert("_", y, i);
							i++;
						}
					} else
						while (i < y.length()) {
							if (Util.charInSet(y.charAt(i), "abcdefghijklmnopqrstuvwxyz")) {
								y = Util.insert("_", y, i);
								i++;
							}
							i++;
						}
				}
			}

		if (y.startsWith("^")) {
			if (x.startsWith("(")) {
				i = 0;
				if (x.startsWith("-"))
					i++;
				while ((i < x.length()) && (!Util.charInSet(x.charAt(i), "+-")))
					i++;
				if ((i < x.length()) && Util.charInSet(x.charAt(i), "+-"))
					x = "(" + x + ")";
			}

			y = Util.delete(y, 1, 2);
			y = Util.delete(y, y.length(), 1);
			i = 0;
			if (y.startsWith("-")) {
				Result = "1_";
				y = Util.delete(y, 1, 1);
			} else
				Result = "";
			while (i < y.length()) {
				if (Util.charInSet(y.charAt(i), "+-")) {
					s = y.substring(0, i);

					j = s.indexOf("_");
					if (j >= 0) {
						s = Util.insert("^(1", s, j);
						s = s + ')';
						if (j > 1) {
							s = Util.insert(")", s, j);
							s = "(" + s;
						}
					} else if (s.length() > 1)
						s = "(" + s + ")";
					Result = Result + x + "^" + s;
					if (y.charAt(i) == '-')
						Result = Result + "_";
					y = Util.delete(y, 1, i + 1);
					i = 0;
				}
				i++;
			}
			j = y.indexOf("_");
			if (j >= 0) {
				y = Util.insert("^(1", y, j);
				y = y + ")";
				if (j > 1) {
					y = Util.insert(")", y, j);
					y = "(" + y;
				}
			} else if (y.length() > 1)
				y = "(" + y + ")";
			Result = Result + x + "^" + y;
			if (Result.startsWith("^"))
				Result = "1" + Result;
		} else if (y.startsWith("_") || (!y.contains("+")) && (!y.contains("-"))) {
			flag = false;
			Result = "";
			i = 0;
			j = 0;
			while (i < x.length()) {
				if ((i + 3 < x.length())
						&& (x.substring(i, i + 3).equals("abs") || x.substring(i, i + 3).equals("log"))) {
					k = i + 3;
					do {
						if (x.charAt(k) == '(')
							j++;
						else if (x.charAt(k) == ')')
							j--;

						k++;
					} while (j != 0);

					Result = Result + x.substring(i, k - 1);
					i = k - 1;
				} else if ((x.charAt(i) == '(') && flag)
					j++;
				else if ((x.charAt(i) == ')') && flag)
					j--;
				else if (Util.charInSet(x.charAt(i), "+-"))
					if (!flag)
						Result = AppendLeftV(Result, y);
					else if (j == 0)
						flag = false;

				if (x.charAt(i) == '_') {
					Result = AppendLeftV(Result, y);
					flag = true;
					j = 0;
				}
				Result = Result + x.charAt(i);
				i++;
			}
			if (!flag)
				Result = AppendLeftV(Result, y);
		} else {
			Result = "";
			i = 0;
			while (i < y.length()) {
				if (Util.charInSet(y.charAt(i), "+-")) {
					Result = Result + Distribution(x, y.substring(0, i)) + y.charAt(i);
					y = Util.delete(y, 1, i + 1);
					i = 0;
				}
				i++;
			}
			Result = Result + Distribution(x, y);
			Result = Result.replace("--", "+");
		}
		return Result;
	}

	public static int AbsolutePosition(String variable, String s) {
		int i;
		if (variable.startsWith("V"))
			return s.indexOf(variable);

		i = 0;
		while (i < s.length()) {
			if (s.charAt(i) == 'V')
				while (Util.charInSet(s.charAt(i + 1), "abcdefghijklmnopqrstuvwxyz0123456789"))
					i++;
			else if (variable.equals(Util.char2String(s.charAt(i))))
				return i;

			i++;
		}
		return -1;
	}

	public static String OppositeSign(String s) {
		if (s.equals("-"))
			return "+";

		return "-";
	}

	public static String SolveFor(String variable, String s) {
		int i, j, k;
		ArrayList<String> memo = new ArrayList<String>();
		boolean equals = false;
		String t, Result = s;
		j = 0;

		if (AbsolutePosition(variable, s) < 0)
			return Result + "\n\nERROR: Variable " + variable + " does not occur in entry.";

		if (s.contains(variable + "^") || s.contains("^" + variable))
			return Result + "\n\nERROR: Variable " + variable + " is not linear in entry.";

		while ((s.length() > 0) && (!Util.charInSet(s.charAt(0), "0123456789-abcdefghijklmnopqrstuvwxyzV(")))
			s = Util.delete(s, 1, 1);

		i = 0;
		while (i < s.length())
			if (Util.charInSet(s.charAt(i), "0123456789=abcdefghijklmnopqrstuvwxyzV()"))
				i++;
			else if (Util.charInSet(s.charAt(i), "+-*_^") && (i < s.length() - 1))
				if (Util.charInSet(s.charAt(i + 1), "0123456789abcdefghijklmnopqrstuvwxyzV("))
					i++;
				else
					s = Util.delete(s, i + 1, 1);
			else
				s = Util.delete(s, i, 1);

		i = 0;
		if (s.startsWith("-"))
			i++;
		while (i < s.length())
			if (Util.charInSet(s.charAt(i), "+-=")) {
				memo.add(s.substring(0, i));
				t = memo.get(memo.size() - 1);
				k = t.indexOf(variable);
				if ((k >= 0) && variable.startsWith("V")) {
					k += variable.length();
					if ((k < t.length()) && Util.charInSet(t.charAt(k), "0123456789abcdefghijklmnopqrstuvwxyz"))
						k = 0;
				}
				if (k > 0) {
					if (equals) {
						memo.add(j, OppositeSign(memo.get(memo.size() - 2)) + memo.get(memo.size() - 1));
						memo.remove(memo.size() - 1);
						if (!memo.get(memo.size() - 1).equals("="))
							memo.remove(memo.size() - 1);
					} else if (memo.size() > 1) {
						memo.add(j, memo.get(memo.size() - 2) + memo.get(memo.size() - 1));
						memo.remove(memo.size() - 1);
						memo.remove(memo.size() - 1);
					}
					j++;
				}

				memo.add(Util.char2String(s.charAt(i)));
				if (s.charAt(i) == '=')
					equals = true;
				s = Util.delete(s, 1, i + 1);
				i = 0;
			} else
				i++;

		memo.add(s);
		t = memo.get(memo.size() - 1);
		k = t.indexOf(variable);
		if ((k >= 0) && variable.startsWith("V")) {
			k += variable.length();
			if ((k < t.length()) && Util.charInSet(t.charAt(k), "0123456789abcdefghijklmnopqrstuvwxyz"))
				k = 0;
		}
		if (k > 0) {
			memo.add(j, OppositeSign(memo.get(memo.size() - 2)) + memo.get(memo.size() - 1));
			memo.remove(memo.size() - 1);
			if (!memo.get(memo.size() - 1).equals("="))
				memo.remove(memo.size() - 1);
		}

		equals = false;
		i = 0;
		while (i < memo.size()) {
			if (memo.get(i).equals("="))
				equals = true;
			else if ((!equals) && (!memo.get(i).equals("+")) && (!memo.get(i).equals("-"))) {
				t = memo.get(i);
				k = t.indexOf(variable);
				if ((k >= 0) && variable.startsWith("V")) {
					k += variable.length();
					if ((k < t.length()) && Util.charInSet(t.charAt(k), "0123456789abcdefghijklmnopqrstuvwxyz"))
						k = 0;
				}
				if (k < 0) {
					if (i == 0)
						memo.add(OppositeSign(memo.get(i)));
					else
						memo.add(OppositeSign(memo.get(i - 1)) + memo.get(i));
					memo.remove(i);
					i--;
					if (memo.get(i).equals("+") || memo.get(i).equals("-")) {
						memo.remove(i);
						i--;
					}
				}
			}

			i++;
		}

		if (memo.get(memo.size() - 1).equals(""))
			memo.remove(memo.size() - 1);

		s = "";
		do {
			if (memo.get(0).equals("=")) {
				memo.set(0, variable + "=");
				if (memo.size() == 1)
					memo.add(1, "(0");
				else
					memo.add(1, "(");
				s = NoParenthesisProcess(Distribution(s, "_" + variable));
				// showmessage(s);
				if (s.equals("-1")) {
					memo.set(1, "-" + memo.get(1));
					memo.add(")");
				} else if (s.equals("1"))
					memo.add(")");
				else
					memo.add(")_(" + s + ")");
				break;
			} else {
				s = s + memo.get(0);
				memo.remove(0);
			}
		} while (true);

		return Util.toString2(memo);
	}

	public static String AlgebricalInverse(String s) {
		if (s.equals(SNum.FracValida(s)))
			return SNum.FracDiv("1", s);

		String Result;
		int i = s.indexOf('_');
		if (i < 0)
			if (s.startsWith("-"))
				Result = "-1_(" + AlgebricalOpposite(s) + ")";
			else
				Result = "1_(" + s + ")";
		else // x^2 y / a^3 b => 1/x^2 /y a^3 /b
		{
			i = 0;
			while (i < s.length()) {
				if (Util.charInSet(s.charAt(i), "abcdefghijklmnopqrstuvwxyz")) {
					s = Util.insert("_", s, i);
					i++;
				} else if (Util.charInSet(s.charAt(i), "0123456789")) {
					s = Util.insert("_", s, i);
					while (Util.charInSet(s.charAt(i + 1), "0123456789"))
						i++;
				}
				i++;
			}
			if (s.startsWith("_"))
				s = "1" + s;
			else if (s.startsWith("-_"))
				s = Util.insert("1", s, 2);
			Result = s.replace("__", "");
		}
		return Result;
	}

	public static String AlgebricalOpposite(String s) {
		int i, j;

		if (s.equals(""))
			return "";

		if (s.startsWith("-")) {
			s = Util.delete(s, 1, 1);
			i = 0;
		} else {
			s = "-" + s;
			i = 1;
		}

		while (i < s.length()) {
			if (s.charAt(i) == '(') {
				j = 1;
				do {
					i++;
					if (s.charAt(i) == '(')
						j++;
					else if (s.charAt(i) == ')')
						j--;
				} while (j != 0);
			}

			if (s.charAt(i) == '+') {
				s = Util.delete(s, i + 1, 1);
				s = Util.insert("-", s, i);
			} else if (s.charAt(i) == '-') {
				s = Util.delete(s, i + 1, 1);
				s = Util.insert("+", s, i);
			}

			i++;
		}

		return s;
	}

	public static String AppendLeftV(String x, String y) {
		int i = x.length();
		if (!y.startsWith("_")) {
			i--;
			while (i >= 0) {
				if (Util.charInSet(x.charAt(i), "0123456789abcdefghijklmnopqrstuvwxyzV"))
					i--;
				else
					break;
			}

			if (i < 0)
				i = 0;
			while ((i < x.length()) && (x.charAt(i) != 'V'))
				i++;
		}

		if ((i >= 1) && (i - 1 < x.length()) && Util.charInSet(x.charAt(i - 1), "0123456789")
				&& Util.charInSet(y.charAt(0), "0123456789"))
			x = Util.insert("*" + y, x, i + 1);
		else
			x = Util.insert(y, x, i + 1);

		return x;
	}

	public static String BasisDifference(String x, String x3) {
		int i, i3;
		String p, p3;

		i3 = x3.indexOf("^");
		if (i3 >= 0) {
			p3 = "1";
			i3 = x3.length();
		} else
			p3 = x3.substring(i3 + 1, x3.length());

		String Result = "";
		i = x.indexOf("^");
		if (i >= 0) {
			p = "1";
			i = x.length();
			Result = x.substring(0, i - 1);
		} else
			p = x.substring(i + 1, x.length());

		if (!Result.equals(""))
			if (Result.equals(x3.substring(0, i3 - 1)) && (!Util.charInSet(Result.charAt(0), "0123456789")))
				if (SNum.Subtrai(p3, p).equals("1"))
					Result = "1_" + Result;
				else if (SNum.Subtrai(p3, p).equals("-1")) {
				} else if (SNum.SNumCompare(p3, p) > 0)
					Result = "1_" + Result + "^" + SNum.Subtrai(p3, p);
				else
					Result = Result + "^" + SNum.Subtrai(p, p3);
			else
				Result = "";

		return Result;
	}

}
