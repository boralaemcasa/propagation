package br.com.calcula.wiki.entidades;

public class SaidaDouble {
	public Double [] ys;
	public Double [] omega;
	public Double [] z;
	public Double denom;
}
