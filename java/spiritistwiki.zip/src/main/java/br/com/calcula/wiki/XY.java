package br.com.calcula.wiki;

public class XY {
	public Double x;
	public Double y;

	public XY() {
		this.x = null;
		this.y = null;
	}

	public XY(Double x, Double y) {
		this.x = x;
		this.y = y;
	}

	public XY(Double x) {
		this.x = x;
		this.y = null;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		XY other = (XY) obj;
		if (y == null) {
			if (other.y != null)
				return false;
		} else if (!y.equals(other.y))
			return false;
		if (x == null) {
			if (other.x != null)
				return false;
		} else if (!x.equals(other.x))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "XY [x=" + x + ", y=" + y + "]";
	}

}
