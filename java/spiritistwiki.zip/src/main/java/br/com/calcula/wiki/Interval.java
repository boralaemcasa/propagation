package br.com.calcula.wiki;

public class Interval { // Intervalo do livro
	public Double min;
	public Double max;

	public Boolean invalido() {
		if (this.max.equals(Util._infty))
			return true;
		if (this.min.equals(Util.infty))
			return true;
		if (this.min > this.max)
			return true;
		if (this.min < Util._infty)
			return true;
		if (this.max > Util.infty)
			return true;
		return false;
	}

	public Interval() {
		this.min = null;
		this.max = null;
	}

	public Interval(Double min, Double max) {
		this.min = min;
		this.max = max;
	}

	public Interval(Double min) {
		this.min = min;
		this.max = null;
	}

	public Interval(Interval z) {
		this.min = z.min;
		this.max = z.max;
	}

	public void set(Double min, Double max) {
		this.min = min;
		this.max = max;
	}

	public void set(Interval y) {
		this.min = y.min;
		this.max = y.max;
	}

	public void xchg() {
		Double x = this.min;
		this.min = this.max;
		this.max = x;
	}

	public Interval plus(Interval y) {
		Interval z = new Interval(0.0, 0.0);
		if (this.invalido() || y.invalido())
			return z;
		if (this.min.equals(Util._infty) && y.min.equals(Util.infty))
			return z;
		if (this.min.equals(Util.infty) && y.min.equals(Util._infty))
			return z;
		if (this.max.equals(Util._infty) && y.max.equals(Util.infty))
			return z;
		if (this.max.equals(Util.infty) && y.max.equals(Util._infty))
			return z;
		if (this.min.equals(Util._infty) || y.min.equals(Util._infty))
			z.min = Util._infty;
		else
			z.min = this.min + y.min;
		if (this.max.equals(Util.infty) || y.max.equals(Util.infty))
			z.max = Util.infty;
		else
			z.max = this.max + y.max;
		return z;
	}

	public Interval oposto() {
		return new Interval(-this.max, -this.min);
	}

	public Interval minus(Interval y) {
		return this.plus(y.oposto());
	}

	public Interval timesConstant(Double y) {
		if (this.invalido())
			return new Interval(0.0, 0.0);
		Interval z;
		if (y < 0) {
			z = this.oposto();
			y = -y;
		} else
			z = new Interval(this);

		if (!z.min.equals(Util._infty))
			z.min = y * z.min;
		if (!z.max.equals(Util.infty))
			z.max = y * z.max;
		return z;
	}

	public Interval plusConstant(Double y) {
		Interval z = new Interval(y, y);
		return this.plus(z);
	}

	public Interval square() {
		if (this.invalido())
			return new Interval(0.0, 0.0);
		Double a2;
		if (this.min.equals(Util._infty))
			a2 = Util.infty;
		else
			a2 = this.min * this.min;
		Double b2;
		if (this.max.equals(Util.infty))
			b2 = Util.infty;
		else
			b2 = this.max * this.max;
		if (this.min >= 0)
			return new Interval(a2, b2);

		if (this.max <= 0)
			return new Interval(b2, a2);

		if (b2 >= a2)
			return new Interval(0.0, b2);

		return new Interval(0.0, a2);
	}

	public Interval exponential() {
		if (this.invalido())
			return new Interval(0.0, 0.0);
		Interval z = new Interval(0.0, Util.infty);
		if (!this.min.equals(Util._infty))
			z.min = Math.exp(this.min);
		if (!this.max.equals(Util.infty))
			z.max = Math.exp(this.max);
		return z;
	}

	public Interval cube() {
		if (this.invalido())
			return new Interval(0.0, 0.0);
		Double a2;
		if (this.min.equals(Util._infty))
			a2 = Util._infty;
		else
			a2 = this.min * this.min * this.min;
		Double b2;
		if (this.max.equals(Util.infty))
			b2 = Util.infty;
		else
			b2 = this.max * this.max * this.max;

		return new Interval(a2, b2);
	}

	public Interval sin() {
		if (this.invalido())
			return new Interval(0.0, 0.0);
		Interval z = new Interval(Math.sin(this.min), Math.sin(this.max));
		if (z.invalido()) {
			Double x = z.min;
			z.min = z.max;
			z.max = x;
		}
		return z;
	}

	public Interval sqrt() {
		Interval z = new Interval(0.0, 0.0);
		if (this.invalido())
			return z;
		if (this.min >= 0)
			z.min = Math.sqrt(this.min);
		if (this.max >= 0)
			z.max = Math.sqrt(this.max);
		return z;
	}

	public Interval times(Interval y) {
		if (this.invalido() || y.invalido())
			return new Interval(0.0, 0.0);
		Double[] s = new Double[4];
		DoubleVector min = new DoubleVector(1, this.min);
		DoubleVector max = new DoubleVector(1, this.max);
		s[0] = min.times(y.min);
		s[1] = min.times(y.max);
		s[2] = max.times(y.min);
		s[3] = max.times(y.max);
		// bubble sort
		for (int i = 0;i <= 2;i++)
			for (int j = i + 1;j <= 3;j++)
				if (s[i] > s[j]) {
					Double d = s[i];
					s[i] = s[j];
					s[j] = d;
				}

		return new Interval(s[0], s[3]);
	}

	public Interval over(Interval y) {
		if (this.invalido() || y.invalido())
			return new Interval(0.0, 0.0);

		if (y.min.equals(0.0) && y.max.equals(0.0))
			return new Interval(0.0, 0.0);

		if (y.min.equals(0.0) && (y.max > 0)) {
			Interval z = new Interval(1.0 / y.max, Util.infty);
			return this.times(z);
		}

		if ((y.min < 0) && y.max.equals(0.0)) {
			Interval z = new Interval(Util._infty, 1.0 / y.min);
			return this.times(z);
		}

		if ((y.min < 0) && (y.max > 0))
			return new Interval(Util._infty, Util.infty);

		Double[] s = new Double[4];
		DoubleVector min = new DoubleVector(1, this.min);
		DoubleVector max = new DoubleVector(1, this.max);
		s[0] = min.over(y.min);
		s[1] = min.over(y.max);
		s[2] = max.over(y.min);
		s[3] = max.over(y.max);
		// bubble sort
		for (int i = 0;i <= 2;i++)
			for (int j = i + 1;j <= 3;j++)
				if (s[i] > s[j]) {
					Double d = s[i];
					s[i] = s[j];
					s[j] = d;
				}
		// 03
		Interval r = new Interval(s[0], s[3]);
		Interval temp = r.times(y);
		if (temp.equals(this))
			return r;

		r.max = s[2];// 02
		temp = r.times(y);
		if (temp.equals(this))
			return r;

		r.set(s[1], s[3]);// 13
		temp = r.times(y);
		if (temp.equals(this))
			return r;

		r.set(s[0], s[1]);// 01
		temp = r.times(y);
		if (temp.equals(this))
			return r;

		r.set(s[1], s[2]);// 12
		temp = r.times(y);
		if (temp.equals(this))
			return r;

		r.set(s[2], s[3]);// 23
		return r;
	}

	public Boolean le(Interval y) {
		Boolean r = this.equals(y);
		if (this.max < y.min) // 2.11 page 20
			r = true;
		return r;
	}

	public Boolean lessThan(Interval y) {
		return (this.max < y.min);// 2.11 page 20
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Interval other = (Interval) obj;
		if (max == null) {
			if (other.max != null)
				return false;
		} else if (!max.equals(other.max))
			return false;
		if (min == null) {
			if (other.min != null)
				return false;
		} else if (!min.equals(other.min))
			return false;
		return true;
	}

	public String graph() {
		return min.toString() + "\n" + max.toString() + "\n";
	}

	@Override
	public String toString() {
		if (this.invalido())
			return "Invalid Interval";

		String s1, s2;
		if (min.equals(Util._infty))
			s1 = "- infty";
		else
			s1 = min.toString();
		if (max.equals(Util.infty))
			s2 = "infty";
		else
			s2 = max.toString();
		return "Interval [min=" + s1 + ", max=" + s2 + "]";
	}

	public Interval gauss(Interval c, Interval sigma) {
		Interval Result = new Interval();
		DoubleVector x1 = new DoubleVector(1, this.min);
		DoubleVector x2 = new DoubleVector(1, this.max);
		Double y1 = x1.gauss(c.min, sigma.min);
		Double y2 = x1.gauss(c.min, sigma.max);
		Double y3 = x2.gauss(c.max, sigma.min);
		Double y4 = x2.gauss(c.max, sigma.max);
		Result.min = y1;
		if (y2 < Result.min)
			Result.min = y2;
		if (y3 < Result.min)
			Result.min = y3;
		if (y4 < Result.min)
			Result.min = y4;
		Result.max = y1;
		if (y2 > Result.min)
			Result.max = y2;
		if (y3 > Result.min)
			Result.max = y3;
		if (y4 > Result.min)
			Result.max = y4;
		if ((this.min < c.min) && (c.max < this.max)) {
		}
		else if (this.max < c.min) {
		}
		else if (c.max < this.min) {
		}
		else Result.max = 1.0;
		return Result;
	}

	public Interval muInterval(Interval a, Interval b, Interval c) {
		Interval dx, dy = new Interval(1.0, 1.0), u, v;
		if (a.equals(b)) {
			if (this.le(a))
				return new Interval(1.0, 1.0);// 1 rampa 0
			if (c.le(this))
				return new Interval(0.0, 0.0);
			dx = b.minus(c);// -Delta x = Bx - Cx
			u = dy.over(dx);
			Interval bu = u.times(b);
			v = dy.minus(bu);// By = u Bx + v
			Interval ux = u.times(this);
			return ux.plus(v);// Ry = u Rx + v
		}

		if (b.equals(c)) {
			if (this.le(a))
				return new Interval(0.0, 0.0);// 0 rampa 1
			if (c.le(this))
				return new Interval(1.0, 1.0);
			dx = b.minus(a);// Delta x = Bx - Ax
			u = dy.over(dx);
			Interval bu = u.times(b);
			v = dy.minus(bu);// By = u Bx + v
			Interval ux = u.times(this);
			return ux.plus(v);// Ry = u Rx + v
		}

		if (this.le(a) || c.le(this))
			return new Interval(0.0, 0.0);

		if (a.lessThan(this) && this.lessThan(b))
			dx = b.minus(a);// Delta x = Bx - Ax
		else
			dx = b.minus(c);// -Delta x = Bx - Cx

		u = dy.over(dx);
		Interval bu = u.times(b);
		v = dy.minus(bu);// By = u Bx + v
		Interval ux = u.times(this);
		return ux.plus(v);// Ry = u Rx + v
	}

	public Double avg() {
		if (min.equals(Util._infty))
			return min;

		if (max.equals(Util.infty))
			return max;

		return 0.5 * (min + max);
	}
}
