package br.com.calcula.wiki;

import br.com.calcula.wiki.entidades.MyTask;

public class Bayes {

	public static Boolean loggy = false;

	public static String[][] ordenar(String[][] entrada, Integer p, Integer q) {
		String[][] matriz = new String[p][q];
		for (int i = 0;i < p;i++)
			for (int j = 0;j < q;j++)
				matriz[i][j] = entrada[i][j];

		String s;
		// bubble
		for (int i = 0;i < p - 1;i++)
			for (int j = i + 1;j < p;j++)
				if (SNum.FracCompare(matriz[i][q - 1], matriz[j][q - 1]) > 0)
					for (int k = 0;k < q;k++) {
						s = matriz[i][k];
						matriz[i][k] = matriz[j][k];
						matriz[j][k] = s;
					}

		return matriz;
	}

	public static String[][] cov(String[][] A, Integer linhas, Integer colunas, String[] avg) {
		String[][] result = new String[colunas][colunas];
		String n = linhas.toString();
		Integer i, j, k;

		// a matriz eh simetrica
		for (j = 0;j < colunas;j++)
			for (k = j;k < colunas;k++)
				result[j][k] = "0";

		for (j = 0;j < colunas;j++)
			for (k = j;k < colunas;k++) {
				if (loggy)
					Util.println("j = " + j.toString() + ", k = " + k.toString());
				for (i = 0;i < linhas;i++)
					result[j][k] = SNum.FracAdd(result[j][k],
							SNum.FracMul(SNum.FracSub(A[i][j], avg[j]), SNum.FracSub(A[i][k], avg[k])));
			}

		for (i = 0;i < colunas;i++)
			for (j = i;j < colunas;j++) {
				result[i][j] = SNum.FracDiv(result[i][j], n);
				// Double d = SNum.FracToDouble(result[i][j]);
				// Util.println("eee " + d.toString());
			}

		for (i = 0;i < colunas;i++)
			for (j = i + 1;j < colunas;j++)
				result[j][i] = result[i][j];

		return result;
	}

	public static String schmidt(String[][] V, Integer n) {
		int i, j, k;
		String[][] Delta = new String[n][n];
		String[][] W = new String[n][n];

		for (i = 0;i < n;i++)
			for (j = i + 1;j < n;j++)
				Delta[j][i] = "0";

		for (k = 0;k < n;k++) {

			for (i = 0;i < n;i++) {
				W[i][k] = V[i][k];
				if (loggy)
					Util.println("wik = " + W[i][k]);
				for (j = 0;j < k;j++)
					W[i][k] = SNum.FracSub(W[i][k], SNum.FracMul(Delta[j][k], W[i][j]));
			}

			// norma da coluna W[k]
			Delta[k][k] = SNum.FracMul(W[0][k], W[0][k]);
			for (i = 1;i < n;i++)
				Delta[k][k] = SNum.FracAdd(Delta[k][k], SNum.FracMul(W[i][k], W[i][k]));
			if (loggy)
				Util.println("kk = " + Delta[k][k]);
			Delta[k][k] = SNum.FracPower(Delta[k][k], "1_2");

			for (i = 0;i < n;i++)
				W[i][k] = SNum.FracDiv(W[i][k], Delta[k][k]);

			if (k < n - 1)
				for (i = 0;i < k + 1;i++) {
					// Delta[i][k + 1] = produtoInterno(V, k + 1, W, i, n);
					Delta[i][k + 1] = SNum.FracMul(V[0][k + 1], W[0][i]);
					for (j = 1;j < n;j++)
						Delta[i][k + 1] = SNum.FracAdd(Delta[i][k + 1], SNum.FracMul(V[j][k + 1], W[j][i]));
				}
		}

		// neste momento V = Delta * W
		// Delta triangular
		// W ortogonal
		if (loggy)
			for (i = 0;i < n;i++) {
				for (j = 0;j < n;j++)
					System.out.print(Delta[i][j] + " ");
				Util.println("");
			}

		// nao sei determinante de W
		if (loggy)
			for (i = 0;i < n;i++) {
				for (j = 0;j < n;j++)
					System.out.print(W[i][j] + " ");
				Util.println("");
			}

		// diagonal
		String result = Delta[0][0];
		for (i = 1;i < n;i++)
			result = SNum.FracMul(result, Delta[i][i]);
		return result;
	}

	// retorna A sem a linha 1 e sem a coluna
	public static String[][] cofator(String[][] A, int coluna, int n) {
		String[][] result = new String[n - 1][n - 1];

		for (int i = 0;i < n - 1;i++)
			for (Integer j = 0, k = 0;j < n - 1;j++, k++) {
				if (k.equals(coluna))
					k++;
				result[i][j] = A[i + 1][k];
			}

		return result;
	}

	public static String det(String[][] K, Integer n) {
		if (loggy)
			for (int i = 0;i < n;i++) {
				for (int j = 0;j < n;j++)
					System.out.print(K[i][j] + " ");
				Util.println("");
			}

		if (n.equals(3)) {
			String s1 = SNum.FracMul(SNum.FracMul(K[0][0], K[1][1]), K[2][2]);
			String s2 = SNum.FracMul(SNum.FracMul(K[0][1], K[1][2]), K[2][0]);
			String s3 = SNum.FracMul(SNum.FracMul(K[0][2], K[1][0]), K[2][1]);
			String s4 = SNum.FracMul(SNum.FracMul(K[0][2], K[1][1]), K[2][0]);
			String s5 = SNum.FracMul(SNum.FracMul(K[0][1], K[1][0]), K[2][2]);
			String s6 = SNum.FracMul(SNum.FracMul(K[0][0], K[1][2]), K[2][1]);
			s3 = SNum.FracAdd(SNum.FracAdd(s1, s2), s3);
			s6 = SNum.FracAdd(SNum.FracAdd(s4, s5), s6);
			return SNum.FracSub(s3, s6);
		}

		if (n.equals(2))
			return SNum.FracSub(SNum.FracMul(K[0][0], K[1][1]), SNum.FracMul(K[1][0], K[0][1]));

		String result = "0", sinal = "1";
		for (Integer j = 0;j < n;j++) {
			if (!K[0][j].equals("0")) {
				if (loggy) Util.println("n = " + n.toString() + ", j = " + j.toString());
				result = SNum.FracAdd(result, SNum.FracMul(sinal, SNum.FracMul(K[0][j], det(cofator(K, j, n), n - 1))));
			}
			sinal = SNum.SNumOposto(sinal);
		}

		return result;
	}

	public static String kronecker(Integer i, Integer j) {
		if (i.equals(j))
			return "1";
		return "0";
	}

	public static String[] solve(String[][] entrada, int k, int n) throws Exception {
		String[][] A = new String[n][n];
		String[] b = new String[n];
		Integer i, j;
		for (i = 0;i < n;i++)
			for (j = 0;j < n;j++)
				A[i][j] = entrada[i][j];
		for (i = 0;i < n;i++)
			b[i] = kronecker(i, k);

		// Ax = b
		for (int pivoti = 0;pivoti < n;pivoti++) {
			Integer pivotj = pivoti;

			while (A[pivoti][pivotj].equals("0") && (pivoti < n))
				pivoti++;

			if (pivoti >= n)
				throw new Exception("Matriz singular.");

			if (!pivotj.equals(pivoti)) {
				// xchg b[pivoti], b[pivotj]
				String s = b[pivoti];
				b[pivoti] = b[pivotj];
				b[pivotj] = s;
				for (j = 0;j < n;j++) {
					// xchg A[pivoti][*], A[pivotj][*]
					s = A[pivoti][j];
					A[pivoti][j] = A[pivotj][j];
					A[pivotj][j] = s;
				}
				pivoti = pivotj;
			}

			for (i = 0;i < n;i++)
			  if (! A[i][pivotj].equals("0")) {
				  b[i] = SNum.FracDiv(b[i], A[i][pivotj]);
				  for (j = 0;j < n;j++)
				    if (! j.equals(pivotj))
					    A[i][j] = SNum.FracDiv(A[i][j], A[i][pivotj]);// coluna pivotj = 1
          A[i][pivotj] = "1";
			  }

			for (i = 0;i < n;i++)
				if ((!i.equals(pivoti)) && (! A[i][pivotj].equals("0"))) {
					b[i] = SNum.FracSub(b[i], b[pivoti]);

					for (j = 0;j < n;j++)
						// linha i -= linha pivoti. coluna pivotj enche de zeros
						A[i][j] = SNum.FracSub(A[i][j], A[pivoti][j]);
				}
		}

		// Diagonal x = b'

		for (i = 0;i < n;i++) {
			b[i] = SNum.FracDiv(b[i], A[i][i]);
		}

		return b;
	}

	public static String[][] inversa(String[][] entrada, String d, Integer n) throws Exception {
		if (n.equals(2)) {
			String[][] A = new String[2][2];
			for (Integer i = 0;i < 2;i++)
				for (Integer j = 0;j < 2;j++) {
					A[i][j] = entrada[i][j];
					// Double x = SNum.FracToDouble(A[i][j]);
				}
			// Double x = SNum.FracToDouble(d);
			String s = A[0][0];
			A[0][0] = SNum.FracDiv(A[1][1], d);
			A[1][1] = SNum.FracDiv(s, d);
			A[1][0] = SNum.FracDiv(SNum.SNumOposto(A[1][0]), d);
			A[0][1] = SNum.FracDiv(SNum.SNumOposto(A[0][1]), d);
			// for (Integer i = 0;i < 2;i++)
			// for (Integer j = 0;j < 2;j++)
			// x = SNum.FracToDouble(A[i][j]);
			return A;
		}

		Util.println("*** inversa de " + n.toString());
		String result[][] = new String[n][n];
		for (int j = 0;j < n;j++) {
			String[] x = solve(entrada, j, n);// pivotear Entrada (x) = (e_j) ==> result[j] = x
			for (int i = 0;i < n;i++)
				result[i][j] = x[i];
		}
		return result;
	}

	public static String produtoInterno(String[] x, String[] m, String[][] A, int n) {
		// y = x - m;
		String[] y = new String[n];
		int i, j;
		for (i = 0;i < n;i++)
			y[i] = SNum.FracSub(x[i], m[i]);

		// return y^t * A * y = \sum y_i A_ij y_j
		String result = "0";
		for (i = 0;i < n;i++)
			for (j = 0;j < n;j++) {
				String s = SNum.FracMul(y[i], SNum.FracMul(A[i][j], y[j]));
				Double d = SNum.FracToDouble(s);
				if (loggy)
					Util.println("parcela " + d.toString());
				result = SNum.FracAdd(result, s);
			}

		return result;
	}

	public static String pdfnvar(String[] x, String[] m, String det, String[][] inverse, int n) {
		String prod = produtoInterno(x, m, inverse, n);
		Double result = 1 / Math.sqrt(Math.pow((2 * Math.PI), n)) * 1 / Math.sqrt(SNum.FracToDouble(det))
				* Math.exp(-0.5 * SNum.FracToDouble(prod));

		if (result.isInfinite() || result.isNaN())
			result = 1.0;

		if (loggy) {
			Double z = SNum.FracToDouble(det);
			Util.println("d = " + z.toString());
			z = SNum.FracToDouble(prod);
			Util.println("prod = " + z.toString());
			Util.println("result = " + result.toString());
		}
		return SNum.DoubleToFrac(result);
	}

	public static void kmeans(MyTask myTask, String[][] M, int linhas, int colunas, int k, int index) {
		// modifica M por referencia
		Integer i, j, c, total;
		String[][] centro = new String[k][colunas];
		//Random rand = new Random();
		for (i = 0;i < k/2;i++) {
			for (j = 0;j < colunas;j++)
				centro[i][j] = M[i][j];
		}
		int a = linhas - 1;
		for (;i < k;i++, a--) {
			for (j = 0;j < colunas;j++)
				centro[i][j] = M[a][j];
		}
		String[] distancia = new String[k];
		String[][] novoCentro = new String[k][colunas];
		for (total = 1;;total++) {
			myTask.setSaida1(myTask.getSaida1() + "Iteracao " + total.toString() + "\n");
			for (i = 0;i < linhas;i++) {
				if ((i+1) % 100 == 0)
					myTask.setSaida1(myTask.getSaida1() + "linha " + i.toString() + "\n");
				for (j = 0;j < k;j++) {
					// Pitágoras em "colunas" dimensoes
					distancia[j] = "0";
					for (c = 0;c < colunas;c++) {
						distancia[j] = SNum.FracAdd(distancia[j],
								SNum.FracPower(SNum.FracSub(M[i][c], centro[j][c]), "2"));
					}
					distancia[j] = SNum.FracPower(distancia[j], "1_2");
				}
				M[i][index] = "0";
				String min = distancia[0];
				for (j = 1;j < k;j++)
					if (SNum.FracCompare(distancia[j], min) < 0) {
						M[i][index] = j.toString();
						min = distancia[j];
					}
			}

			for (j = 0;j < k;j++) {
				String[] s = new String[colunas];
				for (c = 0;c < colunas;c++)
					s[c] = "0";
				Integer contador = 0;
				for (i = 0;i < linhas;i++) {
					// if (i % 100 == 0)
					// myTask.setSaida1(myTask.getSaida1() + "linha " + i.toString() + "\n");
					if (M[i][index].equals(j.toString())) {
						for (c = 0;c < colunas;c++) {
							s[c] = SNum.FracAdd(s[c], M[i][c]);
						}
						contador++;
					}
				}
				for (c = 0;c < colunas;c++) {
					novoCentro[j][c] = SNum.FracDiv(s[c], contador.toString());
				}
			}
			Boolean flag = true;
			for (j = 0;j < k;j++) {
				for (c = 0;c < colunas;c++)
					if (!novoCentro[j][c].equals(centro[j][c])) {
						flag = false;
						break;
					}
				if (!flag)
					break;
			}
			if (flag) {
				return;
			}
			for (i = 0;i < k;i++)
				for (j = 0;j < colunas;j++)
					centro[i][j] = novoCentro[i][j];
		} // for(;;)
	}

}
