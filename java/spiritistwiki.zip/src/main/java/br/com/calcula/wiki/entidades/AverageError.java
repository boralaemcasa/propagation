package br.com.calcula.wiki.entidades;

public class AverageError {
	public SaidaDouble saida;
	public Integer epocas;
	public Double ape;
	public Double alpha;
	public Double[] q;
	public Double[][] p;
	public Double[][] c;
	public Double[][] sigma;

	public AverageError() {
		q = null;
	}

	public void copy(AverageError obj, Integer nGaussianas, Integer nVariaveis) {
		if (q == null) {
			q = new Double[nGaussianas];
			p = new Double[nGaussianas][nVariaveis];
			c = new Double[nGaussianas][nVariaveis];
			sigma = new Double[nGaussianas][nVariaveis];
		}
		alpha = obj.alpha;
		ape = obj.ape;
		//epocas = obj.epocas;
		saida = obj.saida;
		for (Integer j = 0; j < nGaussianas; j++) {
			for (Integer v = 0; v < nVariaveis; v++) {
				c[j][v] = obj.c[j][v];
				sigma[j][v] = obj.sigma[j][v];
				p[j][v] = obj.p[j][v];
			}
			q[j] = obj.q[j];
		}
	}
}
