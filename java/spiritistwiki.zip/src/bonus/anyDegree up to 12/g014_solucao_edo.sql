create table g014_solucao_edo (
  ke bigint not null,               -- k esquerdo
  se character varying(1) not null, -- somar k � esquerda: boolean
  coefd text not null,              -- coeficiente � direita
  kd bigint null,                   -- k direito, se for nulo � independente
  sd character varying(1) not null, -- somar k � esquerda: boolean
  primary key (ke, se));
  
-- cada registro faz b_{k + e} += coefd * b_{k + d}, if s = 1
-- cada registro faz b_{e} += coefd * b_{d}, if s = 0
-- cada registro faz b_{e; ou k + e} += coefd, if d is null
