create table statusWith (
  hora  character varying(255) not null,
  line integer not null,
  who1 character varying(255) not null,
  who2 character varying(255) not null,
  who3 character varying(255) not null,
  i numeric(1000,0) not null,
  a1 integer not null,
  b1 integer not null,
  mul1 integer null,
  mul2 integer null,
  primary key (hora));