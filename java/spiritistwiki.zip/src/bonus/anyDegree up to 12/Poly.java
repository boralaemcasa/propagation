package br.com.calcula.wiki;

import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import br.com.calcula.wiki.entidades.CPoly;

public class Poly {

	public static Connection conProd;

	public static void setOrdem(int x) throws SQLException {
		String query = "update poly_pa set ordem = ?";
		PreparedStatement st = conProd.prepareStatement(query);
		st.setInt(1, x);
		st.executeUpdate();
		st.close();
	}

	public static Long gravarBem(String s, Long id, Long idioma, Long linkId) throws SQLException {
		Long Result = id;
		String query = "insert into palavra (id, data_cria, usuario_id, idioma_id, descricao) values (?, current_date, ?, ?, ?)";
		try {
			PreparedStatement st = conProd.prepareStatement(query);
			st.setLong(1, id);
			st.setLong(2, Long.parseLong(Util.getUsuarioMaster()));
			st.setLong(3, idioma);
			st.setString(4, s);
			st.executeUpdate();
			st.close();
			Result++;
		} catch (SQLException e) {
		}

		query = "select id from palavra where descricao = ?";
		PreparedStatement st = conProd.prepareStatement(query);
		st.setString(1, s);
		st.execute();
		ResultSet rs = st.getResultSet();
		if (!rs.next())
			throw new SQLException("nao salvou " + s);
		int x = rs.getInt(1);
		st.close();

		query = "insert into post_palavra (palavra_id, post_idioma_id, post_link_id,\n"
				+ "data_cria, usuario_id, ordem) values (?, ?, ?,\n" + "current_date, ?, (select ordem from poly_pa))";
		st = conProd.prepareStatement(query);
		st.setInt(1, x);
		st.setLong(2, idioma);
		st.setLong(3, linkId);
		st.setLong(4, Long.parseLong(Util.getUsuarioMaster()));
		st.executeUpdate();
		st.close();

		query = "update poly_pa set ordem = ordem + 1";
		st = conProd.prepareStatement(query);
		st.executeUpdate();
		st.close();

		if (Result > id)
			System.out.println("gravou " + id.toString() + " = " + s);
		return Result;
	}

	public static Long gravar(String buf, Long id, Long idioma, Long linkId) throws SQLException {
		for (;;) {
			int i = buf.indexOf("\n");
			if (i < 0)
				break;
			id = gravarBem(buf.substring(0, i), id, idioma, linkId);
			buf = buf.substring(i + 1);
		}
		return gravarBem(buf, id, idioma, linkId);
	}

	public static void resetMaster(String w, Integer grau) throws SQLException {
// Util.initDatabase(true);
		String query = "SELECT table_name FROM information_schema.tables WHERE table_schema=\'public\' and (table_name like \'g0"
				+ grau.toString() + "pt%\' or table_name like ?) order by 1";
		PreparedStatement st = conProd.prepareStatement(query);
		st.setString(1, "g0" + grau.toString() + "p" + w);
		st.execute();
		ResultSet rs = st.getResultSet();
		while (rs.next()) {
			String tabela = "drop table " + rs.getString(1);
			PreparedStatement st2 = conProd.prepareStatement(tabela);
			st2.executeUpdate();
			st2.close();
			tabela = "drop function proc_simp" + rs.getString(1);
			st2 = conProd.prepareStatement(tabela);
			try {
				st2.executeUpdate();
			} catch (SQLException e) {
			}
			st2.close();
		}
		rs.close();
		st.close();
	}

	public static void exec2(String w, Integer grau) throws SQLException {
// Util.initDatabase(true);
		String query = "SELECT table_name FROM information_schema.tables WHERE table_schema=\'public\' and (table_name like \'g0"
				+ grau.toString() + "pm%n%\' or table_name = \'g0" + grau.toString() + "pq2\') order by 1";
		PreparedStatement st = conProd.prepareStatement(query);
		st.execute();
		ResultSet rs = st.getResultSet();
		while (rs.next()) {
			String tabela = "drop table " + rs.getString(1);
			PreparedStatement st2 = conProd.prepareStatement(tabela);
			st2.executeUpdate();
			st2.close();
			tabela = "drop function proc_simp" + rs.getString(1);
			st2 = conProd.prepareStatement(tabela);
			try {
				st2.executeUpdate();
			} catch (SQLException e) {
			}
			st2.close();
		}
		rs.close();
		st.close();
	}

	public static void powerUp(String s, String w, Integer m, Integer grau) throws SQLException {
		String query = "SELECT table_name FROM information_schema.tables WHERE table_schema=\'public\' and table_name like ? order by 1";
		PreparedStatement st = conProd.prepareStatement(query);
		st.setString(1, "g0" + grau.toString() + "p" + w);
		st.execute();
		ResultSet rs = st.getResultSet();
		while (rs.next()) {
			String tabela = "update " + rs.getString(1) + " set p" + s + " = p" + s + " + " + m.toString();
			PreparedStatement st2 = conProd.prepareStatement(tabela);
			st2.executeUpdate();
			st2.close();
		}

		rs.close();
		st.close();
	}

	public static int minPower(String s, String w, Integer grau) throws SQLException {
		Integer minimo = 999;
		String query = "SELECT table_name FROM information_schema.tables WHERE table_schema=\'public\' and table_name like ? order by 1";
		PreparedStatement st = conProd.prepareStatement(query);
		st.setString(1, "g0" + grau.toString() + "p" + w);
		st.execute();
		ResultSet rs = st.getResultSet();
		while (rs.next()) {
			String tabela = "select min(p" + s + ") m, count(*) from " + rs.getString(1);
			PreparedStatement st2 = conProd.prepareStatement(tabela);
			st2.execute();
			ResultSet rs2 = st2.getResultSet();
			if (rs2.next()) {
				Integer valor = rs2.getInt(1);
				Integer count = rs2.getInt(2);
				if ((valor < minimo) && (!count.equals(0)))
					minimo = valor;
			}
			rs2.close();
			st2.close();
		}

		rs.close();
		st.close();
		return minimo;
	}

	public static ArrayList<CPoly> qryAdd(String w, CPoly linha, Integer grau) throws SQLException {
		// Util.initDatabase(true);
		try {
			createTable(w, grau);
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		ArrayList<CPoly> result = new ArrayList<CPoly>();
		String query = "select i, coef::text coef, coefi::text coefi from g0" + grau.toString() + "p" + w
				+ " m where p1 = ?::bigint" + " and p2 = ?::bigint" + " and p3 = ?::bigint" + " and p4 = ?::bigint"
				+ " and p5 = ?::bigint" + " and p6 = ?::bigint" + " and p7 = ?::bigint" + " and p8 = ?::bigint"
				+ " and p9 = ?::bigint" + " and p10 = ?::bigint" + " and p11 = ?::bigint" + " and p12 = ?::bigint"
				+ " and p13 = ?::bigint" + " and p14 = ?::bigint";
		PreparedStatement st = conProd.prepareStatement(query);
		int i;
		for (i = 1; i <= 14; i++)
			st.setString(i, linha.p[i].toString());
		st.execute();
		ResultSet rs = st.getResultSet();
		while (rs.next()) {
			CPoly poly = new CPoly();
			poly.i = rs.getString(1);
			poly.coef = rs.getString(2);
			poly.coefi = rs.getString(3);
			// for (i = 1;i <= 14;i++)
			// poly.p[i] = linha.p[i];
			result.add(poly);
		}
		rs.close();
		st.close();
		return result;
	}

	public static void qryByPower(String w, Integer prefix, String ttx, Integer GRAU) throws SQLException {
		// Util.initDatabase(true);
		try {
			createTable(ttx, prefix);
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		String query = "insert into g0" + prefix.toString() + "p" + ttx;
		query = query
				+ " select i, coef, p1 - ?, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, coefi from g0"
				+ prefix.toString() + "p" + w + " m where p1 = ? order by p2";
		Integer j = GRAU + 2;
		String pj = "p" + j.toString();
		query = query.replace(pj, pj + " - 1");// expoente de a = 2 - 1
		PreparedStatement st = conProd.prepareStatement(query);
		st.setInt(1, GRAU);// expoente de x = 4 - 3
		st.setInt(2, Poly.maxPower(w, prefix));
		st.executeUpdate();
		st.close();
	}

	public static CPoly qryByI(String w, int i, Integer grau) throws SQLException {
		// Util.initDatabase(true);
		String query = "select i, m.coef::text coef, m.coefi::text coefi, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14 from g0"
				+ grau.toString() + "p" + w + " m where i = ?";
		PreparedStatement st = conProd.prepareStatement(query);
		st.setInt(1, i);
		st.execute();
		ResultSet rs = st.getResultSet();
		CPoly poly = new CPoly();
		if (rs.next()) {
			poly.i = rs.getString(1);
			poly.coef = rs.getString(2);
			poly.coefi = rs.getString(3);
			for (int j = 1; j <= 14; j++)
				poly.p[j] = rs.getInt(j + 3);
		}
		rs.close();
		st.close();
		return poly;
	}

	public static String greatestCommonDivisor(String w, Integer grau) throws SQLException {
		// Util.initDatabase(true);
		String s = "0", query = "select m.coef::text coef from " + w + " m order by 1";
		PreparedStatement st = conProd.prepareStatement(query);
		st.execute();
		ResultSet rs = st.getResultSet();
		if (rs.next())
			s = rs.getString(1);
		while (rs.next()) {
			String x = rs.getString(1);
			s = SNum.mdc(s, x);
			if (s.equals("1")) {
				rs.close();
				st.close();
				return s;
			}
		}
		rs.close();
		st.close();
		return s;
		// mdc a & bi/i considerar todos != 0
	}

	public static void superGreatestCommonDivisor(String w, Integer grau) throws SQLException {
		String gcd = "",
				query = "SELECT table_name FROM information_schema.tables WHERE table_schema=\'public\' and table_name like ? order by 1";
		PreparedStatement st = conProd.prepareStatement(query);
		st.setString(1, "g0" + grau.toString() + "p" + w);
		st.execute();
		ResultSet rs = st.getResultSet();
		if (rs.next())
			gcd = greatestCommonDivisor(rs.getString(1), grau);
		System.out.println(gcd.toString() + " " + rs.getString(1));
		if (!gcd.equals("1"))
			while (rs.next()) {
				String tabela = greatestCommonDivisor(rs.getString(1), grau);
				System.out.println(gcd.toString() + " // " + tabela.toString() + " " + rs.getString(1));
				if (gcd.equals("0"))
					gcd = tabela;
				else if (!tabela.equals("0"))
					gcd = SNum.mdc(gcd, tabela);
				if (gcd.equals("1"))
					break;
			}

		rs.close();
		st.close();
		if (!gcd.equals("1")) {
			st = conProd.prepareStatement(query);
			st.setString(1, "g0" + grau.toString() + "p" + w);
			st.execute();
			rs = st.getResultSet();
			while (rs.next()) {
				String tabela = "update " + rs.getString(1) + " set coef = coef / " + gcd;
				PreparedStatement st2 = conProd.prepareStatement(tabela);
				st2.executeUpdate();
				st2.close();
			}
		}
	}

	public static void qryInsMaster(String w, Integer i, CPoly linha, Integer grau) throws SQLException {
		// Util.initDatabase(true);
		String query = "insert into g0" + grau.toString() + "p" + w
				+ " values(?, ?::bigint, ?::bigint, ?::bigint, ?::bigint, ?::bigint, ?::bigint, ?::bigint, ?::bigint, ?::bigint, ?::bigint, ?::bigint, ?::bigint, ?::bigint, ?::bigint, ?::bigint, ?::bigint)";
		PreparedStatement st = conProd.prepareStatement(query);
		st.setInt(1, i);
		st.setString(2, linha.coef);
		for (int j = 1; j <= 14; j++)
			st.setString(j + 2, linha.p[j].toString());
		st.setString(17, linha.coefi);
		st.executeUpdate();
		st.close();
	}

	public static void zerar(String w, Integer grau, Integer n) throws SQLException {
		n += 2;
		// Util.initDatabase(true);
		String query = "update g0" + grau.toString() + "p" + w + " set p" + n.toString() + " = 0";
		PreparedStatement st = conProd.prepareStatement(query);
		st.executeUpdate();
		st.close();
	}

	public static void qryTTMaster(Integer grau) throws SQLException {
		// Util.initDatabase(true);
		String query = "SELECT table_name FROM information_schema.tables WHERE table_schema=\'public\' and table_name like \'g0"
				+ grau.toString() + "ptt%\' order by 1";
		PreparedStatement st = conProd.prepareStatement(query);
		st.execute();
		ResultSet rs = st.getResultSet();
		while (rs.next()) {
			String tabela = "delete from " + rs.getString(1);
			PreparedStatement st2 = conProd.prepareStatement(tabela);
			st2.executeUpdate();
			st2.close();
		}
		rs.close();
		st.close();
	}

	public static void qryDerivMaster(String who, String mywho, Integer grau) throws SQLException {
		// Util.initDatabase(true);
		try {
			createTable(who, grau);
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		String query = "insert into g0" + grau.toString() + "p" + who + " select i, coef * p1," + "  p1 - 1, p2, p3,"
				+ "  p4, p5, p6," + "  p7, p8, p9, p10, p11, p12, p13, p14, coefi * p1" + " from g0" + grau.toString()
				+ "p" + mywho + " m" + " where p1 > 0";
		PreparedStatement st = conProd.prepareStatement(query);
		st.executeUpdate();
		st.close();
	}

	public static void setWait(Integer i) throws SQLException {
// Util.initDatabase(true);
		String query = "update poly_pa set wait = ?";
		PreparedStatement st = conProd.prepareStatement(query);
		st.setInt(1, i);
		st.executeUpdate();
		st.close();
	}

	public static void incWait() throws SQLException {
// Util.initDatabase(true);
		String query = "update poly_pa set wait = wait + 1 where wait < 0";
		PreparedStatement st = conProd.prepareStatement(query);
		st.executeUpdate();
		st.close();
	}

	public static void setPolyPa(Integer i) throws SQLException {
// Util.initDatabase(true);
		String query = "update poly_pa set simplify = ?";
		PreparedStatement st = conProd.prepareStatement(query);
		st.setInt(1, i);
		st.executeUpdate();
		st.close();
	}

	public static void createTable(String w, Integer grau) throws SQLException {
		try {
			String query = "select p1 from g0" + grau.toString() + "p" + w + " limit 1";
			PreparedStatement st = conProd.prepareStatement(query);
			st.execute();
			st.close();
			return;// ja existia
		} catch (SQLException e) {

		}
		String query = "create table g0" + grau.toString() + "p" + w + " (\n" + "i bigint not null,\n"
				+ "coef numeric not null,\n" + "p1 integer not null,\n" + "p2 integer not null,\n"
				+ "p3 integer not null,\n" + "p4 integer not null,\n" + "p5 integer not null,\n"
				+ "p6 integer not null,\n" + "p7 integer not null,\n" + "p8 integer not null,\n"
				+ "p9 integer not null,\n" + "p10 integer not null,\n" + "p11 integer not null,\n"
				+ "p12 integer not null,\n" + "p13 integer not null,\n" + "p14 integer not null,\n"
				+ "coefi numeric not null,\n" + "flag character varying(1) null,\n" + "primary key (i))";
		PreparedStatement st = conProd.prepareStatement(query);
		st.executeUpdate();
		st.close();

		query = "create index g0" + grau.toString() + "ip" + w + " on g0" + grau.toString() + "p" + w
				+ "(p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14)";
		st = conProd.prepareStatement(query);
		try {
			st.executeUpdate();
		} catch (SQLException e) {
		}
		st.close();

		query = "create index g0" + grau.toString() + "ipf" + w + " on g0" + grau.toString() + "p" + w + "(flag)";
		st = conProd.prepareStatement(query);
		try {
			st.executeUpdate();
		} catch (SQLException e) {
		}
		st.close();

		query = "CREATE OR REPLACE FUNCTION proc_simp" + w + "() \n" + "RETURNS trigger AS $BODY$ \n" + "DECLARE \n"
				+ "    V_M BIGINT;\n" + "    V_S BIGINT;\n" + "BEGIN\n" + "  select simplify\n" + "  into v_s\n"
				+ "  from poly_pa;\n" + "\n" + "  if v_s = 1 then\n" + "  select min(i)\n" + "  into v_m\n"
				+ "  from g0" + grau.toString() + "p" + w + "\n" + "  where p1 = NEW.p1\n" + " and p2 = NEW.p2\n"
				+ " and p3 = NEW.p3\n" + " and p4 = NEW.p4\n" + " and p5 = NEW.p5\n" + " and p6 = NEW.p6\n"
				+ " and p7 = NEW.p7" + " and p8 = NEW.p8" + " and p9 = NEW.p9" + " and p10 = NEW.p10"
				+ " and p11 = NEW.p11" + " and p12 = NEW.p12" + " and p13 = NEW.p13" + " and p14 = NEW.p14;\n" + " \n"
				+ "  if v_m is not null then \n" + " update g0" + grau.toString() + "p" + w + "\n" + " set flag = 'S'\n"
				+ " where (flag <> 'S' or flag is null)\n" + "  and i = v_m;\n" + "  \n" + " NEW.flag := 'S';\n"
				+ "  end if;\n" + "  end if;\n" + "     \n" + "  RETURN NEW;\n"
				+ "END;$BODY$ LANGUAGE plpgsql VOLATILE";
		st = conProd.prepareStatement(query);
		try {
			st.executeUpdate();
		} catch (SQLException e) {
		}
		st.close();

		/*
		 * query = "CREATE TRIGGER tg_simp" + w + " BEFORE INSERT ON p" + w +
		 * " FOR EACH ROW EXECUTE PROCEDURE proc_simp" + w + "()";st =
		 * conProd.prepareStatement(query);st.executeUpdate();st.close();
		 */
	}

	public static void sumMaster(String w1, String w2, Integer grau) throws SQLException {
// Util.initDatabase(true);
		try {
			createTable(w1, grau);
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		String query = "insert into g0" + grau.toString() + "p" + w1 + " select" + "  i + ?, coef," + "  p1, p2, p3,"
				+ "  p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, coefi " + "from g0" + grau.toString() + "p" + w2;
		PreparedStatement st = conProd.prepareStatement(query);
		st.setInt(1, Poly.maxI(w1, grau));
		st.executeUpdate();
		st.close();
	}

	public static void timesMaster(String w1, String w2, String kRe, String kIm, Integer grau) throws SQLException {
// Util.initDatabase(true);
		try {
			createTable(w1, grau);
		} catch (SQLException e) {
			delMaster(w1, 0, grau);
		}
		setPolyPa(0);
		String query = "insert into g0" + grau.toString() + "p" + w1 + " select "
				+ " i, (?::numeric * coef - ?::numeric * coefi)," + "  p1, p2, p3,"
				+ "  p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, (?::numeric * coefi + ?::numeric * coef) "
				+ "from g0" + grau.toString() + "p" + w2;
		PreparedStatement st = conProd.prepareStatement(query);
		st.setString(1, kRe);
		st.setString(2, kIm);
		st.setString(3, kRe);
		st.setString(4, kIm);
		st.executeUpdate();
		st.close();
		setPolyPa(1);
	}

	public static void mult(String w0, String w1, String w2, Integer grau) throws SQLException {
// Util.initDatabase(true);
		try {
			createTable(w0, grau);
		} catch (SQLException e) {
			delMaster(w0, 0, grau);
		}
		setPolyPa(0);
		String query = " insert into g0" + grau.toString() + "p" + w0
				+ " select row_number() over (order by c1) as newi, " + "   sum(coef), " + "   c1, c2, c3, "
				+ "   c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14, sum(coefi)  " + " from " + " ( select "
				+ "   (coefA * coefC - coefBi * coefDi) as coef, " + "   a.p1 + b.p1 c1, " + "   a.p2 + b.p2 c2, "
				+ "   a.p3 + b.p3 c3, " + "   a.p4 + b.p4 c4, " + "   a.p5 + b.p5 c5, " + "   a.p6 + b.p6 c6, "
				+ "   a.p7 + b.p7 c7,  " + "   a.p8 + b.p8 c8,  " + "   a.p9 + b.p9 c9,  " + "   a.p10 + b.p10 c10,  "
				+ "   a.p11 + b.p11 c11,  " + "   a.p12 + b.p12 c12,  " + "   a.p13 + b.p13 c13,  "
				+ "   a.p14 + b.p14 c14, (coefA * coefDi + coefC * coefBi) as coefi  " + " from " + " ( " + " select "
				+ "   m.i i1, " + "   m.coef coefA, " + "   p1, p2, p3, "
				+ "   p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, m.coefi coefBi  " + " from g0" + grau.toString()
				+ "p" + w1 + " m) A, " + " (select " + "   m.i i2, " + "   m.coef coefC, " + "   p1, p2, p3, "
				+ "   p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, m.coefi coefDi  " + " from g0" + grau.toString()
				+ "p" + w2 + " m) B) C " + " group by c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14 ";
		PreparedStatement st = conProd.prepareStatement(query);
		st.executeUpdate();
		st.close();
		setPolyPa(1);
	}

	public static void multC(String w0, String w1, String w2, Long offset, Integer a1, Integer b1, Integer a2,
			Integer b2) throws SQLException {
		String query;
		PreparedStatement st;

//if (a1.equals(0) && b1.equals(0)) {
// Util.initDatabase(true);
//createTable(w0);
//}

		Connection newCon = DriverManager.getConnection(Util.getDatabaseURL(), Util.getDatabaseUser(),
				Util.getDatabasePwd());
		query = "select proc_mult" + w0 + "_" + w1 + "_" + w2 + "(?, ?, ?, ?, ?) from usuario limit 1";
		st = newCon.prepareStatement(query);
		st.setLong(1, offset);
		st.setInt(2, a1);
		st.setInt(3, a2);
		st.setInt(4, b1);
		st.setInt(5, b2);
		System.out.println("proc_mult " + offset.toString() + ", " + a1.toString() + ", " + b1.toString());
		/*
		 * System.out.println("debug " + w0 + "." + offset.toString() + "." + w1 + "." +
		 * a1.toString() + "." + a2.toString() + "." + w2 + "." + b1.toString() + "." +
		 * b2.toString());
		 */
// try {
		st.execute();
		st.close();
		newCon.close();
// } catch (Exception e) {
// Util.kill();
// Poly.continueN(5);
// System.out.println("[5 processado via continue.]");
// throw new SQLException (e.getMessage());
// }
	}

	public static Integer maxI(String w, Integer grau) throws SQLException {
		Integer Result = 0;
// Util.initDatabase(true);
		String query = "select max(i) m from g0" + grau.toString() + "p" + w;
		try {
			PreparedStatement st = conProd.prepareStatement(query);
			st.execute();
			ResultSet rs = st.getResultSet();
			if (rs.next()) {
				Result = rs.getInt(1);
			}
			rs.close();
			st.close();
		} catch (SQLException e) {
			e.printStackTrace();
			conProd = DriverManager.getConnection(Util.getDatabaseURL(), Util.getDatabaseUser(), Util.getDatabasePwd());
		}
		return Result;
	}

	public static String paramWait() throws SQLException {
		String Result = "0";
		Util.initDatabase(true);
		String query = "select wait from poly_pa";
		Connection c = DriverManager.getConnection(Util.getDatabaseURL(), Util.getDatabaseUser(),
				Util.getDatabasePwd());
		PreparedStatement st = c.prepareStatement(query);
		st.execute();
		ResultSet rs = st.getResultSet();
		if (rs.next()) {
			Integer i = rs.getInt(1);
			Result = i.toString();
		}
		rs.close();
		st.close();
		c.close();
		return Result;
	}

	public static Integer maxPower(String w, Integer grau) throws SQLException {
		Integer Result = 0;
// Util.initDatabase(true);
		while (true)
			try {
				String query = "select max(p1) m from g0" + grau.toString() + "p" + w;
				PreparedStatement st = conProd.prepareStatement(query);
				st.execute();
				ResultSet rs = st.getResultSet();
				if (rs.next()) {
					Result = rs.getInt(1);
				}
				rs.close();
				st.close();
				break;
			} catch (SQLException e) {
				e.printStackTrace();
				conProd = DriverManager.getConnection(Util.getDatabaseURL(), Util.getDatabaseUser(),
						Util.getDatabasePwd());
			}
		return Result;
	}

	public static Integer counter(String w, Integer i, Integer grau) throws SQLException {
		Integer Result = 0;
// Util.initDatabase(true);
		String query = "select count(*) c from g0" + grau.toString() + "p" + w + " where i >= ?";
		PreparedStatement st = conProd.prepareStatement(query);
		st.setInt(1, i);
		try {
			st.execute();
			ResultSet rs = st.getResultSet();
			if (rs.next()) {
				Result = rs.getInt(1);
			}
			rs.close();
		} catch (SQLException e) { // return 0;
		}
		st.close();
		return Result;
	}

	public static Integer termosGEGrau(String w, Integer prefix, Integer GRAU) throws SQLException {
		Integer Result = 0;
// Util.initDatabase(true);
		String query = "select count(*) c from g0" + prefix.toString() + "p" + w + " where p1 >= ?";
		PreparedStatement st = conProd.prepareStatement(query);
		st.setInt(1, GRAU);
		try {
			st.execute();
			ResultSet rs = st.getResultSet();
			if (rs.next()) {
				Result = rs.getInt(1);
			}
			rs.close();
		} catch (SQLException e) { // return 0;
		}
		st.close();
		return Result;
	}

	public static ArrayList<CPoly> minI(String w, Integer grau) throws SQLException {
		ArrayList<CPoly> Result = new ArrayList<CPoly>();
// Util.initDatabase(true);
		String query = "select sum(coef)::text as coef, sum(coefi)::text as coefi" + "  min(i) as m"
				+ ", p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14 " + "from g0" + grau.toString() + "p"
				+ w + " m " + "group by " + "  p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14 "
				+ "having count(*) > 1";
		PreparedStatement st = conProd.prepareStatement(query);
		st.execute();
		ResultSet rs = st.getResultSet();
		while (rs.next()) {
			CPoly p = new CPoly();
			p.coef = rs.getString(1);
			p.coefi = rs.getString(2);
			p.i = rs.getString(3);
			Result.add(p);
		}
		rs.close();
		st.close();
		return Result;
	}

	public static ArrayList<CPoly> byPower(String w, Integer grau, Integer n) throws SQLException {
		ArrayList<CPoly> Result = new ArrayList<CPoly>();
// Util.initDatabase(true);
		String query = "select" + "  i, p.coef::text as coef, p.coefi::text as coefi, " + "  p1, p2, p3,"
				+ "  p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14 " + "from g0" + grau.toString() + "p" + w + " p "
				+ "where p1 = ? " + "order by p2";
		PreparedStatement st = conProd.prepareStatement(query);
		st.setInt(1, n);
		st.execute();
		ResultSet rs = st.getResultSet();
		while (rs.next()) {
			CPoly p = new CPoly();
			p.i = rs.getString(1);
			p.coef = rs.getString(2);
			p.coefi = rs.getString(3);
			for (int i = 2; i <= 14; i++)
				p.p[i] = rs.getInt(i + 3);
			Result.add(p);
		}
		rs.close();
		st.close();
		return Result;
	}

	public static String extractSpecial(String s) {
		String x = "";
		for (int i = 0; i < s.length(); i++) {
			char ch = s.charAt(i);
			if (!Util.charInSet(ch, " \n\t/*#\'\".;?-??:{}???\240_|+???&#??"))
				x = x + ch;
		}
		return x;
	}

	public static String adjoint(Boolean link, String s) {
		int i = 0;
		while ((!s.equals(""))
				&& (!Util.charInSet(s.charAt(0), "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789&???????????????????")))
			s = s.substring(1);
		while ((!s.equals("")) && (!Util.charInSet(s.charAt(s.length() - 1),
				"ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789&???????????????????")))
			s = s.substring(0, s.length() - 1);
		if (s.startsWith("CAP."))
			s = s.substring(4);

		if ((!s.equals("")) && (!link)) {
			s = extractSpecial(s);

			if (!s.equals(""))
				if (Util.charInSet(s.charAt(0), "0123456789\n")) {
					for (; i < s.length(); i++)
						if (!Util.charInSet(s.charAt(i), "0123456789\n"))
							break;
					for (;;) {
						if (i >= s.length())
							break;
						s = Util.insert("\n", s, i + 1);
						for (i++; i < s.length(); i++)
							if (Util.charInSet(s.charAt(i), "0123456789\n"))
								break;
						if (i >= s.length())
							break;
						s = Util.insert("\n", s, i + 1);
						for (i++; i < s.length(); i++)
							if (!Util.charInSet(s.charAt(i), "0123456789\n"))
								break;
					}
				} else {
					for (; i < s.length(); i++)
						if (Util.charInSet(s.charAt(i), "0123456789\n"))
							break;
					for (;;) {
						if (i >= s.length())
							break;
						s = Util.insert("\n", s, i + 1);
						for (i++; i < s.length(); i++)
							if (!Util.charInSet(s.charAt(i), "0123456789\n"))
								break;
						if (i >= s.length())
							break;
						s = Util.insert("\n", s, i + 1);
						for (i++; i < s.length(); i++)
							if (Util.charInSet(s.charAt(i), "0123456789\n"))
								break;
					}
				}
		}
		return s;
	}

	public static Long newText(FileWriter fw, String param, Long indiceId, Long idioma, Long linkId)
			throws SQLException {
		setOrdem(1);
		param = param.toUpperCase();
		param = param.replace("&NBSP;", " ").replace("&QUOT;", "\"").replace("HTTP", ";HTTP");
		String s = "", set = "";
		Boolean copiar = true;
		for (int i = 0; i < param.length(); i++) {
			char ch = param.charAt(i);

			Boolean saltar = Util.charInSet(ch, ",()[]?!?");// interroga?ao;? link, exclama?ao, nao

			if (!saltar) {
				if (ch == '<')
					copiar = false;
				else if (ch == '>') {
					copiar = true;
					ch = ' ';
					s = s + ch;
				} else if (copiar)
					s = s + ch;

				Boolean link = (s.contains("HTTP") || s.contains("WWW") || (s.contains("&") && s.contains(";")));
				if (link)
					set = "\n ;\t";
				else
					set = "\n ;-\t";

				if (Util.charInSet(ch, set)) {
					s = adjoint(link, s);

					if (!s.equals("")) {
						indiceId = gravar(s, indiceId, idioma, linkId);
						s = "";
					}
				}
			}
		}

		Boolean link = (s.contains("HTTP") || s.contains("WWW") || (s.contains("&") && s.contains(";")));
		if (!s.equals(""))
			if (link) {
				indiceId = gravar(s, indiceId, idioma, linkId);
				s = "";
			} else
				indiceId = gravar(adjoint(link, s), indiceId, idioma, linkId);

		return indiceId;
	}

	public static Long primeiroTexto(Long indiceId, Long idiomaId, FileWriter fw) throws SQLException {
		// Util.initDatabase(true);
		Integer total = 0;
		String query = "select count(*) from post where idioma_id = " + idiomaId.toString();
		PreparedStatement st = conProd.prepareStatement(query);
		st.execute();
		ResultSet rs = st.getResultSet();
		if (rs.next()) {
			total = rs.getInt(1);
		}
		rs.close();
		st.close();

		query = "select texto, link_id from post where idioma_id = " + idiomaId.toString();
		st = conProd.prepareStatement(query);
		st.execute();
		rs = st.getResultSet();
		Integer contador = 0;
		while (rs.next()) {
			contador++;
			Integer percent = contador * 100 / total;
			System.out.println(contador.toString() + "/" + total.toString() + " = " + percent.toString() + "%");
			String s = rs.getString(1);
			Long linkId = rs.getLong(2);
			indiceId = Poly.newText(fw, s, indiceId, idiomaId, linkId);
		}
		rs.close();
		st.close();
		return indiceId;
	}

	public static void simplify(HttpSession session, String w, Integer grau) throws SQLException {
// Util.initDatabase(true);
		// query = "update g0" + grau.toString() + "p" + w + " set flag = \'S\'";
		// st = conProd.prepareStatement(query);
		// st.executeUpdate();
		// st.close();

		resetMaster(w + "simple", grau);
		createTable(w + "simple", grau);

		String query = "insert into g0" + grau.toString() + "p" + w + "simple\n"
				+ "   select row_number() over (order by p1) as newi, sum(coef),\n"
				+ " p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, sum(coefi), null\n" + "   from g0"
				+ grau.toString() + "p" + w + " m\n"
				+ "  group by p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14\n"
				+ "  having sum(coef) <> 0";
		PreparedStatement st = conProd.prepareStatement(query);
		st.executeUpdate();
		st.close();

		query = " drop table g0" + grau.toString() + "p" + w;
		st = conProd.prepareStatement(query);
		st.executeUpdate();
		st.close();

		query = " alter table g0" + grau.toString() + "p" + w + "simple rename to g0" + grau.toString() + "p" + w;
		st = conProd.prepareStatement(query);
		st.executeUpdate();
		st.close();
	}

	public static void procMult(String w0, String w1, String w2, Integer grau) throws SQLException {
		// Util.initDatabase(true);
		String query = "CREATE OR REPLACE FUNCTION proc_mult" + w0 + "_" + w1 + "_" + w2
				+ "(p_offset bigint, p_a1 bigint, p_a2 bigint, p_b1 bigint, p_b2 bigint) RETURNS INTEGER AS $$\n"
				+ "BEGIN\n" + " insert into g0" + grau.toString() + "p" + w0
				+ " select p_offset::bigint + row_number() over (order by c1) as newi, " + "   sum(coef), "
				+ "   c1, c2, c3, " + "   c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14, sum(coefi), \'S\'  "
				+ " from " + " ( select " + "   (coefA * coefC - coefBi * coefDi) as coef, " + "   a.p1 + b.p1 c1, "
				+ "   a.p2 + b.p2 c2, " + "   a.p3 + b.p3 c3, " + "   a.p4 + b.p4 c4, " + "   a.p5 + b.p5 c5, "
				+ "   a.p6 + b.p6 c6, " + "   a.p7 + b.p7 c7,  " + "   a.p8 + b.p8 c8,  " + "   a.p9 + b.p9 c9,  "
				+ "   a.p10 + b.p10 c10,  " + "   a.p11 + b.p11 c11,  " + "   a.p12 + b.p12 c12,  "
				+ "   a.p13 + b.p13 c13,  " + "   a.p14 + b.p14 c14, (coefA * coefDi + coefC * coefBi) as coefi  "
				+ " from " + " ( " + " select " + "   m.i i1, " + "   m.coef coefA, , m.coefi coefBi, "
				+ "   p1, p2, p3, " + "   p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14  " + " from g0"
				+ grau.toString() + "p" + w1 + " m " + " where m.i between p_a1 and p_a2 " + " ) A, " + " (select "
				+ "   m.i i2, " + "   m.coef coefC, m.coefi coefDi," + "   p1, p2, p3, "
				+ "   p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14  " + " from g0" + grau.toString() + "p" + w2
				+ " m " + " where m.i between p_b1 and p_b2 " + " ) B) C "
				+ " group by c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14;\n" + "   RETURN 0;\n"
				+ "END;$$ \n" + "LANGUAGE plpgsql";
		PreparedStatement st = conProd.prepareStatement(query);
		st.executeUpdate();
		st.close();
	}

	public static void disProcMult(String w0, String w1, String w2) throws SQLException {
		// Util.initDatabase(true);
		String query = "drop FUNCTION proc_mult" + w0 + "_" + w1 + "_" + w2
				+ "(p_offset bigint, p_a1 bigint, p_a2 bigint, p_b1 bigint, p_b2 bigint)";
		PreparedStatement st = conProd.prepareStatement(query);
		try {
			st.executeUpdate();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		st.close();
	}

	public static Integer classify(String w, Integer grau) throws SQLException {
// Util.initDatabase(true);
		String query = "CREATE OR REPLACE FUNCTION CLASSIFY() RETURNS BIGINT AS $$\n" + "DECLARE \n"
				+ "    V_M BIGINT;\n" + "    V_C BIGINT;\n" + "    titles TEXT DEFAULT '';\n"
				+ "    rec_film   RECORD;\n" + "    cur_films CURSOR \n" + "       FOR SELECT i, newi FROM (\n"
				+ "   select I, row_number() over (order by I) as newi\n" + "   from g0" + grau.toString() + "p" + w
				+ ") A\n" + "   where A.i <> A.newi;\n" + "BEGIN\n" + "   SELECT MAX(I) M, COUNT(*) C\n"
				+ "   INTO V_M, V_C\n" + "   FROM g0" + grau.toString() + "p" + w + ";\n" + "   IF V_M <> V_C THEN\n"
				+ "   OPEN cur_films;\n" + "     LOOP\n" + "  FETCH cur_films INTO rec_film;\n"
				+ "  EXIT WHEN NOT FOUND;\n" + " \n" + " update g0" + grau.toString() + "p" + w + "\n"
				+ " set i = rec_film.newi\n" + " where i = rec_film.i;\n" + "   END LOOP;\n" + "   CLOSE cur_films;\n"
				+ "   END IF;\n" + "   RETURN V_C;\n" + "END;$$ \n" + "LANGUAGE plpgsql";
		PreparedStatement st = conProd.prepareStatement(query);
		st.executeUpdate();
		st.close();

		Integer Result = 0;
		query = "select classify() from poly_pa limit 1";
		st = conProd.prepareStatement(query);
		st.execute();
		ResultSet rs = st.getResultSet();
		if (rs.next()) {
			Result = rs.getInt(1);
		}
		rs.close();
		st.close();
		return Result;
	}

	public static void delAllMaster(Integer grau) throws SQLException {
// Util.kill();
		String query = "SELECT table_name FROM information_schema.tables WHERE table_schema=\'public\' and table_name like \'g0"
				+ grau.toString() + "p%\' and table_name not like \'g0" + grau.toString() + "pm%\' order by 1";
		PreparedStatement st = conProd.prepareStatement(query);
		st.execute();
		ResultSet rs = st.getResultSet();
		while (rs.next()) {
			String tabela = "drop table " + rs.getString(1);
			PreparedStatement st2 = conProd.prepareStatement(tabela);
			st2.executeUpdate();
			st2.close();
		}
		rs.close();
		st.close();
	}

	public static void delAllStatusWith() throws SQLException {
// Util.kill();
		String query = "delete from statusWith where hora < to_char(now() - INTERVAL \'160 HOURS\', \'YYYY/MM/DD \')";
		PreparedStatement st = conProd.prepareStatement(query);
		st.executeUpdate();
		st.close();
	}

	public static void delAllStatusOut() throws SQLException {
// Util.kill();
		String query = "delete from statusOut where hora < to_char(now() - INTERVAL \'160 HOURS\', \'YYYY/MM/DD \')";
		PreparedStatement st = conProd.prepareStatement(query);
		st.executeUpdate();
		st.close();
	}

	public static void delMaster(String w, Integer min, Integer grau) throws SQLException {
		// Util.initDatabase(true);
		String query = "delete from g0" + grau.toString() + "p" + w + " where i >= ?";
		PreparedStatement st = conProd.prepareStatement(query);
		st.setInt(1, min);
		st.executeUpdate();
		st.close();
	}

	public static void delMasterOne(String w, String min, Integer grau) throws SQLException {
		// Util.initDatabase(true);
		String query = "delete from g0" + grau.toString() + "p" + w + " where i::text = ?";

		PreparedStatement st = conProd.prepareStatement(query);
		st.setString(1, min);
		st.executeUpdate();
		st.close();
	}

	public static void delMasterPower(String w, Integer grau) throws SQLException {
		// Util.initDatabase(true);
		String query = "delete from g0" + grau.toString() + "p" + w + " where p1 = ?";

		PreparedStatement st = conProd.prepareStatement(query);
		st.setInt(1, maxPower(w, grau));
		st.executeUpdate();
		st.close();
	}

	public static void updateCoef(String coef, String w, Integer min, Integer grau) throws SQLException {
// Util.initDatabase(true);
		String query = "update g0" + grau.toString() + "p" + w + " set coef = ?::numeric where i = ?";

		PreparedStatement st = conProd.prepareStatement(query);
		st.setString(1, coef);
		st.setInt(2, min);
		st.executeUpdate();
		st.close();
	}

	public static void extractMaster(String w, String origem, Integer p, Integer grau) throws SQLException {
// Util.initDatabase(true);
		createTable(w, grau);

		setPolyPa(0);
		String query = "insert into g0" + grau.toString() + "p" + w + " select " + "  i, coef," + "  0 as p1, p2, p3,"
				+ "  p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, coefi " + "from g0" + grau.toString() + "p"
				+ origem + " m " + "where p1 = ?";
		PreparedStatement st = conProd.prepareStatement(query);
		st.setInt(1, p);
		try {
			st.executeUpdate();
			st.close();
		} catch (SQLException e) {
			e.printStackTrace();
			conProd = DriverManager.getConnection(Util.getDatabaseURL(), Util.getDatabaseUser(), Util.getDatabasePwd());
		}
		setPolyPa(1);
	}

	public static void statusWithoutCount(String where, Integer i, Integer j, Integer k, Integer max, Integer minimo,
			Integer count, TPoly[][] a, TPoly[] m, Integer[] simples, String p1, String p2, String p3, String p4,
			String u, String s, Integer grau) throws SQLException {
// Util.initDatabase(true);
		String query = "insert into statusOut values(to_char(now() - INTERVAL \'" + Util.GMT
				+ " HOURS\', \'YYYY/MM/DD HH24:mi:ss.US\'), ?, ?, ?, ?, ?, ?, ?" + ", ?, ?, ?, ?, ?, ?" // j = 0
				+ ", ?, ?, ?, ?, ?, ?" // 1
				+ ", ?, ?, ?, ?, ?, ?" // 2
				+ ", ?, ?, ?, ?, ?, ?" // 3
				+ ", ?, ?, ?, ?, ?, ?" // 4
				+ ", ?, ?, ?, ?, ?, ?" // m
				+ ", ?, ?, ?, ?, ?, ?" // simples
				+ ", ?, ?, ?, ?" // pi
				+ ", ?, ?)";// u, s

		if (grau > 5)
			grau = 5;

		PreparedStatement st = conProd.prepareStatement(query);
		int x = 1;
		st.setString(x++, where);
		st.setInt(x++, i);
		st.setInt(x++, j);
		st.setInt(x++, k);
		st.setInt(x++, max);
		st.setInt(x++, minimo);
		st.setInt(x++, count);
		int y = x;
		for (int ii = 0; ii <= 5; ii++)
			for (int jj = 0; jj <= 5 - 1; jj++)
				st.setString(x++, "");
		for (int ii = 0; ii <= 5; ii++)
			st.setString(x++, "");
		for (int ii = 0; ii <= 5; ii++)
			st.setInt(x++, 0);

		for (int ii = 0; ii <= grau; ii++)
			for (int jj = 0; jj <= grau - 1; jj++)
				st.setString(y++, a[ii][jj].mywho);
		for (int ii = 0; ii <= grau; ii++)
			st.setString(y++, m[ii].mywho);
		for (int ii = 0; ii <= grau; ii++)
			st.setInt(y++, simples[ii]);

		st.setString(x++, p1);
		st.setString(x++, p2);
		st.setString(x++, p3);
		st.setString(x++, p4);
		st.setString(x++, u);
		st.setString(x++, s);
		st.executeUpdate();
		st.close();
	}

	public static void statusWithCount(Integer line, String who1, String who2, String who3, Long i, Integer a1,
			Integer b1, Integer a2, Integer b2, Integer c1, Integer c2) throws SQLException {
// Util.initDatabase(true);
		String query = "insert into statusWith " + "select to_char(now() - INTERVAL \'" + Util.GMT
				+ " HOURS\', \'YYYY/MM/DD HH24:mi:ss.US\'), ?, ?, ?, ?" // who
				+ ", ?::numeric, ?, ?, ?, ?" + "from poly_pa";

		PreparedStatement st = conProd.prepareStatement(query);
		int x = 1;
		st.setInt(x++, line);
		st.setString(x++, who1);
		st.setString(x++, who2);
		st.setString(x++, who3);
		st.setString(x++, i.toString());
		st.setInt(x++, a1);
		st.setInt(x++, b1);
		st.setInt(x++, c1);
		st.setInt(x++, c2);
		st.executeUpdate();
		st.close();
	}

	public static String nTimesStr(int n, String s) {
		int i;
		String result = "";
		for (i = 1; i <= n; i++)
			result = result + s;
		return result;
	}

	public static void manutencao(Integer p) throws SQLException {

		Util.initDatabase(Util.getProducao());
		conProd = DriverManager.getConnection(Util.getDatabaseURL(), Util.getDatabaseUser(), Util.getDatabasePwd());

		for (Integer grau = 2; grau < p - 2; grau++)
			for (Integer i = 0; i <= grau; i++)
				for (Integer j = 0; j < grau; j++) {
					String tabela = "alter table g0" + grau.toString() + "pmi" + i.toString() + "j" + j.toString()
							+ " add column p" + p.toString() + " integer";
					PreparedStatement st = conProd.prepareStatement(tabela);
					st.executeUpdate();
					st.close();
				}
	}

	public static void delphiSubstituir(HttpSession session, Integer n) throws SQLException {
		Integer prefix = 14;

		String[] substRe = new String[15];
		String[] substIm = new String[15];
		Object obj;

		for (Integer i = 1; i <= 12; i++) {
			substRe[i + 2] = "";
			substIm[i + 2] = "";
			if (i < n) { // coeficiente de a_n x^n deixa quieto
				obj = session.getAttribute("ixre" + i.toString());
				if (obj != null) {
					substRe[i + 2] = obj.toString();
					if (!substRe[i + 2].equals(SNum.Valida(SNum.FracValida(substRe[i + 2]))))
						substRe[i + 2] = "";
				}

				obj = session.getAttribute("ixim" + i.toString());
				if (obj != null) {
					substIm[i + 2] = obj.toString();
					if (!substIm[i + 2].equals(SNum.Valida(SNum.FracValida(substIm[i + 2]))))
						substIm[i + 2] = "";
				}

				if ((!substIm[i + 2].equals("")) && substRe[i + 2].equals(""))
					substRe[i + 2] = "0";

				if (substIm[i + 2].equals("") && (!substRe[i + 2].equals("")))
					substIm[i + 2] = "0";
			}
		}

		Util.initDatabase(Util.getProducao());
		conProd = DriverManager.getConnection(Util.getDatabaseURL(), Util.getDatabaseUser(), Util.getDatabasePwd());
		System.out.println("delphi " + prefix.toString() + ". vou dropar");
		resetMaster("%", prefix);
		logReset(prefix);

		TPoly p, plinha, plinha2;
		TPoly[] q, qq, temp = new TPoly[4];
		Integer i, j, max;
		String s;

//derive n - 1 vezes: a_n x^n + ... + a_1 x + s = p + s = 0
//                    p' x' + 1 = 0
//                    x' = -1/p'

// p'' (x')^2 + p' x''  = 0
// p'' + (p')^3 x'' = 0
// x'' = - p'' /(p')^3
// q_2 = - p''

// i >= 2
// x^(i) = q_i / (p')^{2i - 1}
// (p')^{2i - 1} x^(i) - q_i = 0
// (2i - 1) (p')^{2i - 2} x' x^(i) + (p')^{2i - 1} x^(i + 1) - q_i' = 0
// - (2i - 1) q_i / (p')^2 + (p')^{2i - 1} x^(i + 1) - q_i' = 0
// - (2i - 1) q_i + (p')^{2i + 1} x^(i + 1) - q_i' (p')^2 = 0
// x^(i + 1) = [q_i' (p')^2 + (2i - 1) q_i] / (p')^{2i + 1}

// q_{i + 1} = q_i' (p')^2 + (2i - 1) q_i

		q = new TPoly[n + 1];
		qq = new TPoly[n + 1];
		p = TPoly.create(session, prefix);// x_1 = x, x_2 = s, x_3 = a_1, ..., x_{n + 2} = a_n
		for (i = 1; i <= n; i++)
			if (!substRe[i + 2].equals("")) {
				p.addToDisk("plambda", substRe[i + 2] + "." + substIm[i + 2] + "." + i.toString());
				System.out.println(substRe[i + 2] + "." + substIm[i + 2] + "." + i.toString());
			} else
				p.addToDisk("plambda", "1.0." + i.toString() + nTimesStr(i, ".0") + ".1");
		p.mywho = "plambda";
		System.out.println("plambda");

		plinha = p.derivateToDisk("L", prefix);
		System.out.println("L");
		temp[1] = plinha.derivateToDisk("T1", prefix);
		System.out.println("T1");
		q[2] = temp[1].timesConstantToDisk("q2", "-1", "0");
		System.out.println("q2");

		plinha2 = plinha.multiplyToDisk("l2", plinha);
		System.out.println("l2");

// p(x) + s == 0 ====> a_n x^n == - s - Q
		temp[1] = p.timesConstantToDisk("p", "-1", "0");
		temp[1].addToDisk("p", "-1.0.0.1");// -s
		if (!substRe[i + 2].equals("")) {
			temp[1].addToDisk("p", substRe[i + 2] + "." + substIm[i + 2] + "." + n.toString());// x^n a_n
			System.out.println(substRe[i + 2] + "." + substIm[i + 2] + "." + n.toString());// x^n a_n
		} else
			temp[1].addToDisk("p", "1.0." + n.toString() + nTimesStr(n, ".0") + ".1");// x^n a_n
		p = temp[1];
		p.DiskSimplify();
		System.out.println("p");

		logar(prefix, "vou reduzir l2");
		plinha2.diskReduce("l2", p, prefix, n);

		for (i = 2; i <= n - 2; i++) {
			s = SNum.Subtrai(SNum.Multiplica("2", i.toString()), "1");
			logar(prefix, "temp1 = derivar q[" + i.toString() + "]");
			temp[1] = q[i].derivateToDisk("T2", prefix);

			logar(prefix, "temp3 = vezes constante " + s);
			temp[3] = q[i].TimesConstantToDisk("T3", s, "0");

			Integer i2 = i + 1;
			logar(prefix, "disk " + i2.toString() + " = multiplicar por plinha^2");
			temp[2] = plinha2.multiplyToDisk("q" + i2.toString(), temp[1]);

			logar(prefix, "q[" + i2.toString() + "] = sum [to disk] temp 3");
			q[i + 1] = temp[2].sumToDisk("q" + i2.toString(), temp[3]);

			resetMaster("m%n" + prefix.toString(), prefix);

			logar(prefix, "vou reduzir q[" + i2.toString() + "]");
			q[i + 1].diskReduce("q" + i2.toString(), p, prefix, n);
		}

// \sum m_i x^(i) + m_n == 0
// \sum_1^{n-1} m_i q_i (p')^{2n - 2 - 2i} + (m_0 x + m_n) (p')^{2n - 3} == 0

		q[0] = TPoly.create(session, prefix);
		q[0].addToDisk("q0", "1.0.1");// x
		q[0].mywho = "q0";

		q[1] = TPoly.create(session, prefix);
		q[1].addToDisk("q1", "-1.0");// -1
		q[1].mywho = "q1";

		if (n.equals(2))
			exec2("m%n" + prefix.toString(), prefix);
		else {
			resetMaster("m%n" + prefix.toString(), prefix);
			resetMaster("m%x" + prefix.toString(), prefix);
		}

		q[n] = TPoly.create(session, prefix);
		q[n].addToDisk("q" + n.toString(), "1.0");// 1
		q[n].mywho = "q" + n.toString();

		qq[n - 1] = q[n].timesConstantToDisk("qq" + SNum.Subtrai(n.toString(), "1"), "1", "0");

		for (i = n - 2; i >= 1; i--) {
			logar(prefix, "qq[" + i.toString() + "] = multiplicar por plinha^2");
			qq[i] = qq[i + 1].multiplyToDisk("qq" + i.toString(), plinha2);
			logar(prefix, "vou reduzir qq[" + i.toString() + "]");
			qq[i].diskReduce("qq" + i.toString(), p, prefix, n);
		}

		logar(prefix, "qq[0] = multiplicar por plinha");
		qq[0] = qq[1].multiplyToDisk("qq0", plinha);
		logar(prefix, "vou reduzir qq0");
		qq[0].diskReduce("qq0", p, prefix, n);
		qq[n] = qq[0];
		max = 0;

		for (i = 0; i <= n; i++) {
			logar(prefix, "temp1 = multiplicar por qq[" + i.toString() + "]");
			temp[1] = q[i].multiplyToDisk("m" + i.toString() + "x" + prefix.toString(), qq[i]);
			zerar(temp[1].mywho, prefix, n);
			// fixei a_n = 1. se não for "", fazer isto. senão, só rename to m%n.
			q[i] = temp[1].TimesConstantToDisk("m" + i.toString() + "n" + prefix.toString(), "1", "0");
			q[i] = temp[1];

			logar(prefix, "vou reduzir m" + i.toString() + "x" + prefix.toString());
			q[i].diskReduce("m" + i.toString() + "x" + prefix.toString(), p, prefix, n);
			j = Poly.maxPower(q[i].mywho, prefix);
			if (j > max)
				max = j;
		}

		logar(prefix, "minPower");
		Integer m = minPower(SNum.Soma(n.toString(), "2"), "m%n" + prefix.toString(), prefix);
		if (m < 0) {
			logar(prefix, "powerUp");
			powerUp(SNum.Soma(n.toString(), "2"), "m%n" + prefix.toString(), -m, prefix);
		}

		logar(prefix, "superGCD");
		superGreatestCommonDivisor("m%n" + prefix.toString(), prefix);
	}

	public static void extrairN(Integer n, Integer prefix) throws SQLException {
		Integer i, j;
		TPoly[][] a;
		a = new TPoly[13][12];
		TPoly[] m;
		m = new TPoly[13];
		Integer[] simples;
		simples = new Integer[13];

		TPoly p1 = new TPoly(), p2 = new TPoly(), p3 = new TPoly(), p4 = new TPoly();

		p1.mywho = "-";
		p2.mywho = "-";
		p3.mywho = "-";
		p4.mywho = "-";

// Util.initDatabase(Util.getProducao());
		conProd = DriverManager.getConnection(Util.getDatabaseURL(), Util.getDatabaseUser(), Util.getDatabasePwd());
		logar(prefix, "extrair " + prefix.toString() + ". vou dropar");
		delAllMaster(prefix);
		delAllStatusOut();
		delAllStatusWith();
		resetMaster("mi%", prefix);
		resetMaster("m%n" + prefix.toString() + "sol", prefix);
// SQLException e = new SQLException("teste");
// if (n == 5) throw e;

// extrair Ai0j0 ... Ai3j2
		for (i = 0; i <= n; i++) {
			logar(prefix, "extract " + i.toString());
			for (j = 0; j <= n - 1; j++) {
				extractMaster("mi" + i.toString() + "j" + j.toString(), "m" + i.toString() + "n" + prefix.toString(), j,
						prefix);

				a[i][j] = new TPoly();
				a[i][j].mywho = "mi" + i.toString() + "j" + j.toString();
				// a[i][j].maxi = maxI("mi" + i.toString() + "j" +
				// j.toString());
			}
			simples[i] = 0;
			m[i] = new TPoly();
			m[i].mywho = "-";
		}

		logar(prefix, "fim");
		conProd.close();
	}

	public static void continueN(HttpSession session, Integer n) throws SQLException {
		Integer i = null, j = null, k = null, max = null, minimo = null, count = null;
		TPoly[][] a;
		a = new TPoly[13][12];
		TPoly[] m;
		m = new TPoly[13];
		Integer[] simples;
		simples = new Integer[13];

		Boolean flag;

		conProd = DriverManager.getConnection(Util.getDatabaseURL(), Util.getDatabaseUser(), Util.getDatabasePwd());
		System.out.println("load");

// load
		TPoly p1 = new TPoly(), p2 = new TPoly(), p3 = new TPoly(), p4 = new TPoly();
		String u = "1", // polinomio temporario "U1"
				s = "", line = "";
		Integer p1size = 0;

		String query = "select * from statusout order by 1 desc LIMIT 1";
		PreparedStatement st = conProd.prepareStatement(query);
		st.execute();
		ResultSet rs = st.getResultSet();
		if (rs.next()) {
			int x = 2;
			line = rs.getString(x++);
			i = rs.getInt(x++);
			j = rs.getInt(x++);
			k = rs.getInt(x++);
			max = rs.getInt(x++);
			minimo = rs.getInt(x++);
			count = rs.getInt(x++);
			int ii;
			for (ii = 0; ii <= n; ii++)
				for (int jj = 0; jj <= n - 1; jj++) {
					a[ii][jj] = new TPoly();
					a[ii][jj].mywho = rs.getString(x++);
					// a[ii][jj].maxi = maxI(a[ii][jj].mywho);
					// a[ii][jj].maxPower = maxPower(a[ii][jj].mywho);
				}
			for (ii = 0; ii <= n; ii++) {
				m[ii] = new TPoly();
				m[ii].mywho = rs.getString(x++);
			}
			for (ii = 0; ii <= n; ii++)
				simples[ii] = rs.getInt(x++);
			p1.mywho = rs.getString(x++);
			p2.mywho = rs.getString(x++);
			p3.mywho = rs.getString(x++);
			p4.mywho = rs.getString(x++);
			// p1.maxi = maxI(p1.mywho);
			// p2.maxi = maxI(p2.mywho);
			// p3.maxi = maxI(p3.mywho);
			// p4.maxi = maxI(p4.mywho);
			// p1.maxPower = maxPower(p1.mywho);
			// p2.maxPower = maxPower(p2.mywho);
			// p3.maxPower = maxPower(p3.mywho);
			// p4.maxPower = maxPower(p4.mywho);
			u = rs.getString(x++);
			s = rs.getString(x++);
			p1size = Poly.counter(p1.mywho, 0, n);
		}
		rs.close();
		st.close();
		Poly.delAllStatusOut();// 24/sep/2019 -3 horas
		setWait(-2);

		Boolean load = true;

		if (line.equals("p1") || line.equals("p2") || line.equals("p1(m)") || line.equals("p2(m)"))
			flag = true;
		else
			return;

		if (line.equals("p1") || line.equals("p2"))
			do {
				if (line.equals("")) {
					minimo = 0x40000000;
					for (i = 0; i <= n; i++) {
						count = counter(a[i][max].mywho, 0, n);
						System.out.println("count = " + count.toString());

						if ((count > 0) && (count < minimo)) {
							minimo = count;
							j = n - max;
							simples[j] = i;
							System.out.println("minimo = " + minimo.toString() + " from " + a[i][max].mywho + " "
									+ simples[0].toString() + simples[1].toString() + simples[2].toString()
									+ simples[3].toString() + simples[4].toString() + simples[5].toString());
						}
					}

					j = n - max;
					System.out.println("simples " + j.toString() + " = " + simples[j].toString());
					j = 0;
				}

				while (j <= n - 1) {
					if (line.equals("")) {
						count = n - max;
						i = simples[count];
					}
					if (!j.equals(max)) {
						if (line.equals(""))
							k = 0;
						while (k <= n) {
							if (!k.equals(i)) {
								if (line.equals("")) {
									System.out.println("max = " + max.toString() + ", j = " + j.toString() + ", k = "
											+ k.toString());

									a[k][j] = a[k][j].DiskSimplify();
									a[i][max] = a[i][max].DiskSimplify();
								}
								if (line.equals("p1"))
									line = "";
								if (line.equals("")) {
									statusWithoutCount("p1", i, j, k, max, minimo, count, a, m, simples, p1.mywho,
											p2.mywho, p3.mywho, p4.mywho, u, s, n);
									p1 = a[k][j].multiplyToDisk2(true, "U" + u, a[i][max], load, conProd);
									load = false;
									u = SNum.Soma(u, "1");
									p1size = Poly.counter(p1.mywho, 0, n);
// p1 = p1.DiskSimplify();
									a[i][j] = a[i][j].DiskSimplify();
									a[k][max] = a[k][max].DiskSimplify();
								}

								if (line.equals("p2"))
									line = "";

								statusWithoutCount("p2", i, j, k, max, minimo, count, a, m, simples, p1.mywho, p2.mywho,
										p3.mywho, p4.mywho, u, s, n);
								p2 = a[i][j].multiplyToDisk2(true, "U" + u, a[k][max], load, conProd);

// if (n.equals(5))
// throw new SQLException("aguardar fim de threads");

								load = false;
								u = SNum.Soma(u, "1");
								p2 = p2.DiskSimplify();
								p3 = p2.TimesConstantToDisk("U" + u, "-1", "0");
								System.out.println("debug.multipliquei");
								u = SNum.Soma(u, "1");
								p4 = p1.SumToDisk(p1.mywho, p3, p1size);
								System.out.println("debug.somei");
// p4 = p4.DiskSimplify();
								a[k][j] = p4;
// resetMaster(p2.mywho);
// resetMaster(p3.mywho);
							}
							k++;
						}

						delMaster("mi" + i.toString() + "j" + j.toString(), 0, n);
						a[i][j].mywho = "mi" + i.toString() + "j" + j.toString();
						// a[i][j].maxi = 0;
					}
					j++;
				}

				/*
				 * for (i = 0;i <= n;i++) { s = " ";for (j = 0;j <= n - 1;j++) { s = s +
				 * counter(a[i][j].mywho).toString() + ".";} System.out.println("debug " +
				 * i.toString() + s);}
				 */

				max--;
			} while (max > 0);

//agora vamos calcular os emmys
		if (line.equals("")) {
			j = -1;
			k = -1;
			for (count = 0; count <= n; count++) {
				flag = true;
				for (i = 1; i <= n - 1; i++)
					if (simples[i].equals(count))
						flag = false;

				if (flag)
					if (j.equals(-1))
						j = count;// sobrou 1
					else {
						k = count;// sobraram 2
						break;
					}
			}

			System.out.println("");
			System.out.println("[begin]");
			System.out.println("");

			System.out.println("m" + j.toString() + " over 1");

			s = "m" + j.toString() + "n" + n.toString() + "sol";
			m[j] = a[k][0].TimesConstantToDisk(s, "1", "0");
			s = "m" + k.toString() + "n" + n.toString() + "sol";
			System.out.println("m" + k.toString() + " over 1");

			m[k] = a[j][0].TimesConstantToDisk(s, "-1", "0");
			i = 1;
		}

		while (i <= n - 1) {
			if (line.equals("")) {
				count = n - i;
				a[j][count] = a[j][count].DiskSimplify();
				m[j] = m[j].DiskSimplify();
			}
			if (line.equals("p1(m)"))
				line = "";
			if (line.equals("")) {
				statusWithoutCount("p1(m)", i, j, k, max, minimo, count, a, m, simples, p1.mywho, p2.mywho, p3.mywho,
						p4.mywho, u, s, n);
				p1 = a[j][count].multiplyToDisk2(true, "U" + u, m[j], load, conProd);

				if (n.equals(5))
					throw new SQLException("aguardar fim de threads");

				load = false;
				p1size = Poly.counter(p1.mywho, 0, n);
				u = SNum.Soma(u, "1");
// p1 = p1.DiskSimplify();
				a[k][count] = a[k][count].DiskSimplify();
				m[k] = m[k].DiskSimplify();
			}

			if (line.equals("p2(m)"))
				line = "";

			statusWithoutCount("p2(m)", i, j, k, max, minimo, count, a, m, simples, p1.mywho, p2.mywho, p3.mywho,
					p4.mywho, u, s, n);
			p2 = a[k][count].multiplyToDisk2(true, "U" + u, m[k], load, conProd);

			if (n.equals(5))
				throw new SQLException("aguardar fim de threads");

			load = false;
			u = SNum.Soma(u, "1");
// p2 = p2.DiskSimplify();
			p3 = p1.SumToDisk(p1.mywho, p2, p1size);
			p3 = p3.DiskSimplify();
			s = "m" + simples[i].toString() + "n" + n.toString() + "sol";
			m[simples[i]] = p3.TimesConstantToDisk(s, "-1", "0");
			System.out.println("m" + simples[i].toString() + " over " + a[simples[count]][i].mywho);
// resetMaster(p2.mywho);
// resetMaster(p3.mywho);
			i++;
		}

		System.out.println("");
		System.out.println("[end]");
		conProd.close();
	}
	
	public static void println(FileOutputStream out, String s) throws IOException {
		s = s + "\n";
		out.write(s.getBytes());
	}

	public static void processarN(HttpSession session, Integer n, Integer prefix) throws SQLException, IOException {
		Integer i, j = 0, k, max, minimo, count, limite;
		TPoly[][] a;
		a = new TPoly[n + 1][n];
		TPoly[] m;
		m = new TPoly[n + 1];
		Integer[] simples;
		simples = new Integer[n + 1];

		// limite = n - passos;
		if ((n < 5) || prefix.equals(14))
			limite = 0;
		else if (n.equals(5))
			limite = n - 1;
		else
			limite = n;

		// Util.initDatabase(Util.getProducao());
		conProd = DriverManager.getConnection(Util.getDatabaseURL(), Util.getDatabaseUser(), Util.getDatabasePwd());
		TPoly p1 = TPoly.create(session, prefix), p2 = TPoly.create(session, prefix),
				p3 = TPoly.create(session, prefix), p4 = TPoly.create(session, prefix);

		p1.setWho("-");
		p2.setWho("-");
		p3.setWho("-");
		p4.setWho("-");

		String u = "1", // polinomio temporario "U1"
				s = "";
		Boolean flag;

		System.out.println("reset");
		delAllMaster(prefix);
		delAllStatusOut();
		delAllStatusWith();
		resetMaster("m%n" + prefix.toString() + "%", prefix);
// SQLException e = new SQLException("teste");
// if (n == 5) throw e;

// extrair Ai0j0 ... Ai3j2
		for (i = 0; i <= n; i++) {
			System.out.println("extract i = " + i.toString());
			for (j = 0; j <= n - 1; j++) {
				a[i][j] = TPoly.create(session, prefix);
				a[i][j].setWho("mi" + i.toString() + "j" + j.toString());
			}
			simples[i] = 0;
			m[i] = TPoly.create(session, prefix);
			m[i].setWho("-");
		}

// a12 m1 = a02 m0 + a32 m3

		max = n - 1;
		do {
			minimo = 0x40000000;
			for (i = 0; i <= n; i++) {
				count = counter(a[i][max].mywho, 0, prefix);
				System.out.println("count = " + count.toString());

				if ((count > 0) && (count < minimo)) {
					minimo = count;
					j = n - max;
					simples[j] = i;
					System.out.print("minimo = " + minimo.toString() + " from " + a[i][max].mywho + " ");
					for (k = 0; k <= n; k++)
						System.out.print(simples[k].toString());
					System.out.println("");
				}
			}

			i = -1;
			for (;;) {
				Boolean repetido = false;
				for (Integer v = 1; v <= j - 1; v++)
					if (simples[v] == simples[j])
						repetido = true;

				if (!repetido)
					break;
				i++;
				simples[j] = i;
			}

			j = n - max;
// simples[j] = j;
			System.out.println("simples " + j.toString() + " = " + simples[j].toString());

			for (j = 0; j <= n - 1; j++) {
				count = n - max;
				i = simples[count];
				if (!j.equals(max)) {
					for (k = 0; k <= n; k++)
						if (!k.equals(i)) {
							System.out.println(
									"max = " + max.toString() + ", j = " + j.toString() + ", k = " + k.toString());

							statusWithoutCount("p1", i, j, k, max, minimo, count, a, m, simples, p1.mywho, p2.mywho,
									p3.mywho, p4.mywho, u, s, n);
							a[k][j] = a[k][j].DiskSimplify();
							a[i][max] = a[i][max].DiskSimplify();
							p1 = a[k][j].MultiplyToDisk("U" + u, a[i][max], false, conProd);
							Integer p1size = Poly.counter(p1.mywho, 0, prefix);
							u = SNum.Soma(u, "1");
// p1 = p1.DiskSimplify();
							a[i][j] = a[i][j].DiskSimplify();
							a[k][max] = a[k][max].DiskSimplify();
							statusWithoutCount("p2", i, j, k, max, minimo, count, a, m, simples, p1.mywho, p2.mywho,
									p3.mywho, p4.mywho, u, s, n);
							p2 = a[i][j].MultiplyToDisk("U" + u, a[k][max], false, conProd);
							u = SNum.Soma(u, "1");
							p2 = p2.DiskSimplify();
							p3 = p2.TimesConstantToDisk("U" + u, "-1", "0");
							u = SNum.Soma(u, "1");
							p4 = p1.SumToDisk(p1.mywho, p3, p1size);
// p4 = p4.DiskSimplify();
							a[k][j] = p4;
// resetMaster(p2.mywho);
// resetMaster(p3.mywho);
						}

					delMaster("mi" + i.toString() + "j" + j.toString(), 0, prefix);
					a[i][j].setWho("mi" + i.toString() + "j" + j.toString());
				}
			}

			/*
			 * for (i = 0;i <= n;i++) { s = " ";for (j = 0;j <= n - 1; j++) { s = s +
			 * counter(a[i][j].mywho).toString() + "."; } System.out.println("debug " +
			 * i.toString() + s);}
			 */

			max--;
		} while (max >= limite);

		if (n <= 12) {
			for (i = 0; i <= n; i++)
				for (j = 0; j <= n - 1; j++) {
					s = "mi" + i.toString() + "j" + j.toString();
					if (!a[i][j].mywho.equals(s)) {
						delMaster(s, 0, prefix);
						a[i][j] = a[i][j].timesConstantToDisk(s, "1", "0");
					}
				}

			i = n + 3;
			for (j = 0; j < n; j++) {
				for (s = "1"; !s.equals(i.toString()); s = SNum.Soma(s, "1")) {
					k = minPower(s, "mi%j" + j.toString(), prefix);
					if (k > 0)
						powerUp(s, "mi%j" + j.toString(), -k, prefix);
				}

				superGreatestCommonDivisor("mi%j" + j.toString(), prefix);
			}
		}

		// agora vamos calcular os emmys
		j = -1;
		k = -1;
		for (count = 0; count <= n; count++) {
			flag = true;
			for (i = 1; i <= n - 1; i++)
				if (simples[i].equals(count))
					flag = false;

			if (flag)
				if (j.equals(-1))
					j = count;// sobrou 1
				else {
					k = count;// sobraram 2
					break;
				}
		}

		FileOutputStream out = new FileOutputStream("v:/eee.txt");	
		println(out, "[begin]");
		println(out, "");

		println(out, "m" + j.toString() + " over 1");

		s = "m" + j.toString() + "n" + prefix.toString() + "sol";
		m[j] = a[k][0].TimesConstantToDisk(s, "1", "0");
		s = "m" + k.toString() + "n" + prefix.toString() + "sol";
		println(out, "m" + k.toString() + " over 1");

		m[k] = a[j][0].TimesConstantToDisk(s, "-1", "0");

		for (i = 1; i <= n - 1; i++) {
			count = n - i;
			a[j][count] = a[j][count].DiskSimplify();
			m[j] = m[j].DiskSimplify();
			statusWithoutCount("p1(m)", i, j, k, max, minimo, count, a, m, simples, p1.mywho, p2.mywho, p3.mywho,
					p4.mywho, u, s, n);
			p1 = a[j][count].MultiplyToDisk("U" + u, m[j], false, conProd);
			u = SNum.Soma(u, "1");
			Integer p1size = Poly.counter(p1.mywho, 0, prefix);
// p1 = p1.DiskSimplify();
			a[k][count] = a[k][count].DiskSimplify();
			m[k] = m[k].DiskSimplify();
			statusWithoutCount("p2(m)", i, j, k, max, minimo, count, a, m, simples, p1.mywho, p2.mywho, p3.mywho,
					p4.mywho, u, s, n);
			p2 = a[k][count].MultiplyToDisk("U" + u, m[k], false, conProd);
			u = SNum.Soma(u, "1");
// p2 = p2.DiskSimplify();
			p3 = p1.SumToDisk(p1.mywho, p2, p1size);
// p3 = p3.DiskSimplify();
			s = "m" + simples[i].toString() + "n" + prefix.toString() + "sol";
			m[simples[i]] = p3.TimesConstantToDisk(s, "-1", "0");
			println(out, "m" + simples[i].toString() + " over " + a[simples[count]][i].mywho);
			println(out, "");
			println(out, a[simples[count]][i].coefxInDisk("0"));
// resetMaster(p2.mywho);
// resetMaster(p3.mywho);
		}

		println(out, "");
		println(out, "[end]");
		println(out, "");

		for (i = 0; i <= n; i++) {
			println(out, "i = " + i.toString() + "\n\n");
			println(out, m[i].coefxInDisk("0"));
		}

		conProd.close();
		out.close();
	}

	public static void logReset(Integer n) {
		String tabela = "drop table g0" + n.toString() + "loggy";
		PreparedStatement st;
		try {
			st = conProd.prepareStatement(tabela);
			st.executeUpdate();
			st.close();
		} catch (SQLException e) {
		}

		try {
			tabela = "create table g0" + n.toString() + "loggy (\n" + "hora character varying(255) not null,\n"
					+ "texto character varying(255) not null,\n" + "primary key (hora))";
			st = conProd.prepareStatement(tabela);
			st.executeUpdate();
			st.close();
		} catch (SQLException e) {
		}
	}

	public static void logar(Integer n, String s) {
		System.out.println(s);
		try {
			String tabela = "insert into g0" + n.toString() + "loggy " + "select to_char(now() - INTERVAL \'" + Util.GMT
					+ " HOURS\', \'YYYY/MM/DD HH24:mi:ss.US\'), ?" + " from poly_pa";
			PreparedStatement st = conProd.prepareStatement(tabela);
			st.setString(1, s);
			st.executeUpdate();
			st.close();
		} catch (SQLException e) {
		}
	}

	public static void delphi(HttpSession session, Integer n) throws SQLException {

		Util.initDatabase(Util.getProducao());
		conProd = DriverManager.getConnection(Util.getDatabaseURL(), Util.getDatabaseUser(), Util.getDatabasePwd());
		System.out.println("delphi " + n.toString() + ". vou dropar");
		resetMaster("%", n);
		logReset(n);

		TPoly p, plinha, plinha2;
		TPoly[] q, qq, temp = new TPoly[4];
		Integer i, j, max;
		String s;

//derive n - 1 vezes: a_n x^n + ... + a_1 x + s = p + s = 0
//                    p' x' + 1 = 0
//                    x' = -1/p'

// p'' (x')^2 + p' x''  = 0
// p'' + (p')^3 x'' = 0
// x'' = - p'' /(p')^3
// q_2 = - p''

// i >= 2
// x^(i) = q_i / (p')^{2i - 1}
// (p')^{2i - 1} x^(i) - q_i = 0
// (2i - 1) (p')^{2i - 2} x' x^(i) + (p')^{2i - 1} x^(i + 1) - q_i' = 0
// - (2i - 1) q_i / (p')^2 + (p')^{2i - 1} x^(i + 1) - q_i' = 0
// - (2i - 1) q_i + (p')^{2i + 1} x^(i + 1) - q_i' (p')^2 = 0
// x^(i + 1) = [q_i' (p')^2 + (2i - 1) q_i] / (p')^{2i + 1}

// q_{i + 1} = q_i' (p')^2 + (2i - 1) q_i

		q = new TPoly[n + 1];
		qq = new TPoly[n + 1];
		p = TPoly.create(session, n);// x_1 = x, x_2 = s, x_3 = a_1, ..., x_{n + 2} = a_n
		for (i = 1; i <= n; i++)
			p.addToDisk("plambda", "1.0." + i.toString() + nTimesStr(i, ".0") + ".1");
		p.mywho = "plambda";
		System.out.println("plambda");

		plinha = p.derivateToDisk("L", n);
		System.out.println("L");
		temp[1] = plinha.derivateToDisk("T1", n);
		System.out.println("T1");
		q[2] = temp[1].timesConstantToDisk("q2", "-1", "0");
		System.out.println("q2");

		plinha2 = plinha.multiplyToDisk("l2", plinha);
		System.out.println("l2");

// p(x) + s == 0 ====> a_n x^n == - s - Q
		temp[1] = p.timesConstantToDisk("p", "-1", "0");
		temp[1].addToDisk("p", "-1.0.0.1");// -s
		temp[1].addToDisk("p", "1.0." + n.toString() + nTimesStr(n, ".0") + ".1");// x^n a_n
		p = temp[1];
		p.DiskSimplify();
		System.out.println("p");

		logar(n, "vou reduzir l2");
		plinha2.diskReduce("l2", p, n, n);

		for (i = 2; i <= n - 2; i++) {
			s = SNum.Subtrai(SNum.Multiplica("2", i.toString()), "1");
			logar(n, "temp1 = derivar q[" + i.toString() + "]");
			temp[1] = q[i].derivateToDisk("T2", n);

			logar(n, "temp3 = vezes constante " + s);
			temp[3] = q[i].TimesConstantToDisk("T3", s, "0");

			Integer i2 = i + 1;
			logar(n, "disk " + i2.toString() + " = multiplicar por plinha^2");
			temp[2] = plinha2.multiplyToDisk("q" + i2.toString(), temp[1]);

			logar(n, "q[" + i2.toString() + "] = sum [to disk] temp 3");
			q[i + 1] = temp[2].sumToDisk("q" + i2.toString(), temp[3]);

			resetMaster("m%n" + n.toString(), n);

			logar(n, "vou reduzir q[" + i2.toString() + "]");
			q[i + 1].diskReduce("q" + i2.toString(), p, n, n);
		}

// \sum m_i x^(i) + m_n == 0
// \sum_1^{n-1} m_i q_i (p')^{2n - 2 - 2i} + (m_0 x + m_n) (p')^{2n - 3} == 0

		q[0] = TPoly.create(session, n);
		q[0].addToDisk("q0", "1.0.1");// x
		q[0].mywho = "q0";

		q[1] = TPoly.create(session, n);
		q[1].addToDisk("q1", "-1.0");// -1
		q[1].mywho = "q1";

		if (n.equals(2))
			exec2("m%n" + n.toString(), n);
		else
			resetMaster("m%n" + n.toString(), n);

		q[n] = TPoly.create(session, n);
		q[n].addToDisk("q" + n.toString(), "1.0");// 1
		q[n].mywho = "q" + n.toString();

		qq[n - 1] = q[n].timesConstantToDisk("qq" + SNum.Subtrai(n.toString(), "1"), "1", "0");

		for (i = n - 2; i >= 1; i--) {
			logar(n, "qq[" + i.toString() + "] = multiplicar por plinha^2");
			qq[i] = qq[i + 1].multiplyToDisk("qq" + i.toString(), plinha2);
			logar(n, "vou reduzir qq[" + i.toString() + "]");
			qq[i].diskReduce("qq" + i.toString(), p, n, n);
		}

		logar(n, "qq[0] = multiplicar por plinha");
		qq[0] = qq[1].multiplyToDisk("qq0", plinha);
		logar(n, "vou reduzir qq0");
		qq[0].diskReduce("qq0", p, n, n);
		qq[n] = qq[0];
		max = 0;

		for (i = 0; i <= n; i++) {
			logar(n, "temp1 = multiplicar por qq[" + i.toString() + "]");
			temp[1] = q[i].multiplyToDisk("m" + i.toString() + "n" + n.toString(), qq[i]);
			q[i] = temp[1];
			logar(n, "vou reduzir m" + i.toString() + "n" + n.toString());
			q[i].diskReduce("m" + i.toString() + "n" + n.toString(), p, n, n);
			j = Poly.maxPower(q[i].mywho, n);
			if (j > max)
				max = j;
		}

		logar(n, "minPower");
		Integer m = minPower(SNum.Soma(n.toString(), "2"), "m%n" + n.toString(), n);
		if (m < 0) {
			logar(n, "powerUp");
			powerUp(SNum.Soma(n.toString(), "2"), "m%n" + n.toString(), -m, n);
		}

		logar(n, "superGCD");
		superGreatestCommonDivisor("m%n" + n.toString(), n);
	}
}
