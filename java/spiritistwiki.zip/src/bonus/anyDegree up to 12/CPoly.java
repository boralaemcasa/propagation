package br.com.calcula.wiki.entidades;

public class CPoly {

	public String who;
	public String i;
	public String coef;
	public String coefi;
	public Integer[] p;
	
	public CPoly() {
		p = new Integer[15];
		for (int i = 0;i < 15;i++)
			p[i] = 0;
	}
}
