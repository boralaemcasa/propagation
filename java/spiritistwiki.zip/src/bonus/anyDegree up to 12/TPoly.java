package br.com.calcula.wiki;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpSession;

import br.com.calcula.wiki.entidades.CPoly;
import br.com.calcula.wiki.entidades.PolyTask;

public class TPoly {
	public String mywho;
	public Integer grau;
	public String[] list;
	public Integer listn;
	public HttpSession session;

	public void setListn(int n) {
		listn = n;
		list = new String[n];
	}

	public static TPoly create(HttpSession sessao, Integer degree) {
		TPoly p = new TPoly();
		p.listn = 0;
		p.grau = degree;
		p.session = sessao;
		return p;
	}

	public void setWho(String who) {
		mywho = who;
		setListn(1);
		try {
			list[0] = Poly.maxI(who, grau).toString();
		} catch (SQLException e) {
			list[0] = "0";
		}
	}

	public TPoly derivateToDisk(String who, Integer prefix) throws SQLException { // em relaçao a x_1
		TPoly result = TPoly.create(session, grau);
		result.list = list;
		result.listn = listn;
		result.mywho = who;
		Poly.qryDerivMaster(who, mywho, prefix);
		result.mywho = who;
		return result;
	}

	public int termosGEGrau(Integer prefix, Integer GRAU) {
		try {
			return Poly.termosGEGrau(mywho, prefix, GRAU);
		} catch (SQLException e) {
			return 0;
		}
	}

	public TPoly timesConstantToDisk(String who, String kRe, String kIm) throws SQLException {
		TPoly result = TPoly.create(session, grau);
		result.mywho = who;
		result.list = list;
		result.listn = listn;
		if (kRe.equals("0") && kIm.equals("0"))
			return result;

		Poly.timesMaster(who, mywho, kRe, kIm, grau);
		return result;
	}

	Boolean isZero() {
		if (listn == 0)
			return true;

		if (listn == 1)
			if (list[0].equals("0"))
				return true;

		return false;
	}

	public TPoly multiplyToDisk(String who, TPoly p) throws SQLException {
		TPoly result = TPoly.create(session, grau);
		result.mywho = who;
		if (p.isZero() || isZero()) {
			result.setListn(1);
			result.list[0] = "0";			
			return result;
		}

		System.out.println("mult " + who + " = " + mywho + " x " + p.mywho);
		System.out.println(
				"mult " + Poly.counter(mywho, 0, grau).toString() + ", " + Poly.counter(p.mywho, 0, grau).toString());

		Poly.mult(who, mywho, p.mywho, grau);
		result.setListn(1);
		result.list[0] = Poly.maxI(who, grau).toString();
		return result;
	}

	public TPoly sumToDisk(String who, TPoly p) throws SQLException {
		TPoly result = TPoly.create(session, grau);
		result.setListn(1);
		try {
			result.list[0] = SNum.Soma(list[0], p.list[0]);
		} catch (Exception e) {
			result.list[0] = "";
		}
		Poly.sumMaster(who, p.mywho, grau);
		result.mywho = who;
		return result;
	}

	public static ArrayList<String> splitPowers(String s) {
		int i;
		ArrayList<String> result = new ArrayList<String>();
		for (;;) {
			i = s.indexOf('.');
			if (i < 0)
				break;
			result.add(s.substring(0, i));
			s = s.substring(i + 1);
		}
		if (!s.equals(""))
			result.add(s);
		return result;
	}

	public void addToDisk(String who, String s) throws SQLException {
		CPoly poly = new CPoly();
		ArrayList<String> a = splitPowers(s);
		while (a.size() <= 15)
			a.add("0");
		poly.coef = a.get(0);
		poly.coefi = a.get(1);
		for (int i = 1; i <= 14; i++)
			poly.p[i] = Integer.parseInt(a.get(i + 1));
		addToDisk(who, poly);
	}

	public void addToDisk(String who, CPoly poly) throws SQLException {
		String coef;
		if (listn == 0) {
			setListn(1);
			list[0] = "1";
		} else
			list[0] = SNum.Soma(list[0], "1");

		ArrayList<CPoly> registro = Poly.qryAdd(who, poly, grau);

		for (CPoly linha : registro) {
			coef = linha.coef;
			poly.coef = SNum.FracAdd(poly.coef, coef);
			Poly.delMasterOne(who, linha.i, grau);
		}

		if (!poly.coef.equals("0"))
			Poly.qryInsMaster(who, Integer.parseInt(list[0]), poly, grau);
	}

	public void diskReduce(String who, TPoly p, Integer prefix, Integer GRAU) throws SQLException {
		Integer level, contador;
		TPoly[] temp = new TPoly[4];
		DiskSimplify();

		// isso aqui precisa de transação.
		// depurei a parte em que eu chamo who = G03PL2, grau = 3, p = G03PP
		// acontece que pLinha = 3ax^2 + 2bx + c
		// e pp = bx^2 + cx + s
		// cujo quadrado é PL2 := 9a^2 x^4 + 4b^2 x^2 + c^2 + 12ab x^3 + 6ac x^2 + 4bc x
		// esta funçao faz a substituiçao: ax^3 + bx^2 + cx + s = 0

		// nível 2. precisamos pegar o Líder (9a^2 x^4) e dividir por (ax^3) ==> 9ax (I)
		// isso fica armazenado em linha e vai para G03PTTX no marcador (II)

		// daí multiplicamos: TTY := PP * TTX ==> 9ax (bx^2 + cx + s)
		// só falta cancelar o termo que eu chamei de linha.i := (9a^2 x^4)
		// PL2.delete(linha.i);
		// PL2 += TTY;

		// o resultado é o mesmo inicial. por quê?
		// nível 1. Líder := (12ab - 9ab) x^3, divida por ax^3 exatamente como na linha
		// (I)

		for (;;) {
			level = Poly.maxPower(who, prefix);
			if (level < GRAU)
				return;// repita tudo até que o grau seja menor que 3.
			level -= (GRAU - 1);// msg na tela, nível > 0.
			contador = termosGEGrau(prefix, GRAU);
			Poly.logar(prefix, "trans 1.start; nivel " + level.toString() + ", " + contador.toString()
					+ " registros. vou inserir");
			Poly.qryTTMaster(prefix);
			Poly.qryByPower(who, prefix, "ttx", GRAU);// (II)
			Poly.logar(prefix, "trans 2. vou gerar TTY");
			temp[1] = TPoly.create(session, prefix);
			temp[1].setWho("ttx");
			temp[2] = p.multiplyToDisk("tty", temp[1]);
			Poly.logar(prefix, "trans 3. vou deletar lideres");
			Poly.delMasterPower(who, prefix);
			Poly.logar(prefix, "trans 4. vou gerar " + who);
			temp[3] = this.sumToDisk(who, temp[2]);
			Poly.logar(prefix, "trans 5.commit; vou simplificar");
			list = temp[3].list;
			listn = temp[3].listn;
			DiskSimplify();
		}
	}

	public TPoly SumToDisk(String who, TPoly p, Integer whosize) throws SQLException {
		Integer x = Poly.counter(who, 0, grau);
		TPoly Result = TPoly.create(session, grau);
		if (x == whosize)
			Poly.sumMaster(who, p.mywho, grau);
		Result.setWho(who);
		return Result;
	}

	public TPoly MultiplyToDisk(String who, TPoly p, Boolean load, Connection conProd) throws SQLException {
		Integer stepx = 14336;// squared = 196 Mega
		Integer stepy = 36560;// xy > 499 Mega
		// Integer stepy = 14628;
		Integer c1, c2, i, a1 = null, b1 = null, contador = 0;// simplificador = 0;

		TPoly Result = TPoly.create(p.session, p.grau);
		try {
			Poly.createTable(who, grau);
		} catch (SQLException e) {
		}
		Result.setWho(who);

		c1 = Poly.classify(mywho, grau);
		c2 = Poly.classify(p.mywho, grau);

		i = c1 * c2;

		if (i.equals(0)) {
			Poly.mult(who, mywho, p.mywho, grau);// FIAT table
			return Result;
		}

		System.out.println("mult " + c1.toString() + ", " + c2.toString() + " insert " + i.toString());

		if (i < stepx * stepy) {
			Poly.statusWithCount(0, who, mywho, p.mywho, (long) i, 0, 0, stepx, stepy, c1, c2);
			Poly.mult(who, mywho, p.mywho, grau);
		} else { // (A + B)(C + D)
			if (!load) {
				a1 = 0;
				i = 0;
			}

			do {
				if (!load) {
					b1 = 0;
				}
				do {

					if (load) {
						String query = "select * from statuswith order by 1 desc LIMIT 1";
						PreparedStatement st = conProd.prepareStatement(query);
						st.execute();
						ResultSet rs = st.getResultSet();
						if (rs.next()) {
							String s = rs.getString(3);
							if (s.equals(who)) {
								i = rs.getInt(6);
								a1 = rs.getInt(7);
								b1 = rs.getInt(8);
							} else {
								i = 0;
								a1 = 0;
								b1 = 0;
							}
						}
						rs.close();
						st.close();

						Poly.delAllStatusWith();// 24/sep/2019 -3 horas

						contador = Poly.counter(who, i, grau);
						load = false;
					}

					if (!contador.equals(0))
						Poly.delMaster(who, i, grau);
					Integer line;
					if (a1.equals(0) && b1.equals(0))
						line = 0;
					else
						line = Poly.counter(who, 0, grau);
					Poly.statusWithCount(line, who, mywho, p.mywho, (long) i, a1, b1, a1 + stepx, b1 + stepy, c1, c2);
					Poly.multC(who, mywho, p.mywho, (long) i, a1, b1, a1 + stepx - 1, b1 + stepy - 1);
					Poly.incWait();

					Date hora = new Date();
					SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SSS");
					String hh = df.format(hora);
					System.out.println(hh + " MUL " + a1.toString() + ", " + b1.toString());

					b1 += stepy;
					i += stepx * stepy;
					contador = Poly.counter(who, i, grau);
					// simplificador++;

					// if (simplificador % 200 == 0)
					// Result = Result.DiskSimplify();// 256 K * 200 = 50 M
				} while (b1 <= c2);

				a1 += stepx;
			} while (a1 <= c1);

			// Result = Result.DiskSimplify();
		}

		return Result;
	}

	public TPoly multiplyToDisk2(Boolean flag, String who, TPoly p, Boolean load, Connection conProd)
			throws SQLException {
		Integer nThread = 1;
		Integer c1, c2, i, a1 = null, b1 = null;

		TPoly Result = TPoly.create(session, grau);
		Result.setWho(who);

		c1 = Poly.classify(mywho, grau);
		c2 = Poly.classify(p.mywho, grau);
		Poly.procMult(who, mywho, p.mywho, grau);

		Integer stepx = c1 / 6;// 10628 squared = 196 Mega
		Integer stepy = c2 / 6;// 10628
		if (c1 % 7 > 0)
			stepx++;
		if (c2 % 7 > 0)
			stepy++;

		i = c1 * c2;

		System.out.println("mult " + who + " = " + mywho + " x " + p.mywho);
		System.out.println("mult " + c1.toString() + ", " + c2.toString() + " insert " + i.toString());

		if (i.equals(0)) {
			Poly.mult(who, mywho, p.mywho, grau);// FIAT table
			return Result;
		}

		// try {
		// Poly.resetMaster(who.toLowerCase());
		// } catch (SQLException e) {
		// }

		try {
			Poly.createTable(who, grau);
		} catch (SQLException e) {
			return Result;
		}

		if (i < 1000000) {
			Poly.statusWithCount(0, who, mywho, p.mywho, (long) i, 0, 0, stepx, stepy, c1, c2);
			Poly.mult(who, mywho, p.mywho, grau);
		} else { // (A + B)(C + D)
			if (!load) {
				a1 = 0;
				i = 0;
			}

			do {
				if (!load) {
					b1 = 0;
				}
				do {

					if (load) {
						String query = "select * from statuswith order by 1 desc LIMIT 1";
						PreparedStatement st = conProd.prepareStatement(query);
						st.execute();
						ResultSet rs = st.getResultSet();
						if (rs.next()) {
							String s = rs.getString(3);
							if (s.equals(who)) {
								i = rs.getInt(6);
								a1 = rs.getInt(7);
								b1 = rs.getInt(8);
							} else {
								i = 0;
								a1 = 0;
								b1 = 0;
							}
						}
						rs.close();
						st.close();

						Poly.delAllStatusWith();// 24/sep/2019 -3 horas

						load = false;
					}

					Integer line = (a1 + 1) * (b1 + 1);
					// a1 = 3 stepx
					// b1 = 2 stepy
					// line = 3 * 2 * stepx * stepy

					System.out.println("thread " + nThread.toString());

					if (flag) {
						PolyTask task = new PolyTask(session, "attr" + nThread.toString(), who, mywho, p.mywho,
								(long) i, a1, b1, a1 + stepx - 1, b1 + stepy - 1, c1, c2, line);
						nThread++;
						ExecutorService executorService = Executors.newCachedThreadPool();
						executorService.execute(task);
						executorService.shutdown();
					}

					Date hora = new Date();
					SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SSS");
					String hh = df.format(hora);
					System.out.println(hh + " MUL " + a1.toString() + ", " + b1.toString());

					b1 += stepy;
					i += stepx * stepy;
				} while (b1 <= c2);

				a1 += stepx;
			} while (a1 <= c1);

		}

		if (flag) {
			c1 = 0;
			String s;
			do {
				try {
					TimeUnit.SECONDS.sleep(5);
				} catch (Exception e) {
				}
				c1++;
				if (c1 % 24 == 0) {
					c2 = c1 / 12;
					System.out.println("Aguardando ha " + c2.toString() + " minutos.");
				}

				s = "1";
				for (i = 1; i < nThread; i++) {
					s = session.getAttribute("attr" + i.toString()).toString();
					if (!s.equals("1"))
						break;
				}
			} while (!s.equals("1"));
		}

		Poly.disProcMult(who, mywho, p.mywho);
		return Result;
	}

	public TPoly TimesConstantToDisk(String who, String kRe, String kIm) throws SQLException {
		TPoly Result = new TPoly();
		if (kRe.equals("0") && kIm.equals("0"))
			return Result;

		Poly.timesMaster(who, mywho, kRe, kIm, grau);
		Result.mywho = who;
		Result.grau = grau;
		return Result;
	}

	public TPoly DiskSimplify() throws SQLException {
		Poly.setWait(1);
		// System.out.println("simplify " + mywho);
		Poly.simplify(session, mywho, grau);
		Poly.setWait(0);

		TPoly Result = TPoly.create(session, grau);
		Result.setWho(mywho);
		return Result;
	}

	public String coefxInDisk(String n) throws SQLException {
		Integer j;
		String Result = "";
		Util.initDatabase(Util.getProducao());
		Poly.conProd = DriverManager.getConnection(Util.getDatabaseURL(), Util.getDatabaseUser(),
				Util.getDatabasePwd());

		ArrayList<CPoly> lista = Poly.byPower(mywho, grau, Integer.parseInt(n));

		for (CPoly p : lista) {
			if (p.coef.equals("1"))
				Result = Result + "+";
			else if (p.coef.equals("-1"))
				Result = Result + "-";
			else if (p.coef.startsWith("-"))
				Result = Result + p.coef.toString();
			else
				Result = Result + "+" + p.coef.toString();

			for (j = 2; j <= 14; j++) {
				if (!p.p[j].equals(0)) {
					if (j.equals(2)) {
						if (p.p[j].equals(1))
							Result = Result + " x";
						else
							Result = Result + " x^" + p.p[j].toString();
					} else if (j > 2) {
						Integer k = j - 2;
						if (p.p[j].equals(1))
							Result = Result + " a_" + k.toString();
						else
							Result = Result + " a_" + k.toString() + "^" + p.p[j].toString();
					}
				}
			}

			if (Result.endsWith("+") || Result.endsWith("-"))
				Result = Result + "1";
			Result = Result + "\n";
		}

		if (Result.equals(""))
			Result = "0";
		return Result;
	}
}
