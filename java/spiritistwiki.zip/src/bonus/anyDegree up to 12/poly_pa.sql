create table poly_pa (
  wait integer not null,
  simplify integer not null,
  primary key (wait, simplify));