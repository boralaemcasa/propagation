/***********************************************************************
 *
 * Copyrigh (c) Palm Computing 1995 -- All Rights Reserved
 *
 * PROJECT:  Pilot
 * FILE:     AddressRsc.c
 * AUTHOR:   Roger Flores: June 9, 1995
 *
 * DECLARER: Address
 *
 * DESCRIPTION:
 *     The list of resources are stored here.
 *
 **********************************************************************/

#include <BuildRules.h>
//#include <Pilot.h>

// RESOURCE_FILE_PREFIX is now defined in Pilot:Incs:BuildRules.h based on LANGUAGE.

char *AppResourceList[] = {
   ":Rsc:"RESOURCE_FILE_PREFIX"Starter.rsrc",
   ""
   };
	
