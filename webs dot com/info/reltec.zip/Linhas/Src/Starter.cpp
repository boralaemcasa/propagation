#include <Pilot.h>
#include <SysEvtMgr.h>
#include "StarterRsc.h"

/*****************************************************************
 *
 *   Constantes
 *
 *****************************************************************/

#define BCREATOR   'VCLF'
#define BNOME      "LinhasDB"
#define BTIPO      'DATA'
#define MAXWIDTH   145
#define ROM20      0x02003000   // codigo da ROM 2.0
#define TAMSTR     70
#define VIS_ITEMS  9

/*****************************************************************
 *
 *   Variaveis Globais
 *
 *****************************************************************/

FormPtr pform;
ListPtr plist;
FieldPtr pfield;

class TBanco {
   private:
      DmOpenRef ref;
      VoidHand hreg;

   public:
      void    Abre();
      void    Fecha();
      char*   Linha(Word index);
      Boolean RegAdic(char* nova);
      void    RegChange(Word index, char* nova);
      void    RegExclui(Word index);
      Boolean RegFind(char* s);
      void    RegLib();
      Word    RegNro();
} Banco;

/*****************************************************************
 *
 *   Prototipos e Macros-Funcao
 *
 *****************************************************************/

void    Adicionar();
void    Alterar();
void    AtualizaList(UInt n, RectanglePtr r, CharPtr *items);
void    Excluir();
void    Fatal(char* m1 = "", char* m2 = "", char* m3 = "");
Boolean FormLoadHandleEvent(EventPtr eventP);
void    Info(char* m1, char* m2 = "", char* m3 = "");
Boolean MainFormHandleEvent(EventPtr eventP);
void    MainFormInit();
void*   ObjectPointer(Word ID);
Boolean VersaoIncompativel();

/*****************************************************************
 *
 *   Codigo das Rotinas
 *
 *****************************************************************/

void TBanco::Abre() {
   LocalID id = DmFindDatabase(0, BNOME);
   if (!id)
      if (! DmCreateDatabase(0, BNOME, BCREATOR, BTIPO, false)) {
         id = DmFindDatabase(0, BNOME);
      // atributo de backup
         UInt attrBackup = dmHdrAttrBackup;
         DmSetDatabaseInfo(0, id, NULL, &attrBackup,
            NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
      }

   if (!id) Fatal("Imposs�vel abrir o banco de dados");

   if (! (Banco.ref = DmOpenDatabase(0, id, dmModeReadWrite)))
      Fatal();
}

void TBanco::Fecha() {
   DmCloseDatabase (Banco.ref);
}

char* TBanco::Linha(Word index) {
   hreg = DmQueryRecord (ref, index);
   return (char*) MemHandleLock(hreg);
}

Boolean TBanco::RegAdic(char* nova) {
   Word i;

   if (RegFind(nova)) return false;

   i = dmMaxRecordIndex;
   if (! (hreg = DmNewRecord (ref, &i, TAMSTR+1)))
      Fatal("Erro ao criar registro");
   DmReleaseRecord (ref, i, true);

   RegChange(i, nova);

   return true;
}

void TBanco::RegChange(Word index, char* nova) {
   if (DmWrite(Linha(index), 0, nova, StrLen(nova)+1))
      Fatal("Erro ao gravar em registro");
   RegLib();
}

void TBanco::RegExclui(Word index) {
   if (DmRemoveRecord (ref, index))
      Fatal("Erro ao excluir registro");
}

Boolean TBanco::RegFind(char* s) {
   Boolean existe;

   for (Word i = 0; i < RegNro(); i++) {
      existe = !StrCompare(Linha(i), s);
      RegLib();
      if (existe) return true;
   }
   return false;
}

void TBanco::RegLib() {
   MemHandleUnlock(hreg);
}

Word TBanco::RegNro() {
   return DmNumRecords(ref);
}

void Adicionar() {
   char* text = FldGetTextPtr (pfield);

   if (text && StrLen(text))
      if (FntCharsWidth (text, StrLen(text)) > MAXWIDTH)
         Info("O texto digitado ultrapassa a largura da lista");
      else if (Banco.RegAdic(text)) {
         LstSetSelection(plist, plist->numItems);
         plist->numItems++;
         LstSetTopItem(plist, plist->numItems);
         LstEraseList(plist); LstDrawList(plist);
      }
      else Info("J� existe o item \"", text, "\"");
   else Info("Campo vazio");
}

void Alterar() {
   if (plist->currentItem == noListSelection) {
      Info("Voc� deve primeiro selecionar um item");
      return;
   }

   char* text = FldGetTextPtr (pfield);

   if (FntCharsWidth (text, StrLen(text)) > MAXWIDTH)
      Info("O texto digitado ultrapassa a largura da lista");
   else if (Banco.RegFind(text))
      Info("J� existe o item \"", text, "\"");
   else {
      Banco.RegChange(plist->currentItem, text);
      LstEraseList(plist); LstDrawList(plist);
      FldSetSelection(pfield, 0, StrLen(text));
   }
}

void AtualizaList(UInt n, RectanglePtr r, CharPtr *items) {
   char* p = Banco.Linha(n);
   WinEraseRectangle(r, 0);
   WinDrawChars(p, StrLen(p), r->topLeft.x, r->topLeft.y);
   Banco.RegLib();
}

void Excluir() {
   if (! plist->numItems)
      Info("O banco est� vazio");
   else if (plist->currentItem == noListSelection)
      Info("Voc� deve primeiro selecionar um item");
   else {
      Banco.RegExclui(plist->currentItem);
      if (plist->currentItem == --plist->numItems)
         plist->currentItem--;
      if ((int) (plist->currentItem - VIS_ITEMS + 1) <= 0)
         plist->topItem = 0;
      else plist->topItem = plist->currentItem - VIS_ITEMS + 1;
      LstEraseList(plist); LstDrawList(plist);
   }
}

void Fatal(char* m1, char* m2, char* m3) {
   if (StrCompare(m1, ""))
      FrmCustomAlert(ErroAlert, m1, m2, m3);
   else FrmCustomAlert(ErroAlert, "Erro desconhecido", "", "");
   SysReset();
}

Boolean FormLoadHandleEvent(EventPtr eventP)
{
   if (eventP->eType != frmLoadEvent) return false;

   pform = FrmInitForm(eventP->data.frmLoad.formID);
   FrmSetActiveForm(pform);
   FrmSetEventHandler(pform, MainFormHandleEvent);

   return true;
}

void Info(char* m1, char* m2, char* m3) {
   FrmCustomAlert(InfoAlert, m1, m2, m3);
}

Boolean MainFormHandleEvent(EventPtr eventP)
{
   switch (eventP->eType) {
      case ctlSelectEvent:
         switch (eventP->data.ctlSelect.controlID) {
            case MainAdicButton:
               Adicionar();
            break;

            case MainAltButton:
               Alterar();
            break;

            case MainExcButton:
               Excluir();
            break;
         }
      return true;

      case menuEvent:
         FormPtr pForm = FrmInitForm (SobreForm);
         FrmDoDialog (pForm);
         FrmDeleteForm (pForm);
      return true;

      case lstSelectEvent:
         char* text = Banco.Linha(plist->currentItem);

         Handle h = FldGetTextHandle(pfield);
         if (!h)
            if (! (h = (Handle) MemHandleNew (TAMSTR+1)))
               Fatal("Erro de aloca��o");

         StrCopy((char*) MemHandleLock(h), text);
         MemHandleUnlock(h);
         FldSetText(pfield, h, 0, StrLen(text));
         FldDrawField(pfield);

         FldSetSelection(pfield, 0, StrLen(text));
         Banco.RegLib();
      return true;

      case frmOpenEvent:
         MainFormInit();
      return true;
   }

   return false;
}

void MainFormInit() {
   plist = (ListPtr) ObjectPointer(Main_List);
   plist->numItems = Banco.RegNro();
   plist->currentItem = noListSelection;
   LstSetDrawFunction(plist, AtualizaList);

   pfield = (FieldPtr) ObjectPointer(Main_Field);
   FrmSetFocus(pform, FrmGetObjectIndex(pform, Main_Field));

   FrmDrawForm (pform);
}

void* ObjectPointer(Word ID) {
   return FrmGetObjectPtr (pform, FrmGetObjectIndex(pform, ID));
}

DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{
   if (cmd != sysAppLaunchCmdNormalLaunch || VersaoIncompativel())
      return 0;

   Banco.Abre();

   FrmGotoForm(MainForm);

   Word error;
   EventType event;

   do {
      EvtGetEvent(&event, evtWaitForever);

      if (! SysHandleEvent(&event))
         if (! MenuHandleEvent(0, &event, &error))
            if (! FormLoadHandleEvent(&event))
               FrmDispatchEvent(&event);

   } while (event.eType != appStopEvent);

   Banco.Fecha();

   return 0;
}

Boolean VersaoIncompativel() {
   DWord aux;
   FtrGet(sysFtrCreator, sysFtrNumROMVersion, &aux);
   if (aux >= ROM20) return false;
   Info("Sistema Incompat�vel. Esta aplica��o roda apenas no Sistema 2.0 ou superior.");
   return true;
}